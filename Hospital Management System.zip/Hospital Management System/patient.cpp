#include "Patient.h"
#include <iomanip>


using namespace std;

Patient::Patient() : Person() {
    age = 0;
    gender = 'U';
    balance = 0.0;
}

Patient::Patient(int patientId, const char patientName[], int patientAge,
    char patientGender, const char patientContact[],
    const char patientPassword[], double patientBalance)
    : Person(patientId, patientName, patientContact, patientPassword)
{
    age = patientAge;
    gender = patientGender;
    balance = patientBalance;
}

Patient::~Patient() {}

void Patient::display() const {
    cout << id << " | " << name << " | " << age << " | " << gender << " | "
        << contact << " | PKR " << fixed << setprecision(2) << balance << endl;
}

const char* Patient::roleName() const { return "Patient"; }
int         Patient::getAge()     const { return age; }
char        Patient::getGender()  const { return gender; }
double      Patient::getBalance() const { return balance; }

Patient& Patient::operator+=(double amount) { balance += amount; return *this; }
Patient& Patient::operator-=(double amount) { balance -= amount; return *this; }
bool     Patient::operator==(const Patient& other) const { return id == other.id; }
bool     Patient::operator>=(double amount)         const { return balance >= amount; }

ostream& operator<<(ostream& out, const Patient& p) {
    out << p.id << " | " << p.name << " | " << p.age << " | " << p.gender
        << " | " << p.contact << " | PKR "
        << fixed << setprecision(2) << p.balance;
    return out;
}

bool Patient::isRoleButtonHovered(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(190.0f, 35.0f);
    box.setPosition(x, y);

    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains((float)mouse.x, (float)mouse.y);
}

void Patient::drawRoleButton(sf::RenderWindow& window, sf::Font& font,
    float x, float y, bool hovered)
{
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(190.0f, 35.0f);
    box.setPosition(x, y);
    box.setFillColor(hovered ? sf::Color(55, 170, 210) : sf::Color(35, 125, 165));
    box.setOutlineThickness(3.0f);
    box.setOutlineColor(sf::Color(230, 245, 250));
    window.draw(box);

    sf::Text label;
    label.setFont(font);
    label.setString("Patient");
    label.setCharacterSize(28);
    label.setStyle(sf::Text::Bold);
    label.setFillColor(sf::Color::White);

    sf::FloatRect bounds = label.getLocalBounds();
    label.setOrigin(bounds.left + bounds.width / 2.0f,
        bounds.top + bounds.height / 2.0f);
    label.setPosition(x, y - 2.0f);
    window.draw(label);
}

void Patient::drawIcon(sf::RenderWindow& window, float x, float y) {
    sf::CircleShape head(18.0f);
    head.setOrigin(18.0f, 18.0f);
    head.setPosition(x, y - 14.0f);
    head.setFillColor(sf::Color::White);
    window.draw(head);

    sf::RectangleShape body(sf::Vector2f(70.0f, 32.0f));
    body.setOrigin(35.0f, 16.0f);
    body.setPosition(x, y + 24.0f);
    body.setFillColor(sf::Color::White);
    window.draw(body);
}

bool Patient::runLoginScreen(sf::RenderWindow& window, sf::Font& font,
    char outPassword[], int maxLen)
{
    const float CX = 500.0f;
    const float TOP = 200.0f;

    sf::RectangleShape panel(sf::Vector2f(500.0f, 320.0f));
    panel.setOrigin(250.0f, 160.0f);
    panel.setPosition(CX, TOP + 160.0f);
    panel.setFillColor(sf::Color(25, 35, 50));
    panel.setOutlineThickness(4.0f);
    panel.setOutlineColor(sf::Color(35, 125, 165));

    sf::Text title;
    title.setFont(font);
    title.setString("Patient Login");
    title.setCharacterSize(34);
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color(55, 170, 210));
    {
        sf::FloatRect b = title.getLocalBounds();
        title.setOrigin(b.left + b.width / 2.0f, b.top + b.height / 2.0f);
    }
    title.setPosition(CX, TOP + 30.0f);

    sf::RectangleShape inputBox(sf::Vector2f(360.0f, 48.0f));
    inputBox.setOrigin(180.0f, 24.0f);
    inputBox.setPosition(CX, TOP + 200.0f);
    inputBox.setFillColor(sf::Color(15, 20, 30));
    inputBox.setOutlineThickness(2.0f);
    inputBox.setOutlineColor(sf::Color(55, 170, 210));

    sf::Text pwLabel;
    pwLabel.setFont(font);
    pwLabel.setString("Password");
    pwLabel.setCharacterSize(20);
    pwLabel.setFillColor(sf::Color(180, 210, 230));
    pwLabel.setPosition(CX - 180.0f, TOP + 162.0f);

    sf::Text pwText;
    pwText.setFont(font);
    pwText.setCharacterSize(22);
    pwText.setFillColor(sf::Color::White);
    pwText.setPosition(CX - 170.0f, TOP + 186.0f);

    sf::RectangleShape loginBtn(sf::Vector2f(200.0f, 52.0f));
    loginBtn.setOrigin(100.0f, 26.0f);
    loginBtn.setPosition(CX, TOP + 280.0f);
    loginBtn.setFillColor(sf::Color(35, 125, 165));
    loginBtn.setOutlineThickness(2.0f);
    loginBtn.setOutlineColor(sf::Color(230, 245, 250));

    sf::Text loginLabel;
    loginLabel.setFont(font);
    loginLabel.setString("Login");
    loginLabel.setCharacterSize(24);
    loginLabel.setStyle(sf::Text::Bold);
    loginLabel.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = loginLabel.getLocalBounds();
        loginLabel.setOrigin(b.left + b.width / 2.0f, b.top + b.height / 2.0f);
    }
    loginLabel.setPosition(CX, TOP + 278.0f);

    char inputBuf[128];
    char maskBuf[128];
    int  inputLen = 0;
    bool active = true;
    for (int i = 0; i < 128; i++) inputBuf[i] = '\0';
    for (int i = 0; i < 128; i++) maskBuf[i] = '\0';

    auto isOver = [&](sf::RectangleShape& s) {
        sf::Vector2i m = sf::Mouse::getPosition(window);
        return s.getGlobalBounds().contains((float)m.x, (float)m.y);
        };

    while (window.isOpen() && active) {
        sf::Event ev;
        while (window.pollEvent(ev)) {

            if (ev.type == sf::Event::Closed) {
                window.close();
                return false;
            }

            if (ev.type == sf::Event::KeyPressed) {
                if (ev.key.code == sf::Keyboard::Escape)  return false;
                if (ev.key.code == sf::Keyboard::Return) { active = false; break; }
                if (ev.key.code == sf::Keyboard::BackSpace && inputLen > 0) {
                    inputLen--;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (ev.type == sf::Event::TextEntered) {
                uint32_t c = ev.text.unicode;
                if (c >= 32 && c < 127 && inputLen < maxLen - 1) {
                    inputBuf[inputLen] = static_cast<char>(c);
                    maskBuf[inputLen] = '*';
                    inputLen++;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (ev.type == sf::Event::MouseButtonPressed) {
                if (ev.mouseButton.button == sf::Mouse::Left && isOver(loginBtn))
                    active = false;
            }
        }

        pwText.setString(maskBuf);
        loginBtn.setFillColor(isOver(loginBtn) ? sf::Color(55, 170, 210)
            : sf::Color(35, 125, 165));

        window.clear(sf::Color(10, 14, 22));
        window.draw(panel);
        window.draw(title);
        window.draw(pwLabel);
        window.draw(inputBox);
        window.draw(pwText);
        window.draw(loginBtn);
        window.draw(loginLabel);
        window.display();
    }

    if (outPassword && maxLen > 0) {
        int i = 0;
        while (i < inputLen && i < maxLen - 1) {
            outPassword[i] = inputBuf[i];
            i++;
        }
        outPassword[i] = '\0';
    }
    return true;
}