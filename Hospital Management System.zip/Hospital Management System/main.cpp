#include <SFML/Graphics.hpp>
#include "HospitalSystem.h"
#include <iostream>
#include <fstream>

using namespace std;

static bool mouseInside(sf::RectangleShape& box, sf::RenderWindow& window) {
    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains((float)mouse.x, (float)mouse.y);
}

static void setupButton(sf::RectangleShape& box, float y, sf::Color color) {
    box.setSize(sf::Vector2f(440.0f, 85.0f));
    box.setOrigin(220.0f, 42.5f);
    box.setPosition(500.0f, y);
    box.setFillColor(color);
    box.setOutlineThickness(6.0f);
    box.setOutlineColor(sf::Color::White);
}

static void drawPatientIcon(sf::RenderWindow& window, float x, float y) {
    sf::CircleShape head(18.0f);
    head.setOrigin(18.0f, 18.0f);
    head.setPosition(x, y - 14.0f);
    head.setFillColor(sf::Color::White);
    window.draw(head);

    sf::RectangleShape body(sf::Vector2f(70.0f, 32.0f));
    body.setOrigin(35.0f, 16.0f);
    body.setPosition(x, y + 24.0f);
    body.setFillColor(sf::Color::White);
    window.draw(body);
}

static void drawDoctorIcon(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape vertical(sf::Vector2f(22.0f, 70.0f));
    vertical.setOrigin(11.0f, 35.0f);
    vertical.setPosition(x, y);
    vertical.setFillColor(sf::Color::White);
    window.draw(vertical);

    sf::RectangleShape horizontal(sf::Vector2f(70.0f, 22.0f));
    horizontal.setOrigin(35.0f, 11.0f);
    horizontal.setPosition(x, y);
    horizontal.setFillColor(sf::Color::White);
    window.draw(horizontal);
}

static void drawAdminIcon(sf::RenderWindow& window, float x, float y) {
    sf::CircleShape shield(42.0f, 5);
    shield.setOrigin(42.0f, 42.0f);
    shield.setPosition(x, y);
    shield.setFillColor(sf::Color::White);
    window.draw(shield);

    sf::CircleShape center(16.0f);
    center.setOrigin(16.0f, 16.0f);
    center.setPosition(x, y);
    center.setFillColor(sf::Color(35, 80, 190));
    window.draw(center);
}

static void drawExitIcon(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape line1(sf::Vector2f(90.0f, 16.0f));
    line1.setOrigin(45.0f, 8.0f);
    line1.setPosition(x, y);
    line1.setRotation(45.0f);
    line1.setFillColor(sf::Color::White);
    window.draw(line1);

    sf::RectangleShape line2(sf::Vector2f(90.0f, 16.0f));
    line2.setOrigin(45.0f, 8.0f);
    line2.setPosition(x, y);
    line2.setRotation(-45.0f);
    line2.setFillColor(sf::Color::White);
    window.draw(line2);
}

static void drawCentredText(sf::RenderWindow& window, sf::Font& font,
    const sf::String& str, unsigned int size,
    sf::Color color, float x, float y)
{
    sf::Text text;
    text.setFont(font);
    text.setString(str);
    text.setCharacterSize(size);
    text.setFillColor(color);
    text.setStyle(sf::Text::Bold);

    sf::FloatRect bounds = text.getLocalBounds();
    text.setOrigin(bounds.left + bounds.width / 2.0f,
        bounds.top + bounds.height / 2.0f);
    text.setPosition(x, y);
    window.draw(text);
}

int runSfmlMainMenu() {
    sf::RenderWindow window(
        sf::VideoMode(1000, 700),
        "MediCore Hospital Management System"
    );
    window.setFramerateLimit(60);

    sf::Font font;
    bool fontLoaded = false;

    const char* candidates[] = {
        "C:\\Windows\\Fonts\\arial.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "arial.ttf"
    };
    const int numCandidates = 3;

    static char* fontBuf = nullptr;

    for (int c = 0; c < numCandidates && !fontLoaded; c++) {
        ifstream file(candidates[c], ios::binary | ios::ate);
        if (!file.is_open()) continue;

        streamsize sz = file.tellg();
        file.seekg(0, ios::beg);
        char* buf = new char[sz];
        if (file.read(buf, sz)) {
            fontLoaded = font.loadFromMemory(buf, (size_t)sz);
        }
        if (fontLoaded) {
            delete[] fontBuf;
            fontBuf = buf;
        }
        else {
            delete[] buf;
        }
    }

    if (!fontLoaded) {
        cerr << "[WARNING] Could not load Arial font.\n";
    }

    sf::RectangleShape background(sf::Vector2f(1000.0f, 700.0f));
    background.setFillColor(sf::Color(245, 245, 245));

    sf::RectangleShape header(sf::Vector2f(1000.0f, 120.0f));
    header.setPosition(0.0f, 0.0f);
    header.setFillColor(sf::Color(20, 90, 130));

    sf::RectangleShape panel(sf::Vector2f(600.0f, 500.0f));
    panel.setOrigin(300.0f, 250.0f);
    panel.setPosition(500.0f, 400.0f);
    panel.setFillColor(sf::Color(30, 40, 50));
    panel.setOutlineThickness(8.0f);
    panel.setOutlineColor(sf::Color::Black);

    sf::RectangleShape patientButton, doctorButton, adminButton, exitButton;
    setupButton(patientButton, 250.0f, sf::Color(220, 45, 55));
    setupButton(doctorButton, 355.0f, sf::Color(35, 170, 85));
    setupButton(adminButton, 460.0f, sf::Color(55, 95, 220));
    setupButton(exitButton, 565.0f, sf::Color(175, 55, 190));

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {

            if (event.type == sf::Event::Closed) {
                window.close();
                return 4;
            }

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Escape) {
                    window.close();
                    return 4;
                }
            }

            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    if (mouseInside(patientButton, window)) { window.close(); return 1; }
                    if (mouseInside(doctorButton, window)) { window.close(); return 2; }
                    if (mouseInside(adminButton, window)) { window.close(); return 3; }
                    if (mouseInside(exitButton, window)) { window.close(); return 4; }
                }
            }
        }

        patientButton.setFillColor(mouseInside(patientButton, window)
            ? sf::Color(255, 90, 100) : sf::Color(220, 45, 55));
        doctorButton.setFillColor(mouseInside(doctorButton, window)
            ? sf::Color(80, 220, 130) : sf::Color(35, 170, 85));
        adminButton.setFillColor(mouseInside(adminButton, window)
            ? sf::Color(95, 135, 255) : sf::Color(55, 95, 220));
        exitButton.setFillColor(mouseInside(exitButton, window)
            ? sf::Color(220, 95, 235) : sf::Color(175, 55, 190));

        window.clear(sf::Color::Yellow);
        window.draw(background);
        window.draw(header);

        if (fontLoaded)
            drawCentredText(window, font, "MediCore Hospital System",
                36, sf::Color::White, 500.0f, 60.0f);

        window.draw(panel);

        window.draw(patientButton);
        window.draw(doctorButton);
        window.draw(adminButton);
        window.draw(exitButton);

        drawPatientIcon(window, 360.0f, 250.0f);
        drawDoctorIcon(window, 360.0f, 355.0f);
        drawAdminIcon(window, 360.0f, 460.0f);
        drawExitIcon(window, 360.0f, 565.0f);

        if (fontLoaded) {
            drawCentredText(window, font, "Patient", 26, sf::Color::White, 510.0f, 248.0f);
            drawCentredText(window, font, "Doctor", 26, sf::Color::White, 510.0f, 353.0f);
            drawCentredText(window, font, "Admin", 26, sf::Color::White, 510.0f, 458.0f);
            drawCentredText(window, font, "Exit", 26, sf::Color::White, 510.0f, 563.0f);
        }

        window.display();
    }

    return 4;
}

int main() {
    int selectedRole = runSfmlMainMenu();

    if (selectedRole >= 1 && selectedRole <= 3) {
        HospitalSystem system;
        system.runSelectedRole(selectedRole);
    }

    return 0;
}