#include "Doctor.h"
#include "Text.h"
#include <iomanip>
#include <fstream>

using namespace std;

Doctor::Doctor() : Person() {
    Text::copy(specialization, "", 51);
    fee = 0.0;
}

Doctor::Doctor(int doctorId, const char doctorName[], const char doctorSpec[],
    const char doctorContact[], const char doctorPassword[], double doctorFee)
    : Person(doctorId, doctorName, doctorContact, doctorPassword)
{
    Text::copy(specialization, doctorSpec, 51);
    fee = doctorFee;
}

Doctor::~Doctor() {}

void Doctor::display() const {
    cout << id << " | " << name << " | " << specialization << " | " << contact
        << " | PKR " << fixed << setprecision(2) << fee << endl;
}

const char* Doctor::roleName()          const { return "Doctor"; }
const char* Doctor::getSpecialization() const { return specialization; }
double      Doctor::getFee()            const { return fee; }

bool Doctor::operator==(const Doctor& other) const { return id == other.id; }

ostream& operator<<(ostream& out, const Doctor& d) {
    out << d.id << " | " << d.name << " | " << d.specialization
        << " | " << d.contact << " | PKR " << fixed << setprecision(2) << d.fee;
    return out;
}

bool Doctor::isRoleButtonHovered(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(190.0f, 35.0f);
    box.setPosition(x, y);

    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains((float)mouse.x, (float)mouse.y);
}

void Doctor::drawRoleButton(sf::RenderWindow& window, sf::Font& font,
    float x, float y, bool hovered)
{
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(190.0f, 35.0f);
    box.setPosition(x, y);
    box.setFillColor(hovered ? sf::Color(60, 150, 125) : sf::Color(35, 115, 95));
    box.setOutlineThickness(3.0f);
    box.setOutlineColor(sf::Color(230, 245, 250));
    window.draw(box);

    sf::Text label;
    label.setFont(font);
    label.setString("Doctor");
    label.setCharacterSize(28);
    label.setStyle(sf::Text::Bold);
    label.setFillColor(sf::Color::White);

    sf::FloatRect bounds = label.getLocalBounds();
    label.setOrigin(bounds.left + bounds.width / 2.0f,
        bounds.top + bounds.height / 2.0f);
    label.setPosition(x, y - 2.0f);
    window.draw(label);
}

void Doctor::drawIcon(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape vertical(sf::Vector2f(22.0f, 70.0f));
    vertical.setOrigin(11.0f, 35.0f);
    vertical.setPosition(x, y);
    vertical.setFillColor(sf::Color::White);
    window.draw(vertical);

    sf::RectangleShape horizontal(sf::Vector2f(70.0f, 22.0f));
    horizontal.setOrigin(35.0f, 11.0f);
    horizontal.setPosition(x, y);
    horizontal.setFillColor(sf::Color::White);
    window.draw(horizontal);
}

bool Doctor::runLoginScreen(sf::RenderWindow& window, sf::Font& font,
    char outPassword[], int maxLen)
{
    const float CX = 500.0f;
    const float TOP = 200.0f;

    sf::RectangleShape panel(sf::Vector2f(500.0f, 320.0f));
    panel.setOrigin(250.0f, 160.0f);
    panel.setPosition(CX, TOP + 160.0f);
    panel.setFillColor(sf::Color(20, 35, 28));
    panel.setOutlineThickness(4.0f);
    panel.setOutlineColor(sf::Color(35, 115, 95));

    sf::Text title;
    title.setFont(font);
    title.setString("Doctor Login");
    title.setCharacterSize(34);
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color(60, 180, 140));
    {
        sf::FloatRect b = title.getLocalBounds();
        title.setOrigin(b.left + b.width / 2.0f, b.top + b.height / 2.0f);
    }
    title.setPosition(CX, TOP + 30.0f);

    sf::RectangleShape inputBox(sf::Vector2f(360.0f, 48.0f));
    inputBox.setOrigin(180.0f, 24.0f);
    inputBox.setPosition(CX, TOP + 200.0f);
    inputBox.setFillColor(sf::Color(10, 18, 14));
    inputBox.setOutlineThickness(2.0f);
    inputBox.setOutlineColor(sf::Color(35, 115, 95));

    sf::Text pwLabel;
    pwLabel.setFont(font);
    pwLabel.setString("Password");
    pwLabel.setCharacterSize(20);
    pwLabel.setFillColor(sf::Color(160, 210, 185));
    pwLabel.setPosition(CX - 180.0f, TOP + 162.0f);

    sf::Text pwText;
    pwText.setFont(font);
    pwText.setCharacterSize(22);
    pwText.setFillColor(sf::Color::White);
    pwText.setPosition(CX - 170.0f, TOP + 186.0f);

    sf::RectangleShape loginBtn(sf::Vector2f(200.0f, 52.0f));
    loginBtn.setOrigin(100.0f, 26.0f);
    loginBtn.setPosition(CX, TOP + 280.0f);
    loginBtn.setFillColor(sf::Color(35, 115, 95));
    loginBtn.setOutlineThickness(2.0f);
    loginBtn.setOutlineColor(sf::Color(230, 245, 250));

    sf::Text loginLabel;
    loginLabel.setFont(font);
    loginLabel.setString("Login");
    loginLabel.setCharacterSize(24);
    loginLabel.setStyle(sf::Text::Bold);
    loginLabel.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = loginLabel.getLocalBounds();
        loginLabel.setOrigin(b.left + b.width / 2.0f, b.top + b.height / 2.0f);
    }
    loginLabel.setPosition(CX, TOP + 278.0f);

    char inputBuf[128];
    char maskBuf[128];
    int  inputLen = 0;
    bool active = true;
    for (int i = 0; i < 128; i++) inputBuf[i] = '\0';
    for (int i = 0; i < 128; i++) maskBuf[i] = '\0';

    auto isOver = [&](sf::RectangleShape& s) {
        sf::Vector2i m = sf::Mouse::getPosition(window);
        return s.getGlobalBounds().contains((float)m.x, (float)m.y);
        };

    while (window.isOpen() && active) {
        sf::Event ev;
        while (window.pollEvent(ev)) {

            if (ev.type == sf::Event::Closed) {
                window.close();
                return false;
            }

            if (ev.type == sf::Event::KeyPressed) {
                if (ev.key.code == sf::Keyboard::Escape)  return false;
                if (ev.key.code == sf::Keyboard::Return) { active = false; break; }
                if (ev.key.code == sf::Keyboard::BackSpace && inputLen > 0) {
                    inputLen--;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (ev.type == sf::Event::TextEntered) {
                uint32_t c = ev.text.unicode;
                if (c >= 32 && c < 127 && inputLen < maxLen - 1) {
                    inputBuf[inputLen] = static_cast<char>(c);
                    maskBuf[inputLen] = '*';
                    inputLen++;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (ev.type == sf::Event::MouseButtonPressed) {
                if (ev.mouseButton.button == sf::Mouse::Left && isOver(loginBtn))
                    active = false;
            }
        }

        pwText.setString(maskBuf);
        loginBtn.setFillColor(isOver(loginBtn) ? sf::Color(60, 150, 125)
            : sf::Color(35, 115, 95));

        window.clear(sf::Color(8, 16, 12));
        window.draw(panel);
        window.draw(title);
        window.draw(pwLabel);
        window.draw(inputBox);
        window.draw(pwText);
        window.draw(loginBtn);
        window.draw(loginLabel);
        window.display();
    }

    if (outPassword && maxLen > 0) {
        int i = 0;
        while (i < inputLen && i < maxLen - 1) {
            outPassword[i] = inputBuf[i];
            i++;
        }
        outPassword[i] = '\0';
    }
    return true;
}