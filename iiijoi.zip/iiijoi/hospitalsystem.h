#pragma once
#include <SFML/Graphics.hpp>
#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Prescription.h"
#include "Bill.h"

class HospitalSystem {
private:
    Storage<Patient>      patients;
    Storage<Doctor>       doctors;
    Storage<Admin>        admins;
    Storage<Appointment>  appointments;
    Storage<Prescription> prescriptions;
    Storage<Bill>         bills;

    // ── Internal helpers ──────────────────────────────────────────────────
    void  readLine(const char prompt[], char buffer[], int size);
    int   readMenuChoice(int low, int high);

    const char* patientName(int patientId);
    const char* doctorName(int doctorId);
    const char* doctorSpec(int doctorId);

    Bill* findBillByAppointmentId(int appointmentId);
    bool  appointmentHasPrescription(int appointmentId);
    bool  slotTaken(int doctorId, const char date[], const char slot[]);
    int   displayAvailableSlots(int doctorId, const char date[]);

    void sortAppointmentsByDate(Appointment list[], int count, bool ascending);
    void sortAppointmentsByTime(Appointment list[], int count);
    void sortPrescriptionsByDateDesc(Prescription list[], int count);

    int  unpaidBillCount(int patientId);
    bool hasPendingAppointmentWithDoctor(int doctorId);
    bool patientHasUnpaidBills(int patientId);
    bool patientHasPendingAppointments(int patientId);
    bool doctorHasCompletedAppointmentWithPatient(int doctorId, int patientId);

    // ── SFML login ────────────────────────────────────────────────────────
    Patient* loginPatient(sf::RenderWindow& win);
    Doctor* loginDoctor(sf::RenderWindow& win);
    Admin* loginAdmin(sf::RenderWindow& win);

    // ── SFML patient actions ──────────────────────────────────────────────
    void bookAppointment(Patient* patient, sf::RenderWindow& win);
    void cancelAppointment(Patient* patient, sf::RenderWindow& win);
    void viewMyAppointments(Patient* patient, sf::RenderWindow& win);
    void viewMyMedicalRecords(Patient* patient, sf::RenderWindow& win);
    void viewMyBills(Patient* patient, sf::RenderWindow& win);
    void payBill(Patient* patient, sf::RenderWindow& win);
    void topUpBalance(Patient* patient, sf::RenderWindow& win);
    void patientMenu(Patient* patient, sf::RenderWindow& win);

    // ── SFML doctor actions ───────────────────────────────────────────────
    void viewTodayAppointments(Doctor* doctor, sf::RenderWindow& win);
    void markAppointmentStatus(Doctor* doctor, const char newStatus[], sf::RenderWindow& win);
    void writePrescription(Doctor* doctor, sf::RenderWindow& win);
    void viewPatientMedicalHistory(Doctor* doctor, sf::RenderWindow& win);
    void doctorMenu(Doctor* doctor, sf::RenderWindow& win);

    // ── SFML admin actions ────────────────────────────────────────────────
    void addDoctor(sf::RenderWindow& win);
    void removeDoctor(sf::RenderWindow& win);
    void viewAllPatients(sf::RenderWindow& win);
    void viewAllDoctors(sf::RenderWindow& win);
    void viewAllAppointments(sf::RenderWindow& win);
    void viewUnpaidBills(sf::RenderWindow& win);
    void dischargePatient(sf::RenderWindow& win);
    void generateDailyReport(sf::RenderWindow& win);
    void viewSecurityLog(sf::RenderWindow& win);
    void adminMenu(Admin* admin, sf::RenderWindow& win);

    // ── Legacy terminal stubs (declared to satisfy old call-sites) ────────
    Patient* loginPatient();
    Doctor* loginDoctor();
    Admin* loginAdmin();
    void* loginPerson(const char role[]);

    void bookAppointment(Patient*);
    void cancelAppointment(Patient*);
    void viewMyAppointments(Patient*);
    void viewMyMedicalRecords(Patient*);
    void viewMyBills(Patient*);
    void payBill(Patient*);
    void topUpBalance(Patient*);
    void patientMenu(Patient*);

    void viewTodayAppointments(Doctor*);
    int  displayTodayPendingForDoctor(Doctor*);
    void markAppointmentStatus(Doctor*, const char newStatus[]);
    void writePrescription(Doctor*);
    void viewPatientMedicalHistory(Doctor*);
    void doctorMenu(Doctor*);

    void addDoctor();
    void removeDoctor();
    void viewAllPatients();
    void viewAllDoctors();
    void viewAllAppointments();
    void viewUnpaidBills();
    void dischargePatient();
    void generateDailyReport();
    void adminMenu(Admin*);

public:
    HospitalSystem();
    ~HospitalSystem();

    // Main entry points
    void run();
    void runSelectedRole(int choice);
};