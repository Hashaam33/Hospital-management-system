// HospitalSystem.cpp  — Full SFML GUI (no terminal I/O after main menu)
#include "HospitalSystem.h"
#include "FileHandler.h"
#include "Validator.h"
#include "HospitalException.h"
#include "Text.h"
#include "DateTools.h"
#include <SFML/Graphics.hpp>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
//  Internal GUI helpers (file-scope, not exposed in header)
// ─────────────────────────────────────────────────────────────────────────────
namespace {

    // ── Font loader (shared across all screens) ───────────────────────────────
    static sf::Font  g_font;
    static bool      g_fontLoaded = false;

    void ensureFont() {
        if (g_fontLoaded) return;
        const char* paths[] = {
            "C:\\Windows\\Fonts\\arial.ttf",
            "C:/Windows/Fonts/arial.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "arial.ttf"
        };
        for (auto& p : paths) {
            ifstream f(p, ios::binary);
            if (!f.is_open()) continue;
            f.seekg(0, ios::end);
            size_t sz = (size_t)f.tellg();
            f.seekg(0, ios::beg);
            static char* buf = nullptr;
            delete[] buf;
            buf = new char[sz];
            if (f.read(buf, sz) && g_font.loadFromMemory(buf, sz)) {
                g_fontLoaded = true;
                break;
            }
        }
    }

    // ── Colour palette ─────────────────────────────────────────────────────────
    const sf::Color BG{ 18,  24,  38 };
    const sf::Color PANEL{ 28,  36,  55 };
    const sf::Color ACCENT{ 55, 170, 210 };
    const sf::Color ACCENT2{ 130,  75,  60 };
    const sf::Color GREEN_A{ 35, 115,  95 };
    const sf::Color TEXT_COL{ 220, 235, 255 };
    const sf::Color MUTED{ 110, 130, 160 };
    const sf::Color ERR_COL{ 220,  60,  60 };
    const sf::Color SUCCESS_C{ 60, 200, 110 };
    const sf::Color ROW_EVEN{ 30,  40,  60 };
    const sf::Color ROW_ODD{ 24,  32,  50 };

    // ── sf::Text factory ───────────────────────────────────────────────────────
    sf::Text makeText(const sf::String& s, unsigned sz, sf::Color col,
        float x = 0, float y = 0, bool bold = false)
    {
        ensureFont();
        sf::Text t;
        if (g_fontLoaded) t.setFont(g_font);
        t.setString(s);
        t.setCharacterSize(sz);
        t.setFillColor(col);
        if (bold) t.setStyle(sf::Text::Bold);
        t.setPosition(x, y);
        return t;
    }

    void centreText(sf::Text& t, float cx, float cy) {
        sf::FloatRect b = t.getLocalBounds();
        t.setOrigin(b.left + b.width / 2.f, b.top + b.height / 2.f);
        t.setPosition(cx, cy);
    }

    // ── Button ─────────────────────────────────────────────────────────────────
    struct Button {
        sf::RectangleShape box;
        sf::Text           label;

        Button() {}
        Button(const sf::String& text, float x, float y, float w, float h,
            sf::Color fill = ACCENT, unsigned fontSize = 20)
        {
            box.setSize({ w, h });
            box.setPosition(x, y);
            box.setFillColor(fill);
            box.setOutlineThickness(2.f);
            box.setOutlineColor(sf::Color(80, 110, 160));

            label = makeText(text, fontSize, sf::Color::White);
            sf::FloatRect b = label.getLocalBounds();
            label.setOrigin(b.left + b.width / 2.f, b.top + b.height / 2.f);
            label.setPosition(x + w / 2.f, y + h / 2.f - 2.f);
        }

        bool contains(sf::Vector2i m) const {
            return box.getGlobalBounds().contains((float)m.x, (float)m.y);
        }

        void draw(sf::RenderWindow& w, bool hovered) {
            sf::Color base = box.getFillColor();
            if (hovered) {
                sf::Color h(min(255, (int)base.r + 40),
                    min(255, (int)base.g + 40),
                    min(255, (int)base.b + 40));
                box.setFillColor(h);
            }
            else {
                box.setFillColor(base);
            }
            w.draw(box);
            w.draw(label);
            box.setFillColor(base);   // restore
        }
    };

    // ── TextInput ──────────────────────────────────────────────────────────────
    struct TextInput {
        sf::RectangleShape box;
        char buf[512];
        int  len = 0;
        bool masked = false;  // show asterisks
        bool focused = false;

        TextInput() { buf[0] = '\0'; }
        TextInput(float x, float y, float w, float h, bool mask = false)
            : masked(mask)
        {
            buf[0] = '\0';
            box.setSize({ w, h });
            box.setPosition(x, y);
            box.setFillColor(sf::Color(12, 18, 30));
            box.setOutlineThickness(2.f);
            box.setOutlineColor(MUTED);
        }

        void handleEvent(const sf::Event& ev) {
            if (!focused) return;
            if (ev.type == sf::Event::KeyPressed) {
                if (ev.key.code == sf::Keyboard::BackSpace && len > 0) {
                    buf[--len] = '\0';
                }
            }
            if (ev.type == sf::Event::TextEntered) {
                uint32_t c = ev.text.unicode;
                if (c >= 32 && c < 127 && len < 510) {
                    buf[len++] = (char)c;
                    buf[len] = '\0';
                }
            }
        }

        void draw(sf::RenderWindow& w) {
            box.setOutlineColor(focused ? ACCENT : MUTED);
            w.draw(box);

            sf::String display;
            if (masked) { for (int i = 0; i < len; i++) display += '*'; }
            else { display = buf; }
            if (focused) display += "|";

            sf::Text t = makeText(display, 20, TEXT_COL);
            sf::FloatRect bb = box.getGlobalBounds();
            t.setPosition(bb.left + 10.f, bb.top + (bb.height - 24.f) / 2.f);
            w.draw(t);
        }

        bool contains(sf::Vector2i m) const {
            return box.getGlobalBounds().contains((float)m.x, (float)m.y);
        }

        void clear() { len = 0; buf[0] = '\0'; }
    };

    // ── Panel (rounded-ish rectangle) ──────────────────────────────────────────
    void drawPanel(sf::RenderWindow& w, float x, float y, float ww, float h,
        sf::Color fill = PANEL)
    {
        sf::RectangleShape r({ ww, h });
        r.setPosition(x, y);
        r.setFillColor(fill);
        r.setOutlineThickness(2.f);
        r.setOutlineColor(sf::Color(50, 70, 100));
        w.draw(r);
    }

    // ── Message popup  (blocks until OK clicked) ────────────────────────────────
    void showMessage(sf::RenderWindow& w, const sf::String& msg,
        sf::Color col = TEXT_COL)
    {
        // Draw a modal over whatever is on the window
        while (w.isOpen()) {
            sf::Event ev;
            while (w.pollEvent(ev)) {
                if (ev.type == sf::Event::Closed) { w.close(); return; }
                if (ev.type == sf::Event::KeyPressed &&
                    (ev.key.code == sf::Keyboard::Return ||
                        ev.key.code == sf::Keyboard::Escape)) return;
                if (ev.type == sf::Event::MouseButtonPressed) {
                    // click anywhere dismisses
                    sf::FloatRect r(250, 250, 500, 200);
                    if (r.contains((float)ev.mouseButton.x, (float)ev.mouseButton.y))
                        return;
                }
            }
            // semi-transparent overlay
            sf::RectangleShape overlay({ 1000, 700 });
            overlay.setFillColor(sf::Color(0, 0, 0, 160));
            w.draw(overlay);

            drawPanel(w, 250, 260, 500, 180, sf::Color(30, 40, 60));

            // wrap text manually (simple)
            sf::Text t = makeText(msg, 20, col);
            t.setPosition(270, 290);
            w.draw(t);

            Button ok("OK / Press Enter", 380, 400, 240, 44, GREEN_A, 18);
            sf::Vector2i m = sf::Mouse::getPosition(w);
            ok.draw(w, ok.contains(m));
            w.display();
        }
    }

    // ── Scrollable text list ─────────────────────────────────────────────────────
    struct ScrollList {
        vector<string> lines;
        int   scrollOff = 0;
        float x, y, w, h;
        unsigned fontSize;
        int visible;

        ScrollList(float x, float y, float w, float h, unsigned fs = 18)
            : x(x), y(y), w(w), h(h), fontSize(fs)
        {
            visible = (int)(h / (fs + 8));
        }

        void handleEvent(const sf::Event& ev) {
            if (ev.type == sf::Event::MouseWheelScrolled) {
                scrollOff -= (int)ev.mouseWheelScroll.delta;
                int maxOff = max(0, (int)lines.size() - visible);
                if (scrollOff < 0) scrollOff = 0;
                if (scrollOff > maxOff) scrollOff = maxOff;
            }
        }

        void draw(sf::RenderWindow& win) {
            drawPanel(win, x, y, w, h, sf::Color(20, 28, 45));
            float fy = y + 6;
            for (int i = scrollOff; i < (int)lines.size() && i < scrollOff + visible; i++) {
                sf::RectangleShape row({ w - 4, (float)fontSize + 6 });
                row.setPosition(x + 2, fy);
                row.setFillColor(i % 2 == 0 ? ROW_EVEN : ROW_ODD);
                win.draw(row);

                sf::Text t = makeText(lines[i], fontSize, TEXT_COL, x + 8, fy + 2);
                win.draw(t);
                fy += fontSize + 8;
            }
            // scroll indicator
            if ((int)lines.size() > visible) {
                float ratio = (float)visible / lines.size();
                float barH = h * ratio;
                float barY = y + (h - barH) * ((float)scrollOff / (lines.size() - visible));
                sf::RectangleShape bar({ 6, barH });
                bar.setPosition(x + w - 8, barY);
                bar.setFillColor(ACCENT);
                win.draw(bar);
            }
        }
    };

    // ── Header strip ────────────────────────────────────────────────────────────
    void drawHeader(sf::RenderWindow& w, const sf::String& title,
        sf::Color accent = ACCENT)
    {
        sf::RectangleShape hdr({ 1000, 70 });
        hdr.setFillColor(sf::Color(14, 20, 35));
        hdr.setOutlineThickness(0);
        w.draw(hdr);

        sf::RectangleShape line({ 1000, 3 });
        line.setPosition(0, 67);
        line.setFillColor(accent);
        w.draw(line);

        sf::Text t = makeText("MediCore  |  " + title, 26, accent, 0, 0, true);
        centreText(t, 500, 35);
        w.draw(t);
    }

    // ── Generic form field (label + input box) ─────────────────────────────────
    struct FormField {
        sf::String  label;
        TextInput   input;
        sf::Text    errorText;
        bool        hasError = false;

        FormField() {}
        FormField(const sf::String& lbl, float x, float y, float w, bool mask = false)
            : label(lbl), input(x, y + 24, w, 40, mask)
        {
            errorText = makeText("", 15, ERR_COL, x, y + 66);
        }

        void draw(sf::RenderWindow& win, float y_override = -1) {
            float yy = (y_override >= 0) ? y_override
                : input.box.getPosition().y - 24;
            sf::Text lbl = makeText(label, 17, MUTED, input.box.getPosition().x, yy);
            win.draw(lbl);
            input.draw(win);
            if (hasError) win.draw(errorText);
        }

        void setError(const sf::String& msg) {
            hasError = true;
            errorText.setString(msg);
        }
        void clearError() { hasError = false; errorText.setString(""); }
    };

    // ─────────────────────────────────────────────────────────────────────────────
    //  SFML Login screen
    //  Returns true if login succeeded; fills outId / outPassword
    // ─────────────────────────────────────────────────────────────────────────────
    bool runLoginScreen(sf::RenderWindow& win, const sf::String& role,
        sf::Color accent, char outId[], int idLen,
        char outPassword[], int pwLen)
    {
        TextInput idBox(300, 220, 400, 42);
        TextInput pwBox(300, 320, 400, 42, true);
        idBox.focused = true;

        Button loginBtn("Login", 350, 390, 300, 50, accent);
        Button backBtn("Back", 20, 20, 100, 38, sf::Color(50, 60, 80), 17);

        sf::String errMsg;

        bool doSubmit = false;
        while (win.isOpen()) {
            sf::Event ev;
            doSubmit = false;
            while (win.pollEvent(ev)) {
                if (ev.type == sf::Event::Closed) { win.close(); return false; }
                if (ev.type == sf::Event::KeyPressed) {
                    if (ev.key.code == sf::Keyboard::Escape) return false;
                    if (ev.key.code == sf::Keyboard::Tab) {
                        idBox.focused = !idBox.focused;
                        pwBox.focused = !pwBox.focused;
                    }
                    if (ev.key.code == sf::Keyboard::Return) doSubmit = true;
                }
                if (ev.type == sf::Event::MouseButtonPressed &&
                    ev.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i m{ ev.mouseButton.x, ev.mouseButton.y };
                    idBox.focused = idBox.contains(m);
                    pwBox.focused = pwBox.contains(m);
                    if (backBtn.contains(m)) return false;
                    if (loginBtn.contains(m)) doSubmit = true;
                }
                idBox.handleEvent(ev);
                pwBox.handleEvent(ev);
            }

            if (doSubmit) {
                int i = 0;
                while (i < idBox.len && i < idLen - 1) { outId[i] = idBox.buf[i]; i++; }
                outId[i] = '\0';
                i = 0;
                while (i < pwBox.len && i < pwLen - 1) { outPassword[i] = pwBox.buf[i]; i++; }
                outPassword[i] = '\0';
                return true;
            }

            win.clear(BG);
            drawHeader(win, role + " Login", accent);

            drawPanel(win, 260, 160, 480, 310, PANEL);

            sf::Text idLbl = makeText("Staff / Patient ID", 17, MUTED, 300, 196);
            win.draw(idLbl);
            idBox.draw(win);

            sf::Text pwLbl = makeText("Password", 17, MUTED, 300, 296);
            win.draw(pwLbl);
            pwBox.draw(win);

            if (!errMsg.isEmpty()) {
                sf::Text err = makeText(errMsg, 17, ERR_COL, 300, 365);
                win.draw(err);
            }

            sf::Vector2i mouse = sf::Mouse::getPosition(win);
            loginBtn.draw(win, loginBtn.contains(mouse));
            backBtn.draw(win, backBtn.contains(mouse));

            sf::Text hint = makeText("Tab to switch field  |  Enter to login", 15, MUTED);
            centreText(hint, 500, 460);
            win.draw(hint);

            win.display();
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    //  Generic input-form screen
    //  fields: list of {label, isMasked}
    //  Returns false if user cancelled (Back / Escape)
    //  outValues must have at least fields.size() entries, each char[512]
    // ─────────────────────────────────────────────────────────────────────────────
    struct FieldDef { const char* label; bool masked; };

    bool runFormScreen(sf::RenderWindow& win, const sf::String& title,
        sf::Color accent,
        const vector<FieldDef>& fields,
        vector<string>& outValues,
        const sf::String& submitLabel = "Submit")
    {
        const float FORM_X = 200.f;
        const float START_Y = 100.f;
        const float ROW_H = 90.f;
        const float W = 600.f;

        int n = (int)fields.size();
        vector<TextInput> inputs;
        inputs.reserve(n);
        for (int i = 0; i < n; i++)
            inputs.emplace_back(FORM_X, START_Y + 28 + i * ROW_H, W, 42, fields[i].masked);
        if (n > 0) inputs[0].focused = true;

        Button submitBtn(submitLabel, 280, START_Y + n * ROW_H + 20, 200, 48, accent);
        Button backBtn("Back", 20, 20, 100, 38, sf::Color(50, 60, 80), 17);

        sf::String errMsg;
        int scrollOffset = 0;   // for many fields

        while (win.isOpen()) {
            bool doSubmit = false;
            sf::Event ev;
            while (win.pollEvent(ev)) {
                if (ev.type == sf::Event::Closed) { win.close(); return false; }
                if (ev.type == sf::Event::KeyPressed) {
                    if (ev.key.code == sf::Keyboard::Escape) return false;
                    if (ev.key.code == sf::Keyboard::Tab) {
                        for (int i = 0; i < n; i++) {
                            if (inputs[i].focused) {
                                inputs[i].focused = false;
                                inputs[(i + 1) % n].focused = true;
                                break;
                            }
                        }
                    }
                    if (ev.key.code == sf::Keyboard::Return) doSubmit = true;
                }
                if (ev.type == sf::Event::MouseButtonPressed &&
                    ev.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i m{ ev.mouseButton.x, ev.mouseButton.y };
                    for (auto& inp : inputs) inp.focused = inp.contains(m);
                    if (backBtn.contains(m)) return false;
                    if (submitBtn.contains(m)) doSubmit = true;
                }
                for (auto& inp : inputs) inp.handleEvent(ev);
            }
            if (doSubmit) {
                outValues.clear();
                for (auto& inp : inputs) outValues.push_back(inp.buf);
                return true;
            }

            win.clear(BG);
            drawHeader(win, title, accent);

            // draw fields
            for (int i = 0; i < n; i++) {
                float fy = START_Y + i * ROW_H;
                sf::Text lbl = makeText(fields[i].label, 17, MUTED, FORM_X, fy);
                win.draw(lbl);
                inputs[i].draw(win);
            }

            if (!errMsg.isEmpty()) {
                sf::Text err = makeText(errMsg, 17, ERR_COL, FORM_X, START_Y + n * ROW_H + 5);
                win.draw(err);
            }

            sf::Vector2i mouse = sf::Mouse::getPosition(win);
            submitBtn.draw(win, submitBtn.contains(mouse));
            backBtn.draw(win, backBtn.contains(mouse));

            win.display();
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    //  Menu screen — shows a list of labelled buttons, returns 1-based choice
    //  (0 = back / escape)
    // ─────────────────────────────────────────────────────────────────────────────
    int runMenuScreen(sf::RenderWindow& win, const sf::String& title,
        const vector<sf::String>& items,
        sf::Color accent,
        const sf::String& subtitle = "")
    {
        const float CX = 500.f;
        const float START_Y = 120.f;
        const float BTN_W = 500.f;
        const float BTN_H = 52.f;
        const float GAP = 14.f;

        int n = (int)items.size();
        vector<Button> btns;
        btns.reserve(n);
        for (int i = 0; i < n; i++) {
            float y = START_Y + i * (BTN_H + GAP);
            sf::Color col = (i == n - 1) ? sf::Color(80, 80, 90) : accent;
            btns.emplace_back(items[i], CX - BTN_W / 2, y, BTN_W, BTN_H, col, 20);
        }

        Button backBtn("Back", 20, 20, 100, 38, sf::Color(50, 60, 80), 17);

        while (win.isOpen()) {
            sf::Event ev;
            while (win.pollEvent(ev)) {
                if (ev.type == sf::Event::Closed) { win.close(); return 0; }
                if (ev.type == sf::Event::KeyPressed) {
                    if (ev.key.code == sf::Keyboard::Escape) return 0;
                    // number keys
                    int k = ev.key.code - sf::Keyboard::Num1;
                    if (k >= 0 && k < n) return k + 1;
                    k = ev.key.code - sf::Keyboard::Numpad1;
                    if (k >= 0 && k < n) return k + 1;
                }
                if (ev.type == sf::Event::MouseButtonPressed &&
                    ev.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i m{ ev.mouseButton.x, ev.mouseButton.y };
                    if (backBtn.contains(m)) return 0;
                    for (int i = 0; i < n; i++)
                        if (btns[i].contains(m)) return i + 1;
                }
            }

            win.clear(BG);
            drawHeader(win, title, accent);

            if (!subtitle.isEmpty()) {
                sf::Text sub = makeText(subtitle, 19, MUTED);
                centreText(sub, CX, 90.f);
                win.draw(sub);
            }

            sf::Vector2i mouse = sf::Mouse::getPosition(win);
            for (int i = 0; i < n; i++) btns[i].draw(win, btns[i].contains(mouse));

            backBtn.draw(win, backBtn.contains(mouse));
            win.display();
        }
        return 0;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    //  Table / list screen — show rows, optionally let user pick one by ID
    //  Returns selected ID (or 0 if none / back)
    // ─────────────────────────────────────────────────────────────────────────────
    int runTableScreen(sf::RenderWindow& win, const sf::String& title,
        sf::Color accent,
        const vector<string>& rows,
        const sf::String& header = "",
        const sf::String& promptLabel = "",   // empty = no input
        const sf::String& submitLabel = "Select")
    {
        ScrollList list(20, 120, 960, 460);
        if (!header.isEmpty()) list.lines.push_back(string(header));
        for (auto& r : rows) list.lines.push_back(r);

        TextInput idInput(20, 600, 300, 42);
        Button submitBtn(submitLabel, 340, 598, 220, 46, accent, 19);
        Button backBtn("Back", 20, 20, 100, 38, sf::Color(50, 60, 80), 17);

        bool hasInput = !promptLabel.isEmpty();
        if (hasInput) idInput.focused = true;

        while (win.isOpen()) {
            sf::Event ev;
            while (win.pollEvent(ev)) {
                if (ev.type == sf::Event::Closed) { win.close(); return 0; }
                if (ev.type == sf::Event::KeyPressed) {
                    if (ev.key.code == sf::Keyboard::Escape) return 0;
                    if (ev.key.code == sf::Keyboard::Return && hasInput) {
                        int id = 0;
                        if (Validator::parseId(idInput.buf, id)) return id;
                    }
                }
                if (ev.type == sf::Event::MouseButtonPressed &&
                    ev.mouseButton.button == sf::Mouse::Left)
                {
                    sf::Vector2i m{ ev.mouseButton.x, ev.mouseButton.y };
                    if (backBtn.contains(m)) return 0;
                    if (hasInput) idInput.focused = idInput.contains(m);
                    if (hasInput && submitBtn.contains(m)) {
                        int id = 0;
                        if (Validator::parseId(idInput.buf, id)) return id;
                        return -1;   // invalid
                    }
                }
                list.handleEvent(ev);
                if (hasInput) idInput.handleEvent(ev);
            }

            win.clear(BG);
            drawHeader(win, title, accent);
            list.draw(win);

            if (hasInput) {
                sf::Text lbl = makeText(promptLabel, 17, MUTED, 20, 583);
                win.draw(lbl);
                idInput.draw(win);
                sf::Vector2i m = sf::Mouse::getPosition(win);
                submitBtn.draw(win, submitBtn.contains(m));
            }

            sf::Vector2i m = sf::Mouse::getPosition(win);
            backBtn.draw(win, backBtn.contains(m));
            win.display();
        }
        return 0;
    }

    // ── Helper: open a fresh 1000×700 window (role windows share the same window
    //    object so we reuse the caller's window) ─────────────────────────────────
    void clearWindow(sf::RenderWindow& w) {
        w.clear(BG);
    }

    // ── Helper: format money ────────────────────────────────────────────────────
    string pkr(double v) {
        ostringstream ss;
        ss << "PKR " << fixed << setprecision(2) << v;
        return ss.str();
    }

} // anonymous namespace

// ─────────────────────────────────────────────────────────────────────────────
//  HospitalSystem — SFML implementations
// ─────────────────────────────────────────────────────────────────────────────

HospitalSystem::HospitalSystem() {}
HospitalSystem::~HospitalSystem() {}

// ── readLine / readMenuChoice kept for internal use but never called from GUI
void HospitalSystem::readLine(const char prompt[], char buffer[], int size) {
    (void)prompt; buffer[0] = '\0'; (void)size;
}
int HospitalSystem::readMenuChoice(int, int) { return 0; }

// ─── Helpers ────────────────────────────────────────────────────────────────
const char* HospitalSystem::patientName(int id) {
    Patient* p = patients.findById(id);
    return p ? p->getName() : "Unknown";
}
const char* HospitalSystem::doctorName(int id) {
    Doctor* d = doctors.findById(id);
    return d ? d->getName() : "Unknown";
}
const char* HospitalSystem::doctorSpec(int id) {
    Doctor* d = doctors.findById(id);
    return d ? d->getSpecialization() : "Unknown";
}
Bill* HospitalSystem::findBillByAppointmentId(int aid) {
    for (int i = 0; i < bills.size(); i++)
        if (bills.at(i).getAppointmentId() == aid) return &bills.at(i);
    return nullptr;
}
bool HospitalSystem::appointmentHasPrescription(int aid) {
    for (int i = 0; i < prescriptions.size(); i++)
        if (prescriptions.at(i).getAppointmentId() == aid) return true;
    return false;
}
bool HospitalSystem::slotTaken(int did, const char date[], const char slot[]) {
    Appointment target(0, 0, did, date, slot, "pending");
    for (int i = 0; i < appointments.size(); i++)
        if (target == appointments.at(i)) return true;
    return false;
}
int HospitalSystem::displayAvailableSlots(int, const char*) { return 0; }
void HospitalSystem::sortAppointmentsByDate(Appointment list[], int count, bool asc) {
    for (int i = 0; i < count - 1; i++) for (int j = 0; j < count - i - 1; j++) {
        int l = DateTools::dateKey(list[j].getDate());
        int r = DateTools::dateKey(list[j + 1].getDate());
        bool sw = asc ? l > r:l < r;
        if (l == r) {
            int lt = DateTools::timeKey(list[j].getTimeSlot());
            int rt = DateTools::timeKey(list[j + 1].getTimeSlot());
            sw = asc ? lt > rt : lt < rt;
        }
        if (sw) { Appointment t = list[j]; list[j] = list[j + 1]; list[j + 1] = t; }
    }
}
void HospitalSystem::sortAppointmentsByTime(Appointment list[], int count) {
    for (int i = 0; i < count - 1; i++) for (int j = 0; j < count - i - 1; j++)
        if (DateTools::timeKey(list[j].getTimeSlot()) > DateTools::timeKey(list[j + 1].getTimeSlot()))
        {
            Appointment t = list[j]; list[j] = list[j + 1]; list[j + 1] = t;
        }
}
void HospitalSystem::sortPrescriptionsByDateDesc(Prescription list[], int count) {
    for (int i = 0; i < count - 1; i++) for (int j = 0; j < count - i - 1; j++)
        if (DateTools::dateKey(list[j].getDate()) < DateTools::dateKey(list[j + 1].getDate()))
        {
            Prescription t = list[j]; list[j] = list[j + 1]; list[j + 1] = t;
        }
}
int HospitalSystem::unpaidBillCount(int pid) {
    int c = 0;
    for (int i = 0; i < bills.size(); i++)
        if (bills.at(i).getPatientId() == pid && Text::equals(bills.at(i).getStatus(), "unpaid")) c++;
    return c;
}
bool HospitalSystem::hasPendingAppointmentWithDoctor(int did) {
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.at(i).getDoctorId() == did && Text::equals(appointments.at(i).getStatus(), "pending"))
            return true;
    return false;
}
bool HospitalSystem::patientHasUnpaidBills(int pid) {
    for (int i = 0; i < bills.size(); i++)
        if (bills.at(i).getPatientId() == pid && Text::equals(bills.at(i).getStatus(), "unpaid"))
            return true;
    return false;
}
bool HospitalSystem::patientHasPendingAppointments(int pid) {
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.at(i).getPatientId() == pid && Text::equals(appointments.at(i).getStatus(), "pending"))
            return true;
    return false;
}
bool HospitalSystem::doctorHasCompletedAppointmentWithPatient(int did, int pid) {
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.at(i).getDoctorId() == did && appointments.at(i).getPatientId() == pid
            && Text::equals(appointments.at(i).getStatus(), "completed"))
            return true;
    return false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  LOGIN  (SFML)
// ─────────────────────────────────────────────────────────────────────────────
Patient* HospitalSystem::loginPatient(sf::RenderWindow& win) {
    char idBuf[40], pwBuf[80];
    for (int attempt = 1; attempt <= 3; attempt++) {
        if (!runLoginScreen(win, "Patient", ACCENT, idBuf, 40, pwBuf, 80))
            return nullptr;
        int id = 0;
        if (Validator::parseId(idBuf, id)) {
            Patient* p = patients.findById(id);
            if (p && p->passwordMatches(pwBuf)) {
                FileHandler::appendSecurityEvent("Patient", idBuf, "SUCCESS");
                return p;
            }
        }
        FileHandler::appendSecurityEvent("Patient", idBuf, "FAILED");
        showMessage(win, "Invalid ID or password.\nAttempts left: " +
            sf::String(to_string(3 - attempt)), ERR_COL);
    }
    FileHandler::appendSecurityEvent("Patient", idBuf, "LOCKED");
    showMessage(win, "Account locked after 3 failed attempts.\nContact admin.", ERR_COL);
    return nullptr;
}

Doctor* HospitalSystem::loginDoctor(sf::RenderWindow& win) {
    char idBuf[40], pwBuf[80];
    for (int attempt = 1; attempt <= 3; attempt++) {
        if (!runLoginScreen(win, "Doctor", sf::Color(35, 115, 95), idBuf, 40, pwBuf, 80))
            return nullptr;
        int id = 0;
        if (Validator::parseId(idBuf, id)) {
            Doctor* d = doctors.findById(id);
            if (d && d->passwordMatches(pwBuf)) {
                FileHandler::appendSecurityEvent("Doctor", idBuf, "SUCCESS");
                return d;
            }
        }
        FileHandler::appendSecurityEvent("Doctor", idBuf, "FAILED");
        showMessage(win, "Invalid ID or password.\nAttempts left: " +
            sf::String(to_string(3 - attempt)), ERR_COL);
    }
    FileHandler::appendSecurityEvent("Doctor", idBuf, "LOCKED");
    showMessage(win, "Account locked after 3 failed attempts.", ERR_COL);
    return nullptr;
}

Admin* HospitalSystem::loginAdmin(sf::RenderWindow& win) {
    char idBuf[40], pwBuf[80];
    for (int attempt = 1; attempt <= 3; attempt++) {
        if (!runLoginScreen(win, "Admin", ACCENT2, idBuf, 40, pwBuf, 80))
            return nullptr;
        int id = 0;
        if (Validator::parseId(idBuf, id)) {
            Admin* a = admins.findById(id);
            if (a && a->passwordMatches(pwBuf)) {
                FileHandler::appendSecurityEvent("Admin", idBuf, "SUCCESS");
                return a;
            }
        }
        FileHandler::appendSecurityEvent("Admin", idBuf, "FAILED");
        showMessage(win, "Invalid ID or password.\nAttempts left: " +
            sf::String(to_string(3 - attempt)), ERR_COL);
    }
    FileHandler::appendSecurityEvent("Admin", idBuf, "LOCKED");
    showMessage(win, "Account locked after 3 failed attempts.", ERR_COL);
    return nullptr;
}

// Old terminal stubs (unused in GUI flow)
Patient* HospitalSystem::loginPatient() { return nullptr; }
Doctor* HospitalSystem::loginDoctor() { return nullptr; }
Admin* HospitalSystem::loginAdmin() { return nullptr; }
void* HospitalSystem::loginPerson(const char*) { return nullptr; }

// ─────────────────────────────────────────────────────────────────────────────
//  PATIENT MENU
// ─────────────────────────────────────────────────────────────────────────────
void HospitalSystem::bookAppointment(Patient* patient, sf::RenderWindow& win) {
    // Step 1: pick specialization
    vector<FieldDef> f1 = { {"Specialization (e.g. Cardiology)", false} };
    vector<string> v1;
    if (!runFormScreen(win, "Book Appointment — Step 1: Specialization", ACCENT, f1, v1, "Search Doctors"))
        return;

    // Build doctor list
    vector<string> docRows;
    for (int i = 0; i < doctors.size(); i++)
        if (Text::equalsIgnoreCase(doctors.at(i).getSpecialization(), v1[0].c_str())) {
            ostringstream ss;
            ss << doctors.at(i).getId() << " | " << doctors.at(i).getName()
                << " | " << pkr(doctors.at(i).getFee());
            docRows.push_back(ss.str());
        }
    if (docRows.empty()) {
        showMessage(win, "No doctors found for that specialization.", ERR_COL);
        return;
    }

    int doctorId = runTableScreen(win, "Book Appointment — Step 2: Choose Doctor",
        ACCENT, docRows,
        "ID | Name | Fee",
        "Enter Doctor ID:");
    if (doctorId <= 0) return;
    Doctor* doctor = doctors.findById(doctorId);
    if (!doctor || !Text::equalsIgnoreCase(doctor->getSpecialization(), v1[0].c_str())) {
        showMessage(win, "Doctor not found or wrong specialization.", ERR_COL);
        return;
    }

    // Step 3: date + slot
    const char* SLOTS[8] = { "09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00" };
    vector<FieldDef> f2 = { {"Date (DD-MM-YYYY)", false} };
    vector<string> v2;
    if (!runFormScreen(win, "Book Appointment — Step 3: Date", ACCENT, f2, v2, "Check Slots"))
        return;
    char date[20];
    Text::copy(date, v2[0].c_str(), 20);
    if (!Validator::isDate(date)) {
        showMessage(win, "Invalid date. Use DD-MM-YYYY format and a future date.", ERR_COL);
        return;
    }

    // Show available slots
    vector<string> slotRows;
    for (int i = 0; i < 8; i++) {
        if (!slotTaken(doctorId, date, SLOTS[i]))
            slotRows.push_back(SLOTS[i]);
    }
    if (slotRows.empty()) {
        showMessage(win, "No slots available for that date.", ERR_COL);
        return;
    }

    int slotId = runTableScreen(win, "Book Appointment — Step 4: Choose Slot",
        ACCENT, slotRows, "Available Time Slots",
        "Enter slot exactly (e.g. 09:00):", "Book");
    // slotId here is actually just used as a trigger; re-read input from the form
    // We need the actual slot text — use a form instead:
    vector<FieldDef> f3 = { {"Time Slot (e.g. 09:00)", false} };
    vector<string> v3;
    // pre-populate available list in title
    string slotInfo = "Available: ";
    for (auto& s : slotRows) slotInfo += s + "  ";
    if (!runFormScreen(win, "Book Appointment — Enter Slot\n" + sf::String(slotInfo),
        ACCENT, f3, v3, "Confirm Booking"))
        return;
    char slot[20];
    Text::copy(slot, v3[0].c_str(), 20);
    if (!Validator::isTimeSlot(slot)) {
        showMessage(win, "Invalid time slot.", ERR_COL);
        return;
    }
    if (slotTaken(doctorId, date, slot)) {
        showMessage(win, "That slot is already taken.", ERR_COL);
        return;
    }

    // Check balance
    if (!(*patient >= doctor->getFee())) {
        showMessage(win, "Insufficient balance.\nRequired: " +
            sf::String(pkr(doctor->getFee())) +
            "\nYour balance: " + sf::String(pkr(patient->getBalance())), ERR_COL);
        return;
    }

    *patient -= doctor->getFee();
    FileHandler::updatePatientById(patients, *patient);

    int appId = FileHandler::nextAppointmentId();
    Appointment app(appId, patient->getId(), doctorId, date, slot, "pending");
    FileHandler::appendAppointment(app, appointments);

    int billId = FileHandler::nextBillId();
    Bill bill(billId, patient->getId(), appId, doctor->getFee(), "unpaid", date);
    FileHandler::appendBill(bill, bills);

    showMessage(win, "Appointment booked!\nID: " + sf::String(to_string(appId)) +
        "\nDoctor: " + sf::String(doctor->getName()) +
        "\nDate: " + sf::String(date) + "  " + slot +
        "\nFee deducted: " + sf::String(pkr(doctor->getFee())), SUCCESS_C);
}

void HospitalSystem::cancelAppointment(Patient* patient, sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < appointments.size(); i++) {
        auto& a = appointments.at(i);
        if (a.getPatientId() == patient->getId() && Text::equals(a.getStatus(), "pending")) {
            ostringstream ss;
            ss << a.getId() << " | Dr. " << doctorName(a.getDoctorId())
                << " | " << a.getDate() << " " << a.getTimeSlot();
            rows.push_back(ss.str());
        }
    }
    if (rows.empty()) { showMessage(win, "No pending appointments."); return; }

    int aid = runTableScreen(win, "Cancel Appointment", ACCENT, rows,
        "Appointment ID | Doctor | Date | Time",
        "Enter Appointment ID to cancel:", "Cancel");
    if (aid <= 0) return;
    Appointment* app = appointments.findById(aid);
    if (!app || app->getPatientId() != patient->getId() ||
        !Text::equals(app->getStatus(), "pending")) {
        showMessage(win, "Invalid appointment ID.", ERR_COL);
        return;
    }
    Doctor* doc = doctors.findById(app->getDoctorId());
    double fee = doc ? doc->getFee() : 0.0;
    app->setStatus("cancelled");
    FileHandler::saveAppointments(appointments);
    *patient += fee;
    FileHandler::updatePatientById(patients, *patient);
    Bill* bill = findBillByAppointmentId(aid);
    if (bill) { bill->setStatus("cancelled"); FileHandler::saveBills(bills); }
    showMessage(win, "Appointment cancelled.\nRefund: " + sf::String(pkr(fee)), SUCCESS_C);
}

void HospitalSystem::viewMyAppointments(Patient* patient, sf::RenderWindow& win) {
    Appointment* list = new Appointment[100]; int count = 0;
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.at(i).getPatientId() == patient->getId())
            list[count++] = appointments.at(i);
    if (count == 0) { showMessage(win, "No appointments found."); delete[] list; return; }
    sortAppointmentsByDate(list, count, true);
    vector<string> rows;
    for (int i = 0; i < count; i++) {
        ostringstream ss;
        ss << list[i].getId() << " | Dr." << doctorName(list[i].getDoctorId())
            << " | " << doctorSpec(list[i].getDoctorId())
            << " | " << list[i].getDate() << " " << list[i].getTimeSlot()
            << " | " << list[i].getStatus();
        rows.push_back(ss.str());
    }
    delete[] list;
    runTableScreen(win, "My Appointments", ACCENT, rows, "ID | Doctor | Spec | Date | Time | Status");
}

void HospitalSystem::viewMyMedicalRecords(Patient* patient, sf::RenderWindow& win) {
    Prescription* list = new Prescription[100]; int count = 0;
    for (int i = 0; i < prescriptions.size(); i++)
        if (prescriptions.at(i).getPatientId() == patient->getId())
            list[count++] = prescriptions.at(i);
    if (count == 0) { showMessage(win, "No medical records found."); delete[] list; return; }
    sortPrescriptionsByDateDesc(list, count);
    vector<string> rows;
    for (int i = 0; i < count; i++) {
        ostringstream ss;
        ss << list[i].getDate() << " | Dr." << doctorName(list[i].getDoctorId())
            << " | " << list[i].getMedicines() << " | " << list[i].getNotes();
        rows.push_back(ss.str());
    }
    delete[] list;
    runTableScreen(win, "My Medical Records", ACCENT, rows, "Date | Doctor | Medicines | Notes");
}

void HospitalSystem::viewMyBills(Patient* patient, sf::RenderWindow& win) {
    vector<string> rows;
    double total = 0;
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() != patient->getId()) continue;
        ostringstream ss;
        ss << bills.at(i).getId() << " | Appt#" << bills.at(i).getAppointmentId()
            << " | " << pkr(bills.at(i).getAmount())
            << " | " << bills.at(i).getStatus() << " | " << bills.at(i).getDate();
        rows.push_back(ss.str());
        if (Text::equals(bills.at(i).getStatus(), "unpaid")) total += bills.at(i).getAmount();
    }
    if (rows.empty()) { showMessage(win, "No bills found."); return; }
    rows.push_back("─── Total outstanding unpaid: " + pkr(total) + " ───");
    runTableScreen(win, "My Bills", ACCENT, rows, "BillID | ApptID | Amount | Status | Date");
}

void HospitalSystem::payBill(Patient* patient, sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < bills.size(); i++) {
        auto& b = bills.at(i);
        if (b.getPatientId() != patient->getId() || !Text::equals(b.getStatus(), "unpaid")) continue;
        ostringstream ss;
        ss << b.getId() << " | Appt#" << b.getAppointmentId()
            << " | " << pkr(b.getAmount()) << " | " << b.getDate();
        rows.push_back(ss.str());
    }
    if (rows.empty()) { showMessage(win, "No unpaid bills."); return; }
    int bid = runTableScreen(win, "Pay Bill", ACCENT, rows,
        "BillID | ApptID | Amount | Date",
        "Enter Bill ID to pay:", "Pay");
    if (bid <= 0) return;
    Bill* bill = bills.findById(bid);
    if (!bill || bill->getPatientId() != patient->getId() || !Text::equals(bill->getStatus(), "unpaid")) {
        showMessage(win, "Invalid bill.", ERR_COL); return;
    }
    if (!(*patient >= bill->getAmount())) {
        showMessage(win, "Insufficient balance.\nRequired: " + sf::String(pkr(bill->getAmount())) +
            "\nYours: " + sf::String(pkr(patient->getBalance())), ERR_COL);
        return;
    }
    *patient -= bill->getAmount();
    bill->setStatus("paid");
    char today[11]; DateTools::today(today); bill->setDate(today);
    FileHandler::saveBills(bills);
    FileHandler::updatePatientById(patients, *patient);
    showMessage(win, "Bill paid!\nRemaining balance: " + sf::String(pkr(patient->getBalance())), SUCCESS_C);
}

void HospitalSystem::topUpBalance(Patient* patient, sf::RenderWindow& win) {
    vector<FieldDef> f = { {"Amount to add (PKR)",false} };
    vector<string> v;
    if (!runFormScreen(win, "Top Up Balance", ACCENT, f, v, "Add Funds")) return;
    double amount = 0;
    if (!Validator::parsePositiveFloat(v[0].c_str(), amount)) {
        showMessage(win, "Invalid amount.", ERR_COL); return;
    }
    *patient += amount;
    FileHandler::updatePatientById(patients, *patient);
    showMessage(win, "Balance updated!\nNew balance: " + sf::String(pkr(patient->getBalance())), SUCCESS_C);
}

void HospitalSystem::patientMenu(Patient* patient, sf::RenderWindow& win) {
    while (win.isOpen()) {
        string sub = "Welcome, " + string(patient->getName()) +
            "    Balance: " + pkr(patient->getBalance());
        int choice = runMenuScreen(win, "Patient Dashboard", {
            "1. Book Appointment",
            "2. Cancel Appointment",
            "3. View My Appointments",
            "4. View My Medical Records",
            "5. View My Bills",
            "6. Pay Bill",
            "7. Top Up Balance",
            "8. Logout"
            }, ACCENT, sub);
        if (choice == 0 || choice == 8) return;
        if (choice == 1) bookAppointment(patient, win);
        else if (choice == 2) cancelAppointment(patient, win);
        else if (choice == 3) viewMyAppointments(patient, win);
        else if (choice == 4) viewMyMedicalRecords(patient, win);
        else if (choice == 5) viewMyBills(patient, win);
        else if (choice == 6) payBill(patient, win);
        else if (choice == 7) topUpBalance(patient, win);
    }
}

// Stub old signatures
void HospitalSystem::bookAppointment(Patient*) {}
void HospitalSystem::cancelAppointment(Patient*) {}
void HospitalSystem::viewMyAppointments(Patient*) {}
void HospitalSystem::viewMyMedicalRecords(Patient*) {}
void HospitalSystem::viewMyBills(Patient*) {}
void HospitalSystem::payBill(Patient*) {}
void HospitalSystem::topUpBalance(Patient*) {}
void HospitalSystem::patientMenu(Patient*) {}

// ─────────────────────────────────────────────────────────────────────────────
//  DOCTOR MENU
// ─────────────────────────────────────────────────────────────────────────────
void HospitalSystem::viewTodayAppointments(Doctor* doctor, sf::RenderWindow& win) {
    char today[11]; DateTools::today(today);
    Appointment* list = new Appointment[100]; int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        auto& a = appointments.at(i);
        if (a.getDoctorId() == doctor->getId() && Text::equals(a.getDate(), today))
            list[count++] = a;
    }
    if (count == 0) { showMessage(win, "No appointments today."); delete[] list; return; }
    sortAppointmentsByTime(list, count);
    vector<string> rows;
    for (int i = 0; i < count; i++) {
        ostringstream ss;
        ss << list[i].getId() << " | " << patientName(list[i].getPatientId())
            << " | " << list[i].getTimeSlot() << " | " << list[i].getStatus();
        rows.push_back(ss.str());
    }
    delete[] list;
    runTableScreen(win, "Today's Appointments", sf::Color(35, 115, 95), rows,
        "ApptID | Patient | Time | Status");
}

void HospitalSystem::markAppointmentStatus(Doctor* doctor, const char newStatus[],
    sf::RenderWindow& win)
{
    char today[11]; DateTools::today(today);
    vector<string> rows;
    for (int i = 0; i < appointments.size(); i++) {
        auto& a = appointments.at(i);
        if (a.getDoctorId() == doctor->getId() && Text::equals(a.getDate(), today)
            && Text::equals(a.getStatus(), "pending")) {
            ostringstream ss;
            ss << a.getId() << " | " << patientName(a.getPatientId()) << " | " << a.getTimeSlot();
            rows.push_back(ss.str());
        }
    }
    if (rows.empty()) { showMessage(win, "No pending appointments for today."); return; }
    sf::String label = Text::equals(newStatus, "completed") ? "Mark Complete" : "Mark No-Show";
    int aid = runTableScreen(win, "Mark Appointment — " + label, sf::Color(35, 115, 95), rows,
        "ApptID | Patient | Time", "Enter Appointment ID:", label);
    if (aid <= 0) return;
    Appointment* app = appointments.findById(aid);
    if (!app || app->getDoctorId() != doctor->getId() ||
        !Text::equals(app->getStatus(), "pending") ||
        !Text::equals(app->getDate(), today)) {
        showMessage(win, "Invalid appointment ID.", ERR_COL); return;
    }
    app->setStatus(newStatus);
    FileHandler::saveAppointments(appointments);
    if (Text::equals(newStatus, "no-show")) {
        Bill* bill = findBillByAppointmentId(aid);
        if (bill) { bill->setStatus("cancelled"); FileHandler::saveBills(bills); }
        showMessage(win, "Marked as no-show.", SUCCESS_C);
    }
    else {
        showMessage(win, "Marked as completed.", SUCCESS_C);
    }
}

void HospitalSystem::writePrescription(Doctor* doctor, sf::RenderWindow& win) {
    vector<FieldDef> f1 = { {"Appointment ID (completed only)",false} };
    vector<string> v1;
    if (!runFormScreen(win, "Write Prescription — Step 1", sf::Color(35, 115, 95), f1, v1, "Next")) return;
    int aid = 0;
    if (!Validator::parseId(v1[0].c_str(), aid)) {
        showMessage(win, "Invalid ID.", ERR_COL); return;
    }
    Appointment* app = appointments.findById(aid);
    if (!app || app->getDoctorId() != doctor->getId() || !Text::equals(app->getStatus(), "completed")) {
        showMessage(win, "Appointment not found or not completed.", ERR_COL); return;
    }
    if (appointmentHasPrescription(aid)) {
        showMessage(win, "Prescription already exists for this appointment.", ERR_COL); return;
    }
    vector<FieldDef> f2 = {
        {"Medicines (e.g. Paracetamol 500mg;Amoxicillin 250mg)",false},
        {"Notes",false}
    };
    vector<string> v2;
    if (!runFormScreen(win, "Write Prescription — Step 2", sf::Color(35, 115, 95), f2, v2, "Save")) return;
    int pid = FileHandler::nextPrescriptionId();
    Prescription presc(pid, aid, app->getPatientId(), doctor->getId(),
        app->getDate(), v2[0].c_str(), v2[1].c_str());
    FileHandler::appendPrescription(presc, prescriptions);
    showMessage(win, "Prescription saved.", SUCCESS_C);
}

void HospitalSystem::viewPatientMedicalHistory(Doctor* doctor, sf::RenderWindow& win) {
    vector<FieldDef> f = { {"Patient ID",false} };
    vector<string> v;
    if (!runFormScreen(win, "View Patient Medical History", sf::Color(35, 115, 95), f, v, "View")) return;
    int pid = 0;
    if (!Validator::parseId(v[0].c_str(), pid) || patients.findById(pid) == nullptr ||
        !doctorHasCompletedAppointmentWithPatient(doctor->getId(), pid)) {
        showMessage(win, "Access denied or patient not found.\nYou may only view your own patients.", ERR_COL);
        return;
    }
    Prescription* list = new Prescription[100]; int count = 0;
    for (int i = 0; i < prescriptions.size(); i++) {
        auto& p = prescriptions.at(i);
        if (p.getPatientId() == pid && p.getDoctorId() == doctor->getId())
            list[count++] = p;
    }
    if (count == 0) { showMessage(win, "No records found."); delete[] list; return; }
    sortPrescriptionsByDateDesc(list, count);
    vector<string> rows;
    for (int i = 0; i < count; i++) {
        ostringstream ss;
        ss << list[i].getDate() << " | " << list[i].getMedicines() << " | " << list[i].getNotes();
        rows.push_back(ss.str());
    }
    delete[] list;
    runTableScreen(win, "Patient Medical History", sf::Color(35, 115, 95), rows, "Date | Medicines | Notes");
}

void HospitalSystem::doctorMenu(Doctor* doctor, sf::RenderWindow& win) {
    sf::Color GA = sf::Color(35, 115, 95);
    while (win.isOpen()) {
        string sub = "Dr. " + string(doctor->getName()) + "  |  " + doctor->getSpecialization();
        int choice = runMenuScreen(win, "Doctor Dashboard", {
            "1. View Today's Appointments",
            "2. Mark Appointment Complete",
            "3. Mark Appointment No-Show",
            "4. Write Prescription",
            "5. View Patient Medical History",
            "6. Logout"
            }, GA, sub);
        if (choice == 0 || choice == 6) return;
        if (choice == 1) viewTodayAppointments(doctor, win);
        else if (choice == 2) markAppointmentStatus(doctor, "completed", win);
        else if (choice == 3) markAppointmentStatus(doctor, "no-show", win);
        else if (choice == 4) writePrescription(doctor, win);
        else if (choice == 5) viewPatientMedicalHistory(doctor, win);
    }
}

// Stub old signatures
void HospitalSystem::viewTodayAppointments(Doctor*) {}
void HospitalSystem::markAppointmentStatus(Doctor*, const char*) {}
void HospitalSystem::writePrescription(Doctor*) {}
void HospitalSystem::viewPatientMedicalHistory(Doctor*) {}
void HospitalSystem::doctorMenu(Doctor*) {}
int  HospitalSystem::displayTodayPendingForDoctor(Doctor*) { return 0; }

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN MENU
// ─────────────────────────────────────────────────────────────────────────────
void HospitalSystem::addDoctor(sf::RenderWindow& win) {
    vector<FieldDef> fields = {
        {"Full Name",false},
        {"Specialization",false},
        {"Contact (11 digits)",false},
        {"Password (min 6 chars)",true},
        {"Consultation Fee (PKR)",false}
    };
    vector<string> v;
    if (!runFormScreen(win, "Add Doctor", ACCENT2, fields, v, "Add Doctor")) return;
    if (!Validator::isContact(v[2].c_str())) { showMessage(win, "Invalid contact number.", ERR_COL); return; }
    if (!Validator::isPassword(v[3].c_str())) { showMessage(win, "Password too short (min 6).", ERR_COL); return; }
    double fee = 0;
    if (!Validator::parsePositiveFloat(v[4].c_str(), fee)) { showMessage(win, "Invalid fee.", ERR_COL); return; }
    int id = FileHandler::nextDoctorId();
    Doctor doc(id, v[0].c_str(), v[1].c_str(), v[2].c_str(), v[3].c_str(), fee);
    if (!FileHandler::appendDoctor(doc, doctors)) {
        showMessage(win, "Doctor storage limit reached.", ERR_COL); return;
    }
    showMessage(win, "Doctor added!\nID: " + sf::String(to_string(id)), SUCCESS_C);
}

void HospitalSystem::removeDoctor(sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < doctors.size(); i++) {
        ostringstream ss;
        ss << doctors.at(i).getId() << " | " << doctors.at(i).getName()
            << " | " << doctors.at(i).getSpecialization()
            << " | " << pkr(doctors.at(i).getFee());
        rows.push_back(ss.str());
    }
    if (rows.empty()) { showMessage(win, "No doctors on file."); return; }
    int did = runTableScreen(win, "Remove Doctor", ACCENT2, rows,
        "ID | Name | Specialization | Fee",
        "Enter Doctor ID to remove:", "Remove");
    if (did <= 0) return;
    if (!doctors.findById(did)) { showMessage(win, "Doctor not found.", ERR_COL); return; }
    if (hasPendingAppointmentWithDoctor(did)) {
        showMessage(win, "Cannot remove: doctor has pending appointments.", ERR_COL); return;
    }
    FileHandler::deleteDoctorById(doctors, did);
    showMessage(win, "Doctor removed.", SUCCESS_C);
}

void HospitalSystem::viewAllPatients(sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < patients.size(); i++) {
        auto& p = patients.at(i);
        ostringstream ss;
        ss << p.getId() << " | " << p.getName()
            << " | Age:" << p.getAge() << " | " << p.getGender()
            << " | " << p.getContact()
            << " | " << pkr(p.getBalance())
            << " | Unpaid:" << unpaidBillCount(p.getId());
        rows.push_back(ss.str());
    }
    if (rows.empty()) { showMessage(win, "No patients on file."); return; }
    runTableScreen(win, "All Patients", ACCENT2, rows, "ID | Name | Age | G | Contact | Balance | Unpaid");
}

void HospitalSystem::viewAllDoctors(sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < doctors.size(); i++) {
        ostringstream ss;
        ss << doctors.at(i).getId() << " | " << doctors.at(i).getName()
            << " | " << doctors.at(i).getSpecialization()
            << " | " << doctors.at(i).getContact()
            << " | " << pkr(doctors.at(i).getFee());
        rows.push_back(ss.str());
    }
    if (rows.empty()) { showMessage(win, "No doctors on file."); return; }
    runTableScreen(win, "All Doctors", ACCENT2, rows, "ID | Name | Spec | Contact | Fee");
}

void HospitalSystem::viewAllAppointments(sf::RenderWindow& win) {
    Appointment* list = new Appointment[100]; int count = 0;
    for (int i = 0; i < appointments.size(); i++) list[count++] = appointments.at(i);
    if (count == 0) { showMessage(win, "No appointments."); delete[] list; return; }
    sortAppointmentsByDate(list, count, false);
    vector<string> rows;
    for (int i = 0; i < count; i++) {
        ostringstream ss;
        ss << list[i].getId() << " | " << patientName(list[i].getPatientId())
            << " | Dr." << doctorName(list[i].getDoctorId())
            << " | " << list[i].getDate() << " " << list[i].getTimeSlot()
            << " | " << list[i].getStatus();
        rows.push_back(ss.str());
    }
    delete[] list;
    runTableScreen(win, "All Appointments", ACCENT2, rows, "ID | Patient | Doctor | Date | Time | Status");
}

void HospitalSystem::viewUnpaidBills(sf::RenderWindow& win) {
    vector<string> rows;
    for (int i = 0; i < bills.size(); i++) {
        if (!Text::equals(bills.at(i).getStatus(), "unpaid")) continue;
        ostringstream ss;
        ss << bills.at(i).getId() << " | " << patientName(bills.at(i).getPatientId())
            << " | " << pkr(bills.at(i).getAmount()) << " | " << bills.at(i).getDate();
        if (DateTools::daysBeforeToday(bills.at(i).getDate()) > 7.0) ss << " [OVERDUE]";
        rows.push_back(ss.str());
    }
    if (rows.empty()) { showMessage(win, "No unpaid bills."); return; }
    runTableScreen(win, "Unpaid Bills", ACCENT2, rows, "BillID | Patient | Amount | Date");
}

void HospitalSystem::dischargePatient(sf::RenderWindow& win) {
    vector<FieldDef> f = { {"Patient ID to discharge",false} };
    vector<string> v;
    if (!runFormScreen(win, "Discharge Patient", ACCENT2, f, v, "Discharge")) return;
    int pid = 0;
    if (!Validator::parseId(v[0].c_str(), pid)) { showMessage(win, "Invalid ID.", ERR_COL); return; }
    Patient* patient = patients.findById(pid);
    if (!patient) { showMessage(win, "Patient not found.", ERR_COL); return; }
    if (patientHasUnpaidBills(pid)) { showMessage(win, "Cannot discharge: patient has unpaid bills.", ERR_COL); return; }
    if (patientHasPendingAppointments(pid)) { showMessage(win, "Cannot discharge: patient has pending appointments.", ERR_COL); return; }
    Patient copy = *patient;
    FileHandler::archiveDischargedPatient(copy, appointments, prescriptions, bills);
    FileHandler::deletePatientById(patients, pid);
    FileHandler::deleteAppointmentsByPatientId(appointments, pid);
    FileHandler::deletePrescriptionsByPatientId(prescriptions, pid);
    FileHandler::deleteBillsByPatientId(bills, pid);
    showMessage(win, "Patient discharged and archived.", SUCCESS_C);
}

void HospitalSystem::generateDailyReport(sf::RenderWindow& win) {
    char today[11]; DateTools::today(today);
    int total = 0, pending = 0, completed = 0, noshow = 0, cancelled = 0;
    double revenue = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (!Text::equals(appointments.at(i).getDate(), today)) continue;
        total++;
        const char* s = appointments.at(i).getStatus();
        if (Text::equals(s, "pending")) pending++;
        else if (Text::equals(s, "completed")) completed++;
        else if (Text::equals(s, "no-show")) noshow++;
        else if (Text::equals(s, "cancelled")) cancelled++;
    }
    for (int i = 0; i < bills.size(); i++)
        if (Text::equals(bills.at(i).getStatus(), "paid") && Text::equals(bills.at(i).getDate(), today))
            revenue += bills.at(i).getAmount();

    vector<string> rows;
    ostringstream hdr;
    hdr << "Date: " << today << "  |  Total: " << total
        << "  Pending:" << pending << "  Done:" << completed
        << "  No-show:" << noshow << "  Cancelled:" << cancelled;
    rows.push_back(hdr.str());
    ostringstream rev;
    rev << "Revenue collected today: " << pkr(revenue);
    rows.push_back(rev.str());
    rows.push_back("─── Unpaid balances ───");
    bool anyOwed = false;
    for (int i = 0; i < patients.size(); i++) {
        double owed = 0;
        for (int j = 0; j < bills.size(); j++)
            if (bills.at(j).getPatientId() == patients.at(i).getId()
                && Text::equals(bills.at(j).getStatus(), "unpaid"))
                owed += bills.at(j).getAmount();
        if (owed > 0) {
            rows.push_back(string(patients.at(i).getName()) + " owes " + pkr(owed));
            anyOwed = true;
        }
    }
    if (!anyOwed) rows.push_back("No outstanding unpaid bills.");
    rows.push_back("─── Doctor summary ───");
    for (int i = 0; i < doctors.size(); i++) {
        int dc = 0, dp = 0, dn = 0;
        for (int j = 0; j < appointments.size(); j++) {
            if (appointments.at(j).getDoctorId() != doctors.at(i).getId()) continue;
            if (!Text::equals(appointments.at(j).getDate(), today)) continue;
            const char* s = appointments.at(j).getStatus();
            if (Text::equals(s, "completed")) dc++;
            else if (Text::equals(s, "pending")) dp++;
            else if (Text::equals(s, "no-show")) dn++;
        }
        ostringstream ss;
        ss << doctors.at(i).getName() << " | Done:" << dc << " Pending:" << dp << " NoShow:" << dn;
        rows.push_back(ss.str());
    }
    runTableScreen(win, "Daily Report", ACCENT2, rows, "");
}

void HospitalSystem::viewSecurityLog(sf::RenderWindow& win) {
    vector<string> rows;
    ifstream in("security_log.txt");
    if (!in) { showMessage(win, "Cannot open security log.", ERR_COL); return; }
    char line[500];
    while (in.getline(line, 500))
        if (!Text::isEmpty(line)) rows.push_back(line);
    in.close();
    if (rows.empty()) { showMessage(win, "Security log is empty."); return; }
    runTableScreen(win, "Security Log", ACCENT2, rows, "Timestamp | Role | ID | Result");
}

void HospitalSystem::adminMenu(Admin* admin, sf::RenderWindow& win) {
    while (win.isOpen()) {
        string sub = "Admin: " + string(admin->getName());
        int choice = runMenuScreen(win, "Admin Panel", {
            "1.  Add Doctor",
            "2.  Remove Doctor",
            "3.  View All Patients",
            "4.  View All Doctors",
            "5.  View All Appointments",
            "6.  View Unpaid Bills",
            "7.  Discharge Patient",
            "8.  View Security Log",
            "9.  Generate Daily Report",
            "10. Logout"
            }, ACCENT2, sub);
        if (choice == 0 || choice == 10) return;
        if (choice == 1)  addDoctor(win);
        else if (choice == 2)  removeDoctor(win);
        else if (choice == 3)  viewAllPatients(win);
        else if (choice == 4)  viewAllDoctors(win);
        else if (choice == 5)  viewAllAppointments(win);
        else if (choice == 6)  viewUnpaidBills(win);
        else if (choice == 7)  dischargePatient(win);
        else if (choice == 8)  viewSecurityLog(win);
        else if (choice == 9)  generateDailyReport(win);
    }
}

// Stub old signatures
void HospitalSystem::addDoctor() {}
void HospitalSystem::removeDoctor() {}
void HospitalSystem::viewAllPatients() {}
void HospitalSystem::viewAllDoctors() {}
void HospitalSystem::viewAllAppointments() {}
void HospitalSystem::viewUnpaidBills() {}
void HospitalSystem::dischargePatient() {}
void HospitalSystem::generateDailyReport() {}
void HospitalSystem::adminMenu(Admin*) {}

// ─────────────────────────────────────────────────────────────────────────────
//  runSelectedRole  — opens SFML window, handles login & menu for chosen role
// ─────────────────────────────────────────────────────────────────────────────
void HospitalSystem::runSelectedRole(int choice) {
    try {
        FileHandler::loadAll(patients, doctors, admins, appointments, prescriptions, bills);
    }
    catch (HospitalException& e) {
        // Can't do SFML here if window not open — just return
        return;
    }

    sf::RenderWindow win(sf::VideoMode(1000, 700),
        "MediCore Hospital Management System");
    win.setFramerateLimit(60);
    ensureFont();

    try {
        if (choice == 1) {
            Patient* p = loginPatient(win);
            if (p) patientMenu(p, win);
        }
        else if (choice == 2) {
            Doctor* d = loginDoctor(win);
            if (d) doctorMenu(d, win);
        }
        else if (choice == 3) {
            Admin* a = loginAdmin(win);
            if (a) adminMenu(a, win);
        }
    }
    catch (HospitalException& e) {
        showMessage(win, e.what(), ERR_COL);
    }
}

void HospitalSystem::run() {
    // Legacy entry point — not used in GUI flow
}