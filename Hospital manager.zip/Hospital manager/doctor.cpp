#include "Doctor.h"
#include "Text.h"
#include <iomanip>

using namespace std;

Doctor::Doctor() : Person() {
    Text::copy(specialization, "", 51);
    fee = 0.0;
}

Doctor::Doctor(int doctorId, const char doctorName[], const char doctorSpec[],
    const char doctorContact[], const char doctorPassword[], double doctorFee)
    : Person(doctorId, doctorName, doctorContact, doctorPassword) {
    Text::copy(specialization, doctorSpec, 51);
    fee = doctorFee;
}

void Doctor::display() const {
    cout << id << " | " << name << " | " << specialization << " | " << contact
        << " | PKR " << fixed << setprecision(2) << fee << endl;
}

const char* Doctor::roleName() const {
    return "Doctor";
}

const char* Doctor::getSpecialization() const {
    return specialization;
}

double Doctor::getFee() const {
    return fee;
}

bool Doctor::operator==(const Doctor& other) const {
    return id == other.id;
}

std::ostream& operator<<(std::ostream& out, const Doctor& doctor) {
    out << doctor.id << " | " << doctor.name << " | " << doctor.specialization
        << " | " << doctor.contact << " | PKR " << fixed << setprecision(2) << doctor.fee;
    return out;
}

Doctor::~Doctor() {}
