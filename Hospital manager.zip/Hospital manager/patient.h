#ifndef PATIENT_H
#define PATIENT_H

#include <iostream>
#include "Person.h"

class Patient : public Person {
private:
    int age;
    char gender;
    double balance;
public:
    Patient();
    Patient(int patientId, const char patientName[], int patientAge, char patientGender,
        const char patientContact[], const char patientPassword[], double patientBalance);
    void display() const;
    const char* roleName() const;
    int getAge() const;
    char getGender() const;
    double getBalance() const;
    Patient& operator+=(double amount);
    Patient& operator-=(double amount);
    bool operator==(const Patient& other) const;
    bool operator>=(double amount) const;
    friend std::ostream& operator<<(std::ostream& out, const Patient& patient);
    ~Patient();
};

#endif