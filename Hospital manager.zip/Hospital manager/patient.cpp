#include "Patient.h"
#include "Text.h"
#include <iomanip>

using namespace std;

Patient::Patient() : Person() {
    age = 0;
    gender = 'U';
    balance = 0.0;
}

Patient::Patient(int patientId, const char patientName[], int patientAge, char patientGender,
    const char patientContact[], const char patientPassword[], double patientBalance)
    : Person(patientId, patientName, patientContact, patientPassword) {
    age = patientAge;
    gender = patientGender;
    balance = patientBalance;
}

void Patient::display() const {
    cout << id << " | " << name << " | " << age << " | " << gender << " | "
        << contact << " | PKR " << fixed << setprecision(2) << balance << endl;
}

const char* Patient::roleName() const {
    return "Patient";
}

int Patient::getAge() const {
    return age;
}

char Patient::getGender() const {
    return gender;
}

double Patient::getBalance() const {
    return balance;
}

Patient& Patient::operator+=(double amount) {
    balance += amount;
    return *this;
}

Patient& Patient::operator-=(double amount) {
    balance -= amount;
    return *this;
}

bool Patient::operator==(const Patient& other) const {
    return id == other.id;
}

bool Patient::operator>=(double amount) const {
    return balance >= amount;
}

std::ostream& operator<<(std::ostream& out, const Patient& patient) {
    out << patient.id << " | " << patient.name << " | " << patient.age << " | "
        << patient.gender << " | " << patient.contact << " | PKR "
        << fixed << setprecision(2) << patient.balance;
    return out;
}

Patient::~Patient() {}