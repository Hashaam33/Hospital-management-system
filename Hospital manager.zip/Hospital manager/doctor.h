#ifndef DOCTOR_H
#define DOCTOR_H

#include <iostream>
#include "Person.h"

class Doctor : public Person {
private:
    char specialization[51];
    double fee;
public:
    Doctor();
    Doctor(int doctorId, const char doctorName[], const char doctorSpec[],
        const char doctorContact[], const char doctorPassword[], double doctorFee);
    void display() const;
    const char* roleName() const;
    const char* getSpecialization() const;
    double getFee() const;
    bool operator==(const Doctor& other) const;
    friend std::ostream& operator<<(std::ostream& out, const Doctor& doctor);
    ~Doctor();
};

#endif
