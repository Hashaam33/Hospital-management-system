#include "Admin.h"
#include <iostream>

using namespace std;

Admin::Admin() : Person() {}

Admin::Admin(int adminId, const char adminName[], const char adminPassword[])
    : Person(adminId, adminName, "", adminPassword) {}

void Admin::display() const {
    cout << id << " | " << name << endl;
}

const char* Admin::roleName() const {
    return "Admin";
}

Admin::~Admin() {}