#include <SFML/Graphics.hpp>
#include "HospitalSystem.h"
#include <iostream>
#include <fstream>

using namespace std;

class GuiButton {
private:
    sf::RectangleShape box;
    sf::Text text;
    int action;

public:
    GuiButton(sf::Font& font, const char label[], float x, float y, int buttonAction)
        : text(font) {
        action = buttonAction;

        box.setSize(sf::Vector2f(380.0f, 70.0f));
        box.setOrigin(sf::Vector2f(190.0f, 35.0f));
        box.setPosition(sf::Vector2f(x, y));
        box.setFillColor(sf::Color(35, 125, 165));
        box.setOutlineThickness(3.0f);
        box.setOutlineColor(sf::Color(230, 245, 250));

        text.setString(label);
        text.setCharacterSize(28);
        text.setStyle(sf::Text::Bold);
        text.setFillColor(sf::Color::White);

        centerText(x, y - 2.0f);
    }

    void centerText(float x, float y) {
        sf::FloatRect bounds = text.getLocalBounds();

        text.setOrigin(sf::Vector2f(
            bounds.position.x + bounds.size.x / 2.0f,
            bounds.position.y + bounds.size.y / 2.0f
        ));

        text.setPosition(sf::Vector2f(x, y));
    }

    bool isMouseOver(sf::RenderWindow& window) {
        sf::Vector2i mouse = sf::Mouse::getPosition(window);
        return box.getGlobalBounds().contains(sf::Vector2f(mouse.x, mouse.y));
    }

    void update(sf::RenderWindow& window) {
        if (isMouseOver(window)) {
            box.setFillColor(sf::Color(55, 170, 210));
        }
        else {
            box.setFillColor(sf::Color(35, 125, 165));
        }
    }

    void draw(sf::RenderWindow& window) {
        window.draw(box);
        window.draw(text);
    }

    int getAction() { return action; }
};

bool fileExists(const char path[]) {
    ifstream file(path);
    return file.is_open();
}

bool loadFontFromPath(sf::Font& font, const char path[]) {
    if (fileExists(path)) {
        cout << "Attempting to load font: " << path << endl;
        if (font.openFromFile(path)) {
            cout << "Successfully loaded font: " << path << endl;
            return true;
        }
    }
    return false;
}

bool loadAnyFont(sf::Font& font) {
    // Try multiple common font locations
    const char* fontPaths[] = {
        // Current directory
        "fonts/arial.ttf",
        "fonts/Arial.ttf",
        "arial.ttf",
        "Arial.ttf",

        // Common Windows font locations
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/calibri.ttf",

        // Linux font locations
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",

        // macOS font locations
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial.ttf"
    };

    for (const char* path : fontPaths) {
        if (loadFontFromPath(font, path)) {
            return true;
        }
    }

    return false;
}

void centerText(sf::Text& text, float x, float y) {
    sf::FloatRect bounds = text.getLocalBounds();
    text.setOrigin(sf::Vector2f(
        bounds.position.x + bounds.size.x / 2.0f,
        bounds.position.y + bounds.size.y / 2.0f
    ));
    text.setPosition(sf::Vector2f(x, y));
}

int showFontErrorWindow() {
    sf::RenderWindow window(
        sf::VideoMode(sf::Vector2u(850u, 360u)),
        "MediCore - Font Error"
    );

    window.setFramerateLimit(60);

    sf::RectangleShape background;
    background.setSize(sf::Vector2f(850.0f, 360.0f));
    background.setFillColor(sf::Color(120, 25, 35));

    // Create simple shapes for text since we can't load fonts
    sf::RectangleShape messageBox;
    messageBox.setSize(sf::Vector2f(700.0f, 200.0f));
    messageBox.setOrigin(sf::Vector2f(350.0f, 100.0f));
    messageBox.setPosition(sf::Vector2f(425.0f, 180.0f));
    messageBox.setFillColor(sf::Color(40, 40, 40));
    messageBox.setOutlineThickness(2.0f);
    messageBox.setOutlineColor(sf::Color::White);

    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
            if (const sf::Event::KeyPressed* key = event->getIf<sf::Event::KeyPressed>()) {
                if (key->code == sf::Keyboard::Key::Escape || key->code == sf::Keyboard::Key::Enter) {
                    window.close();
                }
            }
        }

        window.clear();
        window.draw(background);
        window.draw(messageBox);
        window.display();
    }

    cout << "\n========== FONT ERROR ==========" << endl;
    cout << "Could not load any font file!" << endl;
    cout << "\nSOLUTIONS:" << endl;
    cout << "1. Create a 'fonts' folder in your project directory" << endl;
    cout << "2. Download a free font (like Arial.ttf) and place it in the fonts folder" << endl;
    cout << "3. For Visual Studio: Set Working Directory to $(ProjectDir)" << endl;
    cout << "   Project Properties > Debugging > Working Directory" << endl;
    cout << "4. Or copy a font file next to your executable" << endl;
    cout << "===============================\n" << endl;

    return 0;
}

int runSfmlMainMenu() {
    sf::RenderWindow window(
        sf::VideoMode(sf::Vector2u(1000u, 700u)),
        "MediCore Hospital Management System"
    );

    window.setFramerateLimit(60);

    sf::Font font;
    if (!loadAnyFont(font)) {
        window.close();
        return showFontErrorWindow();
    }

    sf::RectangleShape background;
    background.setSize(sf::Vector2f(1000.0f, 700.0f));
    background.setFillColor(sf::Color(14, 24, 32));

    sf::RectangleShape header;
    header.setSize(sf::Vector2f(1000.0f, 130.0f));
    header.setFillColor(sf::Color(20, 90, 120));
    header.setPosition(sf::Vector2f(0.0f, 0.0f));

    sf::RectangleShape panel;
    panel.setSize(sf::Vector2f(560.0f, 460.0f));
    panel.setOrigin(sf::Vector2f(280.0f, 230.0f));
    panel.setPosition(sf::Vector2f(500.0f, 405.0f));
    panel.setFillColor(sf::Color(28, 42, 52));
    panel.setOutlineThickness(4.0f);
    panel.setOutlineColor(sf::Color(95, 185, 210));

    sf::Text title(font);
    title.setString("MediCore Hospital");
    title.setCharacterSize(44);
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color::White);
    centerText(title, 500.0f, 62.0f);

    sf::Text subtitle(font);
    subtitle.setString("Hospital Management System");
    subtitle.setCharacterSize(24);
    subtitle.setFillColor(sf::Color(210, 235, 240));
    centerText(subtitle, 500.0f, 105.0f);

    sf::Text chooseText(font);
    chooseText.setString("Login as");
    chooseText.setCharacterSize(30);
    chooseText.setStyle(sf::Text::Bold);
    chooseText.setFillColor(sf::Color(220, 245, 250));
    centerText(chooseText, 500.0f, 205.0f);

    GuiButton buttons[4] = {
        GuiButton(font, "Patient", 500.0f, 285.0f, 1),
        GuiButton(font, "Doctor", 500.0f, 370.0f, 2),
        GuiButton(font, "Admin", 500.0f, 455.0f, 3),
        GuiButton(font, "Exit", 500.0f, 540.0f, 4)
    };

    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return 4;
            }

            if (const sf::Event::KeyPressed* key = event->getIf<sf::Event::KeyPressed>()) {
                if (key->code == sf::Keyboard::Key::Escape) {
                    window.close();
                    return 4;
                }
            }

            if (const sf::Event::MouseButtonPressed* mouseClick = event->getIf<sf::Event::MouseButtonPressed>()) {
                if (mouseClick->button == sf::Mouse::Button::Left) {
                    for (int i = 0; i < 4; i++) {
                        if (buttons[i].isMouseOver(window)) {
                            window.close();
                            return buttons[i].getAction();
                        }
                    }
                }
            }
        }

        for (int i = 0; i < 4; i++) {
            buttons[i].update(window);
        }

        window.clear();
        window.draw(background);
        window.draw(header);
        window.draw(panel);
        window.draw(title);
        window.draw(subtitle);
        window.draw(chooseText);

        for (int i = 0; i < 4; i++) {
            buttons[i].draw(window);
        }

        window.display();
    }

    return 4;
}

int main() {
    cout << "Starting MediCore Hospital Management System..." << endl;

    int selectedRole = runSfmlMainMenu();

    if (selectedRole == 0) {
        cout << "Font loading failed. Exiting..." << endl;
        return 1;
    }

    HospitalSystem system;

    if (selectedRole >= 1 && selectedRole <= 3) {
        cout << "Launching role: " << selectedRole << endl;
        system.runSelectedRole(selectedRole);
    }

    cout << "Thank you for using MediCore!" << endl;
    return 0;
}