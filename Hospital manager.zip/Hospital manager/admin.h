#ifndef ADMIN_H
#define ADMIN_H

#include "Person.h"

class Admin : public Person {
public:
    Admin();
    Admin(int adminId, const char adminName[], const char adminPassword[]);
    void display() const;
    const char* roleName() const;
    ~Admin();

};

#endif
