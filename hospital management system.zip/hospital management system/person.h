#ifndef PERSON_H
#define PERSON_H

class Person {
protected:
    int id;
    char name[51];
    char contact[12];
    char password[51];
public:
    Person();
    Person(int personId, const char personName[], const char personContact[], const char personPassword[]);
    virtual void display() const = 0;
    virtual const char* roleName() const = 0;
    int getId() const;
    const char* getName() const;
    const char* getContact() const;
    const char* getPassword() const;
    bool passwordMatches(const char entered[]) const;
    virtual ~Person();
};

#endif