#include "HospitalException.h"
#include "Text.h"

HospitalException::HospitalException(const char msg[]) {
    Text::copy(message, msg, 200);
}

const char* HospitalException::what() const {
    return message;
}

FileNotFoundException::FileNotFoundException(const char fileName[]) : HospitalException("Required file could not be opened.") {
    Text::append(message, " File: ", 200);
    Text::append(message, fileName, 200);
}

InsufficientFundsException::InsufficientFundsException(const char msg[]) : HospitalException(msg) {}

InvalidInputException::InvalidInputException(const char msg[]) : HospitalException(msg) {}

SlotUnavailableException::SlotUnavailableException(const char msg[]) : HospitalException(msg) {}