#include "Prescription.h"
#include "Text.h"

Prescription::Prescription() {
    id = 0;
    appointmentId = 0;
    patientId = 0;
    doctorId = 0;
    Text::copy(date, "", 11);
    Text::copy(medicines, "", 500);
    Text::copy(notes, "", 300);
}

Prescription::Prescription(int prescriptionId, int appId, int pId, int dId, const char prescriptionDate[],
    const char prescriptionMedicines[], const char prescriptionNotes[]) {
    id = prescriptionId;
    appointmentId = appId;
    patientId = pId;
    doctorId = dId;
    Text::copy(date, prescriptionDate, 11);
    Text::copy(medicines, prescriptionMedicines, 500);
    Text::copy(notes, prescriptionNotes, 300);
}

int Prescription::getId() const {
    return id;
}

int Prescription::getAppointmentId() const {
    return appointmentId;
}

int Prescription::getPatientId() const {
    return patientId;
}

int Prescription::getDoctorId() const {
    return doctorId;
}

const char* Prescription::getDate() const {
    return date;
}

const char* Prescription::getMedicines() const {
    return medicines;
}

const char* Prescription::getNotes() const {
    return notes;
}

Prescription::~Prescription() {}