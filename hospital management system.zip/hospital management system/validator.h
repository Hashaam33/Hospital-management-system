#ifndef VALIDATOR_H
#define VALIDATOR_H

class Validator {
public:
    static bool isDigitsOnly(const char value[]);
    static bool parseId(const char value[], int& outId);
    static bool isDate(const char date[]);
    static bool parseAge(const char value[], int& outAge);
    static bool isGender(const char value[]);
    static bool isTimeSlot(const char slot[]);
    static bool isContact(const char contact[]);
    static bool isPassword(const char password[]);
    static bool isPositiveFloat(const char value[]);
    static bool parsePositiveFloat(const char value[], double& outAmount);
    static bool parseMenuChoice(const char value[], int low, int high, int& outChoice);
};

#endif