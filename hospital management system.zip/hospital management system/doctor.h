#ifndef DOCTOR_H
#define DOCTOR_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include "Person.h"

class Doctor : public Person {
private:
    char   specialization[51];
    double fee;

public:
    Doctor();
    Doctor(int doctorId, const char doctorName[], const char doctorSpec[],
        const char doctorContact[], const char doctorPassword[], double doctorFee);

    void        display()           const;
    const char* roleName()          const;
    const char* getSpecialization() const;
    double      getFee()            const;

    bool operator==(const Doctor& other) const;
    friend std::ostream& operator<<(std::ostream& out, const Doctor& doctor);

    // ── SFML helpers ─────────────────────────────────────────────────────────
    static bool isRoleButtonHovered(sf::RenderWindow& window, float x, float y);
    static void drawRoleButton(sf::RenderWindow& window, sf::Font& font,
        float x, float y, bool hovered);

    // Draw a small cross / medical icon at (x, y)
    static void drawIcon(sf::RenderWindow& window, float x, float y);

    // Full SFML login screen for the Doctor role
    static bool runLoginScreen(sf::RenderWindow& window, sf::Font& font,
        char outPassword[], int maxLen);

    ~Doctor();
};

#endif // DOCTOR_H