#include "Validator.h"
#include "Text.h"
#include "DateTools.h"

bool Validator::isDigitsOnly(const char value[]) {
    if (Text::isEmpty(value)) {
        return false;
    }
    for (int i = 0; value[i] != '\0'; i++) {
        if (value[i] < '0' || value[i] > '9') {
            return false;
        }
    }
    return true;
}

bool Validator::parseId(const char value[], int& outId) {
    if (!isDigitsOnly(value)) {
        return false;
    }
    outId = Text::toIntLoose(value);
    return outId > 0;
}

bool Validator::parseAge(const char value[], int& outAge) {
    if (!isDigitsOnly(value)) {
        return false;
    }
    outAge = Text::toIntLoose(value);
    return outAge > 0 && outAge <= 120;
}

bool Validator::isGender(const char value[]) {
    if (Text::length(value) != 1) {
        return false;
    }
    return value[0] == 'M' || value[0] == 'm' || value[0] == 'F' || value[0] == 'f';
}

bool Validator::isDate(const char date[]) {
    if (Text::length(date) != 10) {
        return false;
    }
    if (date[2] != '-' || date[5] != '-') {
        return false;
    }
    for (int i = 0; i < 10; i++) {
        if (i == 2 || i == 5) {
            continue;
        }
        if (date[i] < '0' || date[i] > '9') {
            return false;
        }
    }
    int d = DateTools::day(date);
    int m = DateTools::month(date);
    int y = DateTools::year(date);
    if (d < 1 || d > 31) {
        return false;
    }
    if (m < 1 || m > 12) {
        return false;
    }
    if (y < DateTools::currentYear()) {
        return false;
    }
    return true;
}

bool Validator::isTimeSlot(const char slot[]) {
    const char* slots[8] = { "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00" };
    for (int i = 0; i < 8; i++) {
        if (Text::equals(slot, slots[i])) {
            return true;
        }
    }
    return false;
}

bool Validator::isContact(const char contact[]) {
    return Text::length(contact) == 11 && isDigitsOnly(contact);
}

bool Validator::isPassword(const char password[]) {
    return Text::length(password) >= 6;
}

bool Validator::isPositiveFloat(const char value[]) {
    if (Text::isEmpty(value)) {
        return false;
    }
    bool hasDigit = false;
    bool hasDot = false;
    for (int i = 0; value[i] != '\0'; i++) {
        if (value[i] == '.') {
            if (hasDot) {
                return false;
            }
            hasDot = true;
        }
        else if (value[i] >= '0' && value[i] <= '9') {
            hasDigit = true;
        }
        else {
            return false;
        }
    }
    return hasDigit && Text::toDoubleLoose(value) > 0.0;
}

bool Validator::parsePositiveFloat(const char value[], double& outAmount) {
    if (!isPositiveFloat(value)) {
        return false;
    }
    outAmount = Text::toDoubleLoose(value);
    return true;
}

bool Validator::parseMenuChoice(const char value[], int low, int high, int& outChoice) {
    if (!isDigitsOnly(value)) {
        return false;
    }
    outChoice = Text::toIntLoose(value);
    return outChoice >= low && outChoice <= high;
}