#include "Patient.h"
#include "Text.h"
#include <iomanip>
#include <fstream>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
//  Constructors / Destructor
// ─────────────────────────────────────────────────────────────────────────────

Patient::Patient() : Person() {
    age = 0;
    gender = 'U';
    balance = 0.0;
}

Patient::Patient(int patientId, const char patientName[], int patientAge,
    char patientGender, const char patientContact[],
    const char patientPassword[], double patientBalance)
    : Person(patientId, patientName, patientContact, patientPassword)
{
    age = patientAge;
    gender = patientGender;
    balance = patientBalance;
}

Patient::~Patient() {}

// ─────────────────────────────────────────────────────────────────────────────
//  Core interface
// ─────────────────────────────────────────────────────────────────────────────

void Patient::display() const {
    cout << id << " | " << name << " | " << age << " | " << gender << " | "
        << contact << " | PKR " << fixed << setprecision(2) << balance << endl;
}

const char* Patient::roleName() const { return "Patient"; }
int         Patient::getAge()     const { return age; }
char        Patient::getGender()  const { return gender; }
double      Patient::getBalance() const { return balance; }

// ─────────────────────────────────────────────────────────────────────────────
//  Operators
// ─────────────────────────────────────────────────────────────────────────────

Patient& Patient::operator+=(double amount) { balance += amount; return *this; }
Patient& Patient::operator-=(double amount) { balance -= amount; return *this; }
bool     Patient::operator==(const Patient& other) const { return id == other.id; }
bool     Patient::operator>=(double amount)         const { return balance >= amount; }

ostream& operator<<(ostream& out, const Patient& p) {
    out << p.id << " | " << p.name << " | " << p.age << " | " << p.gender
        << " | " << p.contact << " | PKR "
        << fixed << setprecision(2) << p.balance;
    return out;
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – hit-test helper
// ─────────────────────────────────────────────────────────────────────────────

bool Patient::isRoleButtonHovered(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(sf::Vector2f(190.0f, 35.0f));
    box.setPosition(sf::Vector2f(x, y));

    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains(sf::Vector2f((float)mouse.x, (float)mouse.y));
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – draw role button (uses arial.ttf via the passed-in font)
// ─────────────────────────────────────────────────────────────────────────────

void Patient::drawRoleButton(sf::RenderWindow& window, sf::Font& font,
    float x, float y, bool hovered)
{
    // Button body
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(sf::Vector2f(190.0f, 35.0f));
    box.setPosition(sf::Vector2f(x, y));
    box.setFillColor(hovered ? sf::Color(55, 170, 210) : sf::Color(35, 125, 165));
    box.setOutlineThickness(3.0f);
    box.setOutlineColor(sf::Color(230, 245, 250));
    window.draw(box);

    // Label  (SFML 3.x constructor: sf::Text(font))
    sf::Text label(font);
    label.setString("Patient");
    label.setCharacterSize(28);
    label.setStyle(sf::Text::Bold);
    label.setFillColor(sf::Color::White);

    sf::FloatRect bounds = label.getLocalBounds();
    label.setOrigin(sf::Vector2f(bounds.position.x + bounds.size.x / 2.0f,
        bounds.position.y + bounds.size.y / 2.0f));
    label.setPosition(sf::Vector2f(x, y - 2.0f));
    window.draw(label);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – small patient silhouette icon
// ─────────────────────────────────────────────────────────────────────────────

void Patient::drawIcon(sf::RenderWindow& window, float x, float y) {
    // Head
    sf::CircleShape head(18.0f);
    head.setOrigin(sf::Vector2f(18.0f, 18.0f));
    head.setPosition(sf::Vector2f(x, y - 14.0f));
    head.setFillColor(sf::Color::White);
    window.draw(head);

    // Body
    sf::RectangleShape body(sf::Vector2f(70.0f, 32.0f));
    body.setOrigin(sf::Vector2f(35.0f, 16.0f));
    body.setPosition(sf::Vector2f(x, y + 24.0f));
    body.setFillColor(sf::Color::White);
    window.draw(body);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – simple login screen for the Patient role
//  Returns true when the user clicks "Login" (password written to outPassword).
//  Returns false when the user closes the window or presses Escape.
// ─────────────────────────────────────────────────────────────────────────────

bool Patient::runLoginScreen(sf::RenderWindow& window, sf::Font& font,
    char outPassword[], int maxLen)
{
    // ── layout constants ────────────────────────────────────────────────────
    const float CX = 500.0f;   // horizontal centre
    const float TOP = 200.0f;

    // Background panel
    sf::RectangleShape panel(sf::Vector2f(500.0f, 320.0f));
    panel.setOrigin(sf::Vector2f(250.0f, 160.0f));
    panel.setPosition(sf::Vector2f(CX, TOP + 160.0f));
    panel.setFillColor(sf::Color(25, 35, 50));
    panel.setOutlineThickness(4.0f);
    panel.setOutlineColor(sf::Color(35, 125, 165));

    // Title
    sf::Text title(font);
    title.setString("Patient Login");
    title.setCharacterSize(34);
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color(55, 170, 210));
    {
        sf::FloatRect b = title.getLocalBounds();
        title.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.0f,
            b.position.y + b.size.y / 2.0f));
    }
    title.setPosition(sf::Vector2f(CX, TOP + 30.0f));

    // Password input box
    sf::RectangleShape inputBox(sf::Vector2f(360.0f, 48.0f));
    inputBox.setOrigin(sf::Vector2f(180.0f, 24.0f));
    inputBox.setPosition(sf::Vector2f(CX, TOP + 200.0f));
    inputBox.setFillColor(sf::Color(15, 20, 30));
    inputBox.setOutlineThickness(2.0f);
    inputBox.setOutlineColor(sf::Color(55, 170, 210));

    // "Password" label
    sf::Text pwLabel(font);
    pwLabel.setString("Password");
    pwLabel.setCharacterSize(20);
    pwLabel.setFillColor(sf::Color(180, 210, 230));
    pwLabel.setPosition(sf::Vector2f(CX - 180.0f, TOP + 162.0f));

    // Echoed password text (masked with asterisks)
    sf::Text pwText(font);
    pwText.setCharacterSize(22);
    pwText.setFillColor(sf::Color::White);
    pwText.setPosition(sf::Vector2f(CX - 170.0f, TOP + 186.0f));

    // Login button
    sf::RectangleShape loginBtn(sf::Vector2f(200.0f, 52.0f));
    loginBtn.setOrigin(sf::Vector2f(100.0f, 26.0f));
    loginBtn.setPosition(sf::Vector2f(CX, TOP + 280.0f));
    loginBtn.setFillColor(sf::Color(35, 125, 165));
    loginBtn.setOutlineThickness(2.0f);
    loginBtn.setOutlineColor(sf::Color(230, 245, 250));

    sf::Text loginLabel(font);
    loginLabel.setString("Login");
    loginLabel.setCharacterSize(24);
    loginLabel.setStyle(sf::Text::Bold);
    loginLabel.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = loginLabel.getLocalBounds();
        loginLabel.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.0f,
            b.position.y + b.size.y / 2.0f));
    }
    loginLabel.setPosition(sf::Vector2f(CX, TOP + 278.0f));

    // ── state (plain char arrays only — no cstring, no string) ─────────────
    char inputBuf[128];
    char maskBuf[128];
    int  inputLen = 0;
    bool active = true;

    for (int i = 0; i < 128; i++) inputBuf[i] = '\0';
    for (int i = 0; i < 128; i++) maskBuf[i] = '\0';

    auto isOver = [&](sf::RectangleShape& s) {
        sf::Vector2i m = sf::Mouse::getPosition(window);
        return s.getGlobalBounds().contains(sf::Vector2f((float)m.x, (float)m.y));
        };

    // ── event loop ──────────────────────────────────────────────────────────
    while (window.isOpen() && active) {
        while (auto ev = window.pollEvent()) {
            if (ev->is<sf::Event::Closed>()) {
                window.close();
                return false;
            }

            if (const sf::Event::KeyPressed* kp = ev->getIf<sf::Event::KeyPressed>()) {
                if (kp->code == sf::Keyboard::Key::Escape) return false;
                if (kp->code == sf::Keyboard::Key::Enter) { active = false; break; }
                if (kp->code == sf::Keyboard::Key::Backspace && inputLen > 0) {
                    inputLen--;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (const sf::Event::TextEntered* te = ev->getIf<sf::Event::TextEntered>()) {
                uint32_t c = te->unicode;
                if (c >= 32 && c < 127 && inputLen < maxLen - 1) {
                    inputBuf[inputLen] = static_cast<char>(c);
                    maskBuf[inputLen] = '*';
                    inputLen++;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (const sf::Event::MouseButtonPressed* mb =
                ev->getIf<sf::Event::MouseButtonPressed>()) {
                if (mb->button == sf::Mouse::Button::Left && isOver(loginBtn))
                    active = false;
            }
        }

        // maskBuf is kept in sync above — pass directly, no std::string needed
        pwText.setString(maskBuf);

        loginBtn.setFillColor(isOver(loginBtn) ? sf::Color(55, 170, 210)
            : sf::Color(35, 125, 165));

        window.clear(sf::Color(10, 14, 22));
        window.draw(panel);
        window.draw(title);
        window.draw(pwLabel);
        window.draw(inputBox);
        window.draw(pwText);
        window.draw(loginBtn);
        window.draw(loginLabel);
        window.display();
    }

    // ── copy result char-by-char (no strncpy) ───────────────────────────────
    if (outPassword && maxLen > 0) {
        int i = 0;
        while (i < inputLen && i < maxLen - 1) {
            outPassword[i] = inputBuf[i];
            i++;
        }
        outPassword[i] = '\0';
    }
    return true;
}