#ifndef BILL_H
#define BILL_H

class Bill {
private:
    int id;
    int patientId;
    int appointmentId;
    double amount;
    char status[16];
    char date[11];
public:
    Bill();
    Bill(int billId, int pId, int appId, double billAmount, const char billStatus[], const char billDate[]);
    int getId() const;
    int getPatientId() const;
    int getAppointmentId() const;
    double getAmount() const;
    const char* getStatus() const;
    const char* getDate() const;
    void setStatus(const char newStatus[]);
    void setDate(const char newDate[]);
    ~Bill();
};

#endif
