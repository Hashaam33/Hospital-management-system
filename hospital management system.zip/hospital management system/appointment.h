#ifndef APPOINTMENT_H
#define APPOINTMENT_H

#include <iostream>

class Appointment {
private:
    int id;
    int patientId;
    int doctorId;
    char date[11];
    char timeSlot[6];
    char status[16];
public:
    Appointment();
    Appointment(int appointmentId, int pId, int dId, const char appointmentDate[],
        const char slot[], const char appointmentStatus[]);
    int getId() const;
    int getPatientId() const;
    int getDoctorId() const;
    const char* getDate() const;
    const char* getTimeSlot() const;
    const char* getStatus() const;
    void setStatus(const char newStatus[]);
    bool isCancelled() const;
    bool operator==(const Appointment& other) const;
    friend std::ostream& operator<<(std::ostream& out, const Appointment& appointment);
    ~Appointment();
};

#endif
