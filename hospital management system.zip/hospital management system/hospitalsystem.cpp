#include "HospitalSystem.h"
#include "FileHandler.h"
#include "Validator.h"
#include "HospitalException.h"
#include "Text.h"
#include "DateTools.h"
#include <iostream>
#include <iomanip>

using namespace std;

void HospitalSystem::readLine(const char prompt[], char buffer[], int size) {
    cout << prompt;
    cin.getline(buffer, size);
    if (cin.fail()) {
        cin.clear();
        cin.ignore(10000, '\n');
    }
}

int HospitalSystem::readMenuChoice(int low, int high) {
    char input[20];
    int choice = 0;
    while (true) {
        readLine("Enter choice: ", input, 20);
        if (Validator::parseMenuChoice(input, low, high, choice)) {
            return choice;
        }
        cout << "Invalid choice." << endl;
    }
}

Patient* HospitalSystem::loginPatient() {
    return (Patient*)loginPerson("Patient");
}

Doctor* HospitalSystem::loginDoctor() {
    return (Doctor*)loginPerson("Doctor");
}

Admin* HospitalSystem::loginAdmin() {
    return (Admin*)loginPerson("Admin");
}

void* HospitalSystem::loginPerson(const char role[]) {
    char idInput[40];
    char passwordInput[80];
    for (int attempt = 1; attempt <= 3; attempt++) {
        readLine("Enter ID: ", idInput, 40);
        readLine("Enter password: ", passwordInput, 80);

        int id = 0;
        bool validId = Validator::parseId(idInput, id);
        if (validId) {
            if (Text::equals(role, "Patient")) {
                Patient* p = patients.findById(id);
                if (p != 0 && p->passwordMatches(passwordInput)) {
                    return p;
                }
            }
            else if (Text::equals(role, "Doctor")) {
                Doctor* d = doctors.findById(id);
                if (d != 0 && d->passwordMatches(passwordInput)) {
                    return d;
                }
            }
            else {
                Admin* a = admins.findById(id);
                if (a != 0 && a->passwordMatches(passwordInput)) {
                    return a;
                }
            }
        }

        FileHandler::appendSecurityEvent(role, idInput, "FAILED");
        cout << "Invalid ID or password." << endl;
    }
    FileHandler::appendSecurityEvent(role, idInput, "LOCKED");
    cout << "Account locked. Contact admin." << endl;
    return 0;
}

const char* HospitalSystem::patientName(int patientId) {
    Patient* p = patients.findById(patientId);
    if (p == 0) {
        return "Unknown";
    }
    return p->getName();
}

const char* HospitalSystem::doctorName(int doctorId) {
    Doctor* d = doctors.findById(doctorId);
    if (d == 0) {
        return "Unknown";
    }
    return d->getName();
}

const char* HospitalSystem::doctorSpec(int doctorId) {
    Doctor* d = doctors.findById(doctorId);
    if (d == 0) {
        return "Unknown";
    }
    return d->getSpecialization();
}

Bill* HospitalSystem::findBillByAppointmentId(int appointmentId) {
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getAppointmentId() == appointmentId) {
            return &bills.at(i);
        }
    }
    return 0;
}

bool HospitalSystem::appointmentHasPrescription(int appointmentId) {
    for (int i = 0; i < prescriptions.size(); i++) {
        if (prescriptions.at(i).getAppointmentId() == appointmentId) {
            return true;
        }
    }
    return false;
}

bool HospitalSystem::slotTaken(int doctorId, const char date[], const char slot[]) {
    Appointment target(0, 0, doctorId, date, slot, "pending");
    for (int i = 0; i < appointments.size(); i++) {
        if (target == appointments.at(i)) {
            return true;
        }
    }
    return false;
}

int HospitalSystem::displayAvailableSlots(int doctorId, const char date[]) {
    const char* slots[8] = { "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00" };
    int available = 0;
    cout << "Available slots: ";
    for (int i = 0; i < 8; i++) {
        if (!slotTaken(doctorId, date, slots[i])) {
            cout << slots[i] << " ";
            available++;
        }
    }
    cout << endl;
    return available;
}

void HospitalSystem::sortAppointmentsByDate(Appointment list[], int count, bool ascending) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            int left = DateTools::dateKey(list[j].getDate());
            int right = DateTools::dateKey(list[j + 1].getDate());
            bool swapNeeded = ascending ? left > right : left < right;
            if (left == right) {
                int lt = DateTools::timeKey(list[j].getTimeSlot());
                int rt = DateTools::timeKey(list[j + 1].getTimeSlot());
                swapNeeded = ascending ? lt > rt : lt < rt;
            }
            if (swapNeeded) {
                Appointment temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] = temp;
            }
        }
    }
}

void HospitalSystem::sortAppointmentsByTime(Appointment list[], int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (DateTools::timeKey(list[j].getTimeSlot()) > DateTools::timeKey(list[j + 1].getTimeSlot())) {
                Appointment temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] = temp;
            }
        }
    }
}

void HospitalSystem::sortPrescriptionsByDateDesc(Prescription list[], int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (DateTools::dateKey(list[j].getDate()) < DateTools::dateKey(list[j + 1].getDate())) {
                Prescription temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] = temp;
            }
        }
    }
}

int HospitalSystem::unpaidBillCount(int patientId) {
    int count = 0;
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() == patientId && Text::equals(bills.at(i).getStatus(), "unpaid")) {
            count++;
        }
    }
    return count;
}

bool HospitalSystem::hasPendingAppointmentWithDoctor(int doctorId) {
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getDoctorId() == doctorId && Text::equals(appointments.at(i).getStatus(), "pending")) {
            return true;
        }
    }
    return false;
}

bool HospitalSystem::patientHasUnpaidBills(int patientId) {
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() == patientId && Text::equals(bills.at(i).getStatus(), "unpaid")) {
            return true;
        }
    }
    return false;
}

bool HospitalSystem::patientHasPendingAppointments(int patientId) {
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getPatientId() == patientId && Text::equals(appointments.at(i).getStatus(), "pending")) {
            return true;
        }
    }
    return false;
}

bool HospitalSystem::doctorHasCompletedAppointmentWithPatient(int doctorId, int patientId) {
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getDoctorId() == doctorId
            && appointments.at(i).getPatientId() == patientId
            && Text::equals(appointments.at(i).getStatus(), "completed")) {
            return true;
        }
    }
    return false;
}

void HospitalSystem::bookAppointment(Patient* patient) {
    char spec[60];
    readLine("Enter specialization to search (e.g. Cardiology): ", spec, 60);

    int found = 0;
    for (int i = 0; i < doctors.size(); i++) {
        if (Text::equalsIgnoreCase(doctors.at(i).getSpecialization(), spec)) {
            cout << doctors.at(i).getId() << " | " << doctors.at(i).getName()
                << " | PKR " << fixed << setprecision(2) << doctors.at(i).getFee() << endl;
            found++;
        }
    }
    if (found == 0) {
        cout << "No doctors available for that specialization." << endl;
        return;
    }

    char input[40];
    int doctorId = 0;
    readLine("Enter Doctor ID: ", input, 40);
    if (!Validator::parseId(input, doctorId) || doctors.findById(doctorId) == 0) {
        cout << "Doctor not found." << endl;
        return;
    }
    Doctor* doctor = doctors.findById(doctorId);

    char date[20];
    bool validDate = false;
    for (int attempt = 1; attempt <= 3; attempt++) {
        readLine("Enter date (DD-MM-YYYY): ", date, 20);
        if (Validator::isDate(date)) {
            validDate = true;
            break;
        }
        cout << "Invalid date. Use format DD-MM-YYYY." << endl;
    }
    if (!validDate) {
        return;
    }

    if (displayAvailableSlots(doctorId, date) == 0) {
        cout << "No slots available for selected doctor/date." << endl;
        return;
    }

    char slot[20];
    while (true) {
        readLine("Enter time slot (e.g. 09:00): ", slot, 20);
        if (!Validator::isTimeSlot(slot)) {
            cout << "Invalid time slot." << endl;
            displayAvailableSlots(doctorId, date);
            continue;
        }
        try {
            if (slotTaken(doctorId, date, slot)) {
                throw SlotUnavailableException();
            }
            break;
        }
        catch (HospitalException& e) {
            cout << e.what() << endl;
            displayAvailableSlots(doctorId, date);
        }
    }

    try {
        if (!((*patient) >= doctor->getFee())) {
            throw InsufficientFundsException();
        }
        (*patient) -= doctor->getFee();
        FileHandler::updatePatientById(patients, *patient);

        int appointmentId = FileHandler::nextAppointmentId();
        Appointment appointment(appointmentId, patient->getId(), doctorId, date, slot, "pending");
        if (!FileHandler::appendAppointment(appointment, appointments)) {
            cout << "Appointment storage limit reached." << endl;
            return;
        }

        int billId = FileHandler::nextBillId();
        Bill bill(billId, patient->getId(), appointmentId, doctor->getFee(), "unpaid", date);
        if (!FileHandler::appendBill(bill, bills)) {
            cout << "Bill storage limit reached." << endl;
            return;
        }

        cout << "Appointment booked successfully. Appointment ID: " << appointmentId << "." << endl;
    }
    catch (HospitalException& e) {
        cout << e.what() << endl;
    }
}

void HospitalSystem::cancelAppointment(Patient* patient) {
    int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getPatientId() == patient->getId()
            && Text::equals(appointments.at(i).getStatus(), "pending")) {
            cout << appointments.at(i).getId() << " | " << doctorName(appointments.at(i).getDoctorId())
                << " | " << appointments.at(i).getDate() << " | " << appointments.at(i).getTimeSlot() << endl;
            count++;
        }
    }
    if (count == 0) {
        cout << "You have no pending appointments." << endl;
        return;
    }

    char input[40];
    int appointmentId = 0;
    readLine("Enter Appointment ID to cancel: ", input, 40);
    Appointment* appointment = 0;
    if (Validator::parseId(input, appointmentId)) {
        appointment = appointments.findById(appointmentId);
    }
    if (appointment == 0 || appointment->getPatientId() != patient->getId()
        || !Text::equals(appointment->getStatus(), "pending")) {
        cout << "Invalid appointment ID." << endl;
        return;
    }

    Doctor* doctor = doctors.findById(appointment->getDoctorId());
    double fee = doctor == 0 ? 0.0 : doctor->getFee();
    appointment->setStatus("cancelled");
    FileHandler::saveAppointments(appointments);

    (*patient) += fee;
    FileHandler::updatePatientById(patients, *patient);

    Bill* bill = findBillByAppointmentId(appointmentId);
    if (bill != 0) {
        bill->setStatus("cancelled");
        FileHandler::saveBills(bills);
    }

    cout << "Appointment cancelled. PKR " << fixed << setprecision(2)
        << fee << " refunded to your balance." << endl;
}

void HospitalSystem::viewMyAppointments(Patient* patient) {
    Appointment *list =  new Appointment[100];
    int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getPatientId() == patient->getId()) {
            list[count] = appointments.at(i);
            count++;
        }
    }
    if (count == 0) {
        cout << "No appointments found." << endl;
        delete[] list;
        return;
    }
    sortAppointmentsByDate(list, count, true);
    cout << "ID | Doctor Name | Specialization | Date | Time Slot | Status" << endl;
    for (int i = 0; i < count; i++) {
        cout << list[i].getId() << " | " << doctorName(list[i].getDoctorId())
            << " | " << doctorSpec(list[i].getDoctorId()) << " | " << list[i].getDate()
            << " | " << list[i].getTimeSlot() << " | " << list[i].getStatus() << endl;
    }
    delete[] list;
}

void HospitalSystem::viewMyMedicalRecords(Patient* patient) {
    Prescription *list = new Prescription[100];
    int count = 0;
    for (int i = 0; i < prescriptions.size(); i++) {
        if (prescriptions.at(i).getPatientId() == patient->getId()) {
            list[count] = prescriptions.at(i);
            count++;
        }
    }
    if (count == 0) {
        cout << "No medical records found." << endl;
        delete[] list;
        return;
    }
    sortPrescriptionsByDateDesc(list, count);
    cout << "Date | Doctor Name | Medicines | Notes" << endl;
    for (int i = 0; i < count; i++) {
        cout << list[i].getDate() << " | " << doctorName(list[i].getDoctorId())
            << " | " << list[i].getMedicines() << " | " << list[i].getNotes() << endl;
    }
}

void HospitalSystem::viewMyBills(Patient* patient) {
    int count = 0;
    double total = 0.0;
    cout << "Bill ID | Appointment ID | Amount (PKR) | Status | Date" << endl;
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() == patient->getId()) {
            cout << bills.at(i).getId() << " | " << bills.at(i).getAppointmentId()
                << " | " << fixed << setprecision(2) << bills.at(i).getAmount()
                << " | " << bills.at(i).getStatus() << " | " << bills.at(i).getDate() << endl;
            if (Text::equals(bills.at(i).getStatus(), "unpaid")) {
                total += bills.at(i).getAmount();
            }
            count++;
        }
    }
    if (count == 0) {
        cout << "No bills found." << endl;
        return;
    }
    cout << "Total outstanding unpaid amount: PKR " << fixed << setprecision(2) << total << endl;
}

void HospitalSystem::payBill(Patient* patient) {
    int count = 0;
    cout << "Bill ID | Appointment ID | Amount (PKR) | Date" << endl;
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() == patient->getId() && Text::equals(bills.at(i).getStatus(), "unpaid")) {
            cout << bills.at(i).getId() << " | " << bills.at(i).getAppointmentId() << " | "
                << fixed << setprecision(2) << bills.at(i).getAmount() << " | " << bills.at(i).getDate() << endl;
            count++;
        }
    }
    if (count == 0) {
        cout << "No unpaid bills." << endl;
        return;
    }

    char input[40];
    int billId = 0;
    readLine("Enter Bill ID to pay: ", input, 40);
    Bill* bill = 0;
    if (Validator::parseId(input, billId)) {
        bill = bills.findById(billId);
    }
    if (bill == 0 || bill->getPatientId() != patient->getId() || !Text::equals(bill->getStatus(), "unpaid")) {
        cout << "Invalid bill ID." << endl;
        return;
    }

    try {
        if (!((*patient) >= bill->getAmount())) {
            throw InsufficientFundsException();
        }
        (*patient) -= bill->getAmount();
        bill->setStatus("paid");
        char today[11];
        DateTools::today(today);
        bill->setDate(today);
        FileHandler::saveBills(bills);
        FileHandler::updatePatientById(patients, *patient);
        cout << "Bill paid successfully. Remaining balance: PKR "
            << fixed << setprecision(2) << patient->getBalance() << "." << endl;
    }
    catch (HospitalException& e) {
        cout << e.what() << endl;
    }
}

void HospitalSystem::topUpBalance(Patient* patient) {
    char input[60];
    double amount = 0.0;
    for (int attempt = 1; attempt <= 3; attempt++) {
        readLine("Enter amount to add (PKR): ", input, 60);
        try {
            if (!Validator::parsePositiveFloat(input, amount)) {
                throw InvalidInputException("Invalid amount.");
            }
            (*patient) += amount;
            FileHandler::updatePatientById(patients, *patient);
            cout << "Balance updated. New balance: PKR "
                << fixed << setprecision(2) << patient->getBalance() << "." << endl;
            return;
        }
        catch (HospitalException& e) {
            cout << e.what() << endl;
        }
    }
}

void HospitalSystem::patientMenu(Patient* patient) {
    while (true) {
        cout << endl;
        cout << "Welcome, " << patient->getName() << endl;
        cout << "Balance: PKR " << fixed << setprecision(2) << patient->getBalance() << endl;
        cout << "========================" << endl;
        cout << "1. Book Appointment" << endl;
        cout << "2. Cancel Appointment" << endl;
        cout << "3. View My Appointments" << endl;
        cout << "4. View My Medical Records" << endl;
        cout << "5. View My Bills" << endl;
        cout << "6. Pay Bill" << endl;
        cout << "7. Top Up Balance" << endl;
        cout << "8. Logout" << endl;
        int choice = readMenuChoice(1, 8);
        if (choice == 1) {
            bookAppointment(patient);
        }
        else if (choice == 2) {
            cancelAppointment(patient);
        }
        else if (choice == 3) {
            viewMyAppointments(patient);
        }
        else if (choice == 4) {
            viewMyMedicalRecords(patient);
        }
        else if (choice == 5) {
            viewMyBills(patient);
        }
        else if (choice == 6) {
            payBill(patient);
        }
        else if (choice == 7) {
            topUpBalance(patient);
        }
        else {
            return;
        }
    }
}

void HospitalSystem::viewTodayAppointments(Doctor* doctor) {
    char today[11];
    DateTools::today(today);
    Appointment *list = new Appointment[100];
    int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getDoctorId() == doctor->getId()
            && Text::equals(appointments.at(i).getDate(), today)) {
            list[count] = appointments.at(i);
            count++;
        }
    }
    if (count == 0) {
        cout << "No appointments scheduled for today." << endl;
        delete[] list;
        return;
    }
    sortAppointmentsByTime(list, count);
    cout << "Appointment ID | Patient Name | Time Slot | Status" << endl;
    for (int i = 0; i < count; i++) {
        cout << list[i].getId() << " | " << patientName(list[i].getPatientId())
            << " | " << list[i].getTimeSlot() << " | " << list[i].getStatus() << endl;
    }
}

int HospitalSystem::displayTodayPendingForDoctor(Doctor* doctor) {
    char today[11];
    DateTools::today(today);
    int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getDoctorId() == doctor->getId()
            && Text::equals(appointments.at(i).getDate(), today)
            && Text::equals(appointments.at(i).getStatus(), "pending")) {
            cout << appointments.at(i).getId() << " | " << patientName(appointments.at(i).getPatientId())
                << " | " << appointments.at(i).getTimeSlot() << endl;
            count++;
        }
    }
    return count;
}

void HospitalSystem::markAppointmentStatus(Doctor* doctor, const char newStatus[]) {
    int available = displayTodayPendingForDoctor(doctor);
    if (available == 0) {
        cout << "No pending appointments for today." << endl;
        return;
    }
    char today[11];
    DateTools::today(today);
    char input[40];
    int appointmentId = 0;
    readLine("Enter Appointment ID: ", input, 40);
    Appointment* appointment = 0;
    if (Validator::parseId(input, appointmentId)) {
        appointment = appointments.findById(appointmentId);
    }
    if (appointment == 0 || appointment->getDoctorId() != doctor->getId()
        || !Text::equals(appointment->getStatus(), "pending")
        || !Text::equals(appointment->getDate(), today)) {
        cout << "Invalid appointment ID." << endl;
        return;
    }
    appointment->setStatus(newStatus);
    FileHandler::saveAppointments(appointments);

    if (Text::equals(newStatus, "no-show")) {
        Bill* bill = findBillByAppointmentId(appointmentId);
        if (bill != 0) {
            bill->setStatus("cancelled");
            FileHandler::saveBills(bills);
        }
        cout << "Appointment marked as no-show." << endl;
    }
    else {
        cout << "Appointment marked as completed." << endl;
    }
}

void HospitalSystem::writePrescription(Doctor* doctor) {
    char input[40];
    int appointmentId = 0;
    readLine("Enter Appointment ID: ", input, 40);
    Appointment* appointment = 0;
    if (Validator::parseId(input, appointmentId)) {
        appointment = appointments.findById(appointmentId);
    }
    if (appointment == 0 || appointment->getDoctorId() != doctor->getId()
        || !Text::equals(appointment->getStatus(), "completed")) {
        cout << "Invalid appointment ID." << endl;
        return;
    }
    if (appointmentHasPrescription(appointmentId)) {
        cout << "Prescription already written for this appointment." << endl;
        return;
    }

    char medicines[500];
    char notes[300];
    readLine("Enter medicines (format: MedicineName Dosage; e.g. Paracetamol 500mg;Amoxicillin 250mg): ", medicines, 500);
    readLine("Enter notes (max 300 chars): ", notes, 300);

    int prescriptionId = FileHandler::nextPrescriptionId();
    Prescription prescription(prescriptionId, appointmentId, appointment->getPatientId(),
        doctor->getId(), appointment->getDate(), medicines, notes);
    if (!FileHandler::appendPrescription(prescription, prescriptions)) {
        cout << "Prescription storage limit reached." << endl;
        return;
    }
    cout << "Prescription saved." << endl;
}

void HospitalSystem::viewPatientMedicalHistory(Doctor* doctor) {
    char input[40];
    int patientId = 0;
    readLine("Enter Patient ID: ", input, 40);
    if (!Validator::parseId(input, patientId) || patients.findById(patientId) == 0
        || !doctorHasCompletedAppointmentWithPatient(doctor->getId(), patientId)) {
        cout << "Access denied. You can only view records of your own patients." << endl;
        return;
    }

    Prescription *list = new Prescription[100];
    int count = 0;
    for (int i = 0; i < prescriptions.size(); i++) {
        if (prescriptions.at(i).getPatientId() == patientId
            && prescriptions.at(i).getDoctorId() == doctor->getId()) {
            list[count] = prescriptions.at(i);
            count++;
        }
    }
    if (count == 0) {
        cout << "No medical records found." << endl;
        delete[] list;
        return;
    }
    sortPrescriptionsByDateDesc(list, count);
    cout << "Date | Medicines | Notes" << endl;
    for (int i = 0; i < count; i++) {
        cout << list[i].getDate() << " | " << list[i].getMedicines() << " | " << list[i].getNotes() << endl;
    }
}

void HospitalSystem::doctorMenu(Doctor* doctor) {
    while (true) {
        cout << endl;
        cout << "Welcome, Dr. " << doctor->getName() << "  |  Specialization: "
            << doctor->getSpecialization() << endl;
        cout << "===============================================" << endl;
        cout << "1. View Today's Appointments" << endl;
        cout << "2. Mark Appointment Complete" << endl;
        cout << "3. Mark Appointment No-Show" << endl;
        cout << "4. Write Prescription" << endl;
        cout << "5. View Patient Medical History" << endl;
        cout << "6. Logout" << endl;
        int choice = readMenuChoice(1, 6);
        if (choice == 1) {
            viewTodayAppointments(doctor);
        }
        else if (choice == 2) {
            markAppointmentStatus(doctor, "completed");
        }
        else if (choice == 3) {
            markAppointmentStatus(doctor, "no-show");
        }
        else if (choice == 4) {
            writePrescription(doctor);
        }
        else if (choice == 5) {
            viewPatientMedicalHistory(doctor);
        }
        else {
            return;
        }
    }
}

void HospitalSystem::addDoctor() {
    char name[51];
    char spec[51];
    char contact[20];
    char password[60];
    char feeInput[40];
    double fee = 0.0;

    readLine("Enter name (max 50 chars): ", name, 51);
    readLine("Enter specialization (max 50 chars): ", spec, 51);
    while (true) {
        readLine("Enter contact (11 digits): ", contact, 20);
        if (Validator::isContact(contact)) {
            break;
        }
        cout << "Invalid contact number." << endl;
    }
    while (true) {
        readLine("Enter password (minimum 6 characters): ", password, 60);
        if (Validator::isPassword(password)) {
            break;
        }
        cout << "Invalid password." << endl;
    }
    while (true) {
        readLine("Enter consultation fee: ", feeInput, 40);
        if (Validator::parsePositiveFloat(feeInput, fee)) {
            break;
        }
        cout << "Invalid fee." << endl;
    }

    int id = FileHandler::nextDoctorId();
    Doctor doctor(id, name, spec, contact, password, fee);
    if (!FileHandler::appendDoctor(doctor, doctors)) {
        cout << "Doctor storage limit reached." << endl;
        return;
    }
    cout << "Doctor added successfully. ID: " << id << "." << endl;
}

void HospitalSystem::removeDoctor() {
    cout << "ID | Name | Specialization | Fee" << endl;
    for (int i = 0; i < doctors.size(); i++) {
        cout << doctors.at(i).getId() << " | " << doctors.at(i).getName()
            << " | " << doctors.at(i).getSpecialization() << " | PKR "
            << fixed << setprecision(2) << doctors.at(i).getFee() << endl;
    }
    char input[40];
    int doctorId = 0;
    readLine("Enter Doctor ID to remove: ", input, 40);
    if (!Validator::parseId(input, doctorId) || doctors.findById(doctorId) == 0) {
        cout << "Doctor not found." << endl;
        return;
    }
    if (hasPendingAppointmentWithDoctor(doctorId)) {
        cout << "Cannot remove doctor with pending appointments. Cancel or reassign them first." << endl;
        return;
    }
    FileHandler::deleteDoctorById(doctors, doctorId);
    cout << "Doctor removed." << endl;
}

void HospitalSystem::viewAllPatients() {
    cout << "ID | Name | Age | Gender | Contact | Balance | Count of unpaid bills" << endl;
    for (int i = 0; i < patients.size(); i++) {
        cout << patients.at(i).getId() << " | " << patients.at(i).getName()
            << " | " << patients.at(i).getAge() << " | " << patients.at(i).getGender()
            << " | " << patients.at(i).getContact() << " | PKR "
            << fixed << setprecision(2) << patients.at(i).getBalance()
            << " | " << unpaidBillCount(patients.at(i).getId()) << endl;
    }
}

void HospitalSystem::viewAllDoctors() {
    cout << "ID | Name | Specialization | Contact | Fee" << endl;
    for (int i = 0; i < doctors.size(); i++) {
        cout << doctors.at(i) << endl;
    }
}

void HospitalSystem::viewAllAppointments() {
    Appointment *list = new Appointment[100];
    int count = 0;
    for (int i = 0; i < appointments.size(); i++) {
        list[count] = appointments.at(i);
        count++;
    }
    if (count == 0) {
        cout << "No appointments found." << endl;
        delete[] list;
        return;
    }
    sortAppointmentsByDate(list, count, false);
    cout << "ID | Patient Name | Doctor Name | Date | Time Slot | Status" << endl;
    for (int i = 0; i < count; i++) {
        cout << list[i].getId() << " | " << patientName(list[i].getPatientId())
            << " | " << doctorName(list[i].getDoctorId()) << " | " << list[i].getDate()
            << " | " << list[i].getTimeSlot() << " | " << list[i].getStatus() << endl;
    }
}

void HospitalSystem::viewUnpaidBills() {
    int count = 0;
    cout << "Bill ID | Patient Name | Amount (PKR) | Date" << endl;
    for (int i = 0; i < bills.size(); i++) {
        if (Text::equals(bills.at(i).getStatus(), "unpaid")) {
            cout << bills.at(i).getId() << " | " << patientName(bills.at(i).getPatientId())
                << " | " << fixed << setprecision(2) << bills.at(i).getAmount()
                << " | " << bills.at(i).getDate();
            if (DateTools::daysBeforeToday(bills.at(i).getDate()) > 7.0) {
                cout << " [OVERDUE]";
            }
            cout << endl;
            count++;
        }
    }
    if (count == 0) {
        cout << "No unpaid bills." << endl;
    }
}

void HospitalSystem::dischargePatient() {
    char input[40];
    int patientId = 0;
    readLine("Enter Patient ID: ", input, 40);
    Patient* patient = 0;
    if (Validator::parseId(input, patientId)) {
        patient = patients.findById(patientId);
    }
    if (patient == 0) {
        cout << "Patient not found." << endl;
        return;
    }
    if (patientHasUnpaidBills(patientId)) {
        cout << "Cannot discharge patient with unpaid bills." << endl;
        return;
    }
    if (patientHasPendingAppointments(patientId)) {
        cout << "Cannot discharge patient with pending appointments." << endl;
        return;
    }

    Patient copy = *patient;
    FileHandler::archiveDischargedPatient(copy, appointments, prescriptions, bills);
    FileHandler::deletePatientById(patients, patientId);
    FileHandler::deleteAppointmentsByPatientId(appointments, patientId);
    FileHandler::deletePrescriptionsByPatientId(prescriptions, patientId);
    FileHandler::deleteBillsByPatientId(bills, patientId);
    cout << "Patient discharged and archived successfully." << endl;
}

void HospitalSystem::generateDailyReport() {
    char today[11];
    DateTools::today(today);
    int total = 0;
    int pending = 0;
    int completed = 0;
    int noshow = 0;
    int cancelled = 0;
    for (int i = 0; i < appointments.size(); i++) {
        if (Text::equals(appointments.at(i).getDate(), today)) {
            total++;
            if (Text::equals(appointments.at(i).getStatus(), "pending")) {
                pending++;
            }
            else if (Text::equals(appointments.at(i).getStatus(), "completed")) {
                completed++;
            }
            else if (Text::equals(appointments.at(i).getStatus(), "no-show")) {
                noshow++;
            }
            else if (Text::equals(appointments.at(i).getStatus(), "cancelled")) {
                cancelled++;
            }
        }
    }

    double revenue = 0.0;
    for (int i = 0; i < bills.size(); i++) {
        if (Text::equals(bills.at(i).getStatus(), "paid") && Text::equals(bills.at(i).getDate(), today)) {
            revenue += bills.at(i).getAmount();
        }
    }

    cout << "Total appointments today: " << total << " (Pending: " << pending
        << " Completed: " << completed << " No-show: " << noshow
        << " Cancelled: " << cancelled << ")" << endl;
    cout << "Revenue collected today (paid bills): PKR " << fixed << setprecision(2) << revenue << endl;

    cout << "Patients with outstanding unpaid bills: Patient Name | Total Owed" << endl;
    bool anyOwed = false;
    for (int i = 0; i < patients.size(); i++) {
        double owed = 0.0;
        for (int j = 0; j < bills.size(); j++) {
            if (bills.at(j).getPatientId() == patients.at(i).getId()
                && Text::equals(bills.at(j).getStatus(), "unpaid")) {
                owed += bills.at(j).getAmount();
            }
        }
        if (owed > 0.0) {
            cout << patients.at(i).getName() << " | PKR " << fixed << setprecision(2) << owed << endl;
            anyOwed = true;
        }
    }
    if (!anyOwed) {
        cout << "None" << endl;
    }

    cout << "Doctor-wise summary for today: Doctor Name | Completed | Pending | No-show" << endl;
    for (int i = 0; i < doctors.size(); i++) {
        int dCompleted = 0;
        int dPending = 0;
        int dNoshow = 0;
        for (int j = 0; j < appointments.size(); j++) {
            if (appointments.at(j).getDoctorId() == doctors.at(i).getId()
                && Text::equals(appointments.at(j).getDate(), today)) {
                if (Text::equals(appointments.at(j).getStatus(), "completed")) {
                    dCompleted++;
                }
                else if (Text::equals(appointments.at(j).getStatus(), "pending")) {
                    dPending++;
                }
                else if (Text::equals(appointments.at(j).getStatus(), "no-show")) {
                    dNoshow++;
                }
            }
        }
        cout << doctors.at(i).getName() << " | " << dCompleted << " | " << dPending << " | " << dNoshow << endl;
    }
}

void HospitalSystem::adminMenu(Admin* admin) {
    while (true) {
        cout << endl;
        cout << "Admin Panel - MediCore" << endl;
        cout << "======================" << endl;
        cout << "1.  Add Doctor" << endl;
        cout << "2.  Remove Doctor" << endl;
        cout << "3.  View All Patients" << endl;
        cout << "4.  View All Doctors" << endl;
        cout << "5.  View All Appointments" << endl;
        cout << "6.  View Unpaid Bills" << endl;
        cout << "7.  Discharge Patient" << endl;
        cout << "8.  View Security Log" << endl;
        cout << "9.  Generate Daily Report" << endl;
        cout << "10. Logout" << endl;
        int choice = readMenuChoice(1, 10);
        if (choice == 1) {
            addDoctor();
        }
        else if (choice == 2) {
            removeDoctor();
        }
        else if (choice == 3) {
            viewAllPatients();
        }
        else if (choice == 4) {
            viewAllDoctors();
        }
        else if (choice == 5) {
            viewAllAppointments();
        }
        else if (choice == 6) {
            viewUnpaidBills();
        }
        else if (choice == 7) {
            dischargePatient();
        }
        else if (choice == 8) {
            FileHandler::displaySecurityLog();
        }
        else if (choice == 9) {
            generateDailyReport();
        }
        else {
            return;
        }
    }
}

void HospitalSystem::run() {
    try {
        FileHandler::loadAll(patients, doctors, admins, appointments, prescriptions, bills);
    }
    catch (HospitalException& e) {
        cout << e.what() << endl;
        return;
    }

    while (true) {
        cout << endl;
        cout << "Welcome to MediCore Hospital Management System" << endl;
        cout << "===============================================" << endl;
        cout << "Login as:" << endl;
        cout << "1. Patient" << endl;
        cout << "2. Doctor" << endl;
        cout << "3. Admin" << endl;
        cout << "4. Exit" << endl;
        int choice = readMenuChoice(1, 4);
        try {
            if (choice == 1) {
                Patient* patient = loginPatient();
                if (patient != 0) {
                    patientMenu(patient);
                }
            }
            else if (choice == 2) {
                Doctor* doctor = loginDoctor();
                if (doctor != 0) {
                    doctorMenu(doctor);
                }
            }
            else if (choice == 3) {
                Admin* admin = loginAdmin();
                if (admin != 0) {
                    adminMenu(admin);
                }
            }
            else {
                cout << "Goodbye." << endl;
                return;
            }
        }
        catch (HospitalException& e) {
            cout << e.what() << endl;
        }
    }
}

void HospitalSystem::runSelectedRole(int choice) {
    try {
        FileHandler::loadAll(patients, doctors, admins, appointments, prescriptions, bills);
    }
    catch (HospitalException& e) {
        cout << e.what() << endl;
        return;
    }

    try {
        if (choice == 1) {
            Patient* patient = loginPatient();
            if (patient != 0) {
                patientMenu(patient);
            }
        }
        else if (choice == 2) {
            Doctor* doctor = loginDoctor();
            if (doctor != 0) {
                doctorMenu(doctor);
            }
        }
        else if (choice == 3) {
            Admin* admin = loginAdmin();
            if (admin != 0) {
                adminMenu(admin);
            }
        }
        else {
            run();
        }
    }
    catch (HospitalException& e) {
        cout << e.what() << endl;
    }
}
HospitalSystem::~HospitalSystem() {}