#ifndef DATETOOLS_H
#define DATETOOLS_H

#include <ctime>

class DateTools {
public:
    static int currentYear();
    static void today(char outDate[]);
    static void timestamp(char outStamp[]);
    static int day(const char date[]);
    static int month(const char date[]);
    static int year(const char date[]);
    static int dateKey(const char date[]);
    static int timeKey(const char slot[]);
    static time_t toTime(const char date[]);
    static double daysBeforeToday(const char date[]);
};

#endif
