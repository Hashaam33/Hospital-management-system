#include "DateTools.h"
#include <ctime>

int DateTools::currentYear() {
    time_t now = time(0);
    tm local{};
    localtime_s(&local, &now);
    return local.tm_year + 1900;
}

void DateTools::today(char outDate[]) {
    time_t now = time(0);
    tm local{};
    localtime_s(&local, &now);
    strftime(outDate, 11, "%d-%m-%Y", &local);
}

void DateTools::timestamp(char outStamp[]) {
    time_t now = time(0);
    tm local{};
    localtime_s(&local, &now);
    strftime(outStamp, 20, "%d-%m-%Y %H:%M:%S", &local);
}

int DateTools::day(const char date[]) {
    return (date[0] - '0') * 10 + (date[1] - '0');
}

int DateTools::month(const char date[]) {
    return (date[3] - '0') * 10 + (date[4] - '0');
}

int DateTools::year(const char date[]) {
    return (date[6] - '0') * 1000 + (date[7] - '0') * 100 + (date[8] - '0') * 10 + (date[9] - '0');
}

int DateTools::dateKey(const char date[]) {
    return year(date) * 10000 + month(date) * 100 + day(date);
}

int DateTools::timeKey(const char slot[]) {
    return (slot[0] - '0') * 1000 + (slot[1] - '0') * 100 + (slot[3] - '0') * 10 + (slot[4] - '0');
}

time_t DateTools::toTime(const char date[]) {
    tm value{};
    value.tm_sec = 0;
    value.tm_min = 0;
    value.tm_hour = 0;
    value.tm_mday = day(date);
    value.tm_mon = month(date) - 1;
    value.tm_year = year(date) - 1900;
    value.tm_wday = 0;
    value.tm_yday = 0;
    value.tm_isdst = -1;
    return mktime(&value);
}

double DateTools::daysBeforeToday(const char date[]) {
    char todayDate[11];
    today(todayDate);
    time_t oldDate = toTime(date);
    time_t nowDate = toTime(todayDate);
    return difftime(nowDate, oldDate) / (60.0 * 60.0 * 24.0);
}