#ifndef HOSPITALSYSTEM_H
#define HOSPITALSYSTEM_H

#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Prescription.h"
#include "Bill.h"

class HospitalSystem {
private:
    Storage<Patient> patients;
    Storage<Doctor> doctors;
    Storage<Admin> admins;
    Storage<Appointment> appointments;
    Storage<Prescription> prescriptions;
    Storage<Bill> bills;

    void readLine(const char prompt[], char buffer[], int size);
    int readMenuChoice(int low, int high);
    Patient* loginPatient();
    Doctor* loginDoctor();
    Admin* loginAdmin();
    void* loginPerson(const char role[]);
    const char* patientName(int patientId);
    const char* doctorName(int doctorId);
    const char* doctorSpec(int doctorId);
    Bill* findBillByAppointmentId(int appointmentId);
    bool appointmentHasPrescription(int appointmentId);
    bool slotTaken(int doctorId, const char date[], const char slot[]);
    int displayAvailableSlots(int doctorId, const char date[]);
    void sortAppointmentsByDate(Appointment list[], int count, bool ascending);
    void sortAppointmentsByTime(Appointment list[], int count);
    void sortPrescriptionsByDateDesc(Prescription list[], int count);
    int unpaidBillCount(int patientId);
    bool hasPendingAppointmentWithDoctor(int doctorId);
    bool patientHasUnpaidBills(int patientId);
    bool patientHasPendingAppointments(int patientId);
    bool doctorHasCompletedAppointmentWithPatient(int doctorId, int patientId);
    void bookAppointment(Patient* patient);
    void cancelAppointment(Patient* patient);
    void viewMyAppointments(Patient* patient);
    void viewMyMedicalRecords(Patient* patient);
    void viewMyBills(Patient* patient);
    void payBill(Patient* patient);
    void topUpBalance(Patient* patient);
    void patientMenu(Patient* patient);
    void viewTodayAppointments(Doctor* doctor);
    int displayTodayPendingForDoctor(Doctor* doctor);
    void markAppointmentStatus(Doctor* doctor, const char newStatus[]);
    void writePrescription(Doctor* doctor);
    void viewPatientMedicalHistory(Doctor* doctor);
    void doctorMenu(Doctor* doctor);
    void addDoctor();
    void removeDoctor();
    void viewAllPatients();
    void viewAllDoctors();
    void viewAllAppointments();
    void viewUnpaidBills();
    void dischargePatient();
    void generateDailyReport();
    void adminMenu(Admin* admin);
public:
    void run();
    void runSelectedRole(int choice);
    ~HospitalSystem();
};

#endif