#include "Appointment.h"
#include "Text.h"

Appointment::Appointment() {
    id = 0;
    patientId = 0;
    doctorId = 0;
    Text::copy(date, "", 11);
    Text::copy(timeSlot, "", 6);
    Text::copy(status, "pending", 16);
}

Appointment::Appointment(int appointmentId, int pId, int dId, const char appointmentDate[],
    const char slot[], const char appointmentStatus[]) {
    id = appointmentId;
    patientId = pId;
    doctorId = dId;
    Text::copy(date, appointmentDate, 11);
    Text::copy(timeSlot, slot, 6);
    Text::copy(status, appointmentStatus, 16);
}

int Appointment::getId() const {
    return id;
}

int Appointment::getPatientId() const {
    return patientId;
}

int Appointment::getDoctorId() const {
    return doctorId;
}

const char* Appointment::getDate() const {
    return date;
}

const char* Appointment::getTimeSlot() const {
    return timeSlot;
}

const char* Appointment::getStatus() const {
    return status;
}

void Appointment::setStatus(const char newStatus[]) {
    Text::copy(status, newStatus, 16);
}

bool Appointment::isCancelled() const {
    return Text::equals(status, "cancelled");
}

bool Appointment::operator==(const Appointment& other) const {
    return doctorId == other.doctorId
        && Text::equals(date, other.date)
        && Text::equals(timeSlot, other.timeSlot)
        && !isCancelled()
        && !other.isCancelled();
}

std::ostream& operator<<(std::ostream& out, const Appointment& appointment) {
    out << appointment.id << " | Patient " << appointment.patientId
        << " | Doctor " << appointment.doctorId << " | " << appointment.date
        << " | " << appointment.timeSlot << " | " << appointment.status;
    return out;
}
Appointment::~Appointment() {}