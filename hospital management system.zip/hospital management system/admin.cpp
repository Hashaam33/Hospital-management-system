#include "Admin.h"
#include <iostream>
#include <fstream>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
//  Constructors / Destructor
// ─────────────────────────────────────────────────────────────────────────────

Admin::Admin() : Person() {}

Admin::Admin(int adminId, const char adminName[], const char adminPassword[])
    : Person(adminId, adminName, "", adminPassword) {}

Admin::~Admin() {}

// ─────────────────────────────────────────────────────────────────────────────
//  Core interface
// ─────────────────────────────────────────────────────────────────────────────

void Admin::display() const {
    cout << id << " | " << name << endl;
}

const char* Admin::roleName() const { return "Admin"; }

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – hit-test helper
// ─────────────────────────────────────────────────────────────────────────────

bool Admin::isRoleButtonHovered(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(sf::Vector2f(190.0f, 35.0f));
    box.setPosition(sf::Vector2f(x, y));

    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains(sf::Vector2f((float)mouse.x, (float)mouse.y));
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – draw role button (uses arial.ttf via the passed-in font)
// ─────────────────────────────────────────────────────────────────────────────

void Admin::drawRoleButton(sf::RenderWindow& window, sf::Font& font,
    float x, float y, bool hovered)
{
    sf::RectangleShape box;
    box.setSize(sf::Vector2f(380.0f, 70.0f));
    box.setOrigin(sf::Vector2f(190.0f, 35.0f));
    box.setPosition(sf::Vector2f(x, y));
    box.setFillColor(hovered ? sf::Color(165, 105, 80) : sf::Color(130, 75, 60));
    box.setOutlineThickness(3.0f);
    box.setOutlineColor(sf::Color(230, 245, 250));
    window.draw(box);

    sf::Text label(font);
    label.setString("Admin");
    label.setCharacterSize(28);
    label.setStyle(sf::Text::Bold);
    label.setFillColor(sf::Color::White);

    sf::FloatRect bounds = label.getLocalBounds();
    label.setOrigin(sf::Vector2f(bounds.position.x + bounds.size.x / 2.0f,
        bounds.position.y + bounds.size.y / 2.0f));
    label.setPosition(sf::Vector2f(x, y - 2.0f));
    window.draw(label);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – shield / admin icon
// ─────────────────────────────────────────────────────────────────────────────

void Admin::drawIcon(sf::RenderWindow& window, float x, float y) {
    // Pentagon-ish shield
    sf::CircleShape shield(42.0f, 5);
    shield.setOrigin(sf::Vector2f(42.0f, 42.0f));
    shield.setPosition(sf::Vector2f(x, y));
    shield.setFillColor(sf::Color::White);
    window.draw(shield);

    // Inner accent circle
    sf::CircleShape center(16.0f);
    center.setOrigin(sf::Vector2f(16.0f, 16.0f));
    center.setPosition(sf::Vector2f(x, y));
    center.setFillColor(sf::Color(130, 75, 60));
    window.draw(center);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SFML – login screen for the Admin role
// ─────────────────────────────────────────────────────────────────────────────

bool Admin::runLoginScreen(sf::RenderWindow& window, sf::Font& font,
    char outPassword[], int maxLen)
{
    const float CX = 500.0f;
    const float TOP = 200.0f;

    // Panel
    sf::RectangleShape panel(sf::Vector2f(500.0f, 320.0f));
    panel.setOrigin(sf::Vector2f(250.0f, 160.0f));
    panel.setPosition(sf::Vector2f(CX, TOP + 160.0f));
    panel.setFillColor(sf::Color(35, 22, 18));
    panel.setOutlineThickness(4.0f);
    panel.setOutlineColor(sf::Color(130, 75, 60));

    // Title
    sf::Text title(font);
    title.setString("Admin Login");
    title.setCharacterSize(34);
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color(200, 130, 100));
    {
        sf::FloatRect b = title.getLocalBounds();
        title.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.0f,
            b.position.y + b.size.y / 2.0f));
    }
    title.setPosition(sf::Vector2f(CX, TOP + 30.0f));

    // Input box
    sf::RectangleShape inputBox(sf::Vector2f(360.0f, 48.0f));
    inputBox.setOrigin(sf::Vector2f(180.0f, 24.0f));
    inputBox.setPosition(sf::Vector2f(CX, TOP + 200.0f));
    inputBox.setFillColor(sf::Color(18, 10, 8));
    inputBox.setOutlineThickness(2.0f);
    inputBox.setOutlineColor(sf::Color(130, 75, 60));

    sf::Text pwLabel(font);
    pwLabel.setString("Password");
    pwLabel.setCharacterSize(20);
    pwLabel.setFillColor(sf::Color(210, 170, 150));
    pwLabel.setPosition(sf::Vector2f(CX - 180.0f, TOP + 162.0f));

    sf::Text pwText(font);
    pwText.setCharacterSize(22);
    pwText.setFillColor(sf::Color::White);
    pwText.setPosition(sf::Vector2f(CX - 170.0f, TOP + 186.0f));

    // Login button
    sf::RectangleShape loginBtn(sf::Vector2f(200.0f, 52.0f));
    loginBtn.setOrigin(sf::Vector2f(100.0f, 26.0f));
    loginBtn.setPosition(sf::Vector2f(CX, TOP + 280.0f));
    loginBtn.setFillColor(sf::Color(130, 75, 60));
    loginBtn.setOutlineThickness(2.0f);
    loginBtn.setOutlineColor(sf::Color(230, 245, 250));

    sf::Text loginLabel(font);
    loginLabel.setString("Login");
    loginLabel.setCharacterSize(24);
    loginLabel.setStyle(sf::Text::Bold);
    loginLabel.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = loginLabel.getLocalBounds();
        loginLabel.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.0f,
            b.position.y + b.size.y / 2.0f));
    }
    loginLabel.setPosition(sf::Vector2f(CX, TOP + 278.0f));

    // ── Input state (plain char arrays only) ────────────────────────────────
    char inputBuf[128];
    int  inputLen = 0;
    bool active = true;

    // Zero-initialise manually (no memset / no cstring)
    for (int i = 0; i < 128; i++) inputBuf[i] = '\0';

    // Mask buffer: mirrors inputBuf but stores '*' instead of actual chars
    char maskBuf[128];
    for (int i = 0; i < 128; i++) maskBuf[i] = '\0';

    auto isOver = [&](sf::RectangleShape& s) {
        sf::Vector2i m = sf::Mouse::getPosition(window);
        return s.getGlobalBounds().contains(sf::Vector2f((float)m.x, (float)m.y));
        };

    // ── Event loop ──────────────────────────────────────────────────────────
    while (window.isOpen() && active) {
        while (auto ev = window.pollEvent()) {
            if (ev->is<sf::Event::Closed>()) { window.close(); return false; }

            if (const sf::Event::KeyPressed* kp = ev->getIf<sf::Event::KeyPressed>()) {
                if (kp->code == sf::Keyboard::Key::Escape) return false;
                if (kp->code == sf::Keyboard::Key::Enter) { active = false; break; }
                if (kp->code == sf::Keyboard::Key::Backspace && inputLen > 0) {
                    inputLen--;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (const sf::Event::TextEntered* te = ev->getIf<sf::Event::TextEntered>()) {
                uint32_t c = te->unicode;
                if (c >= 32 && c < 127 && inputLen < maxLen - 1) {
                    inputBuf[inputLen] = static_cast<char>(c);
                    maskBuf[inputLen] = '*';
                    inputLen++;
                    inputBuf[inputLen] = '\0';
                    maskBuf[inputLen] = '\0';
                }
            }

            if (const sf::Event::MouseButtonPressed* mb =
                ev->getIf<sf::Event::MouseButtonPressed>()) {
                if (mb->button == sf::Mouse::Button::Left && isOver(loginBtn))
                    active = false;
            }
        }

        // maskBuf is kept in sync with inputBuf above – just set it directly
        pwText.setString(maskBuf);

        loginBtn.setFillColor(isOver(loginBtn) ? sf::Color(165, 105, 80)
            : sf::Color(130, 75, 60));

        window.clear(sf::Color(12, 8, 6));
        window.draw(panel);
        window.draw(title);
        window.draw(pwLabel);
        window.draw(inputBox);
        window.draw(pwText);
        window.draw(loginBtn);
        window.draw(loginLabel);
        window.display();
    }

    // ── Copy result into outPassword (manual char-by-char, no strncpy) ──────
    if (outPassword && maxLen > 0) {
        int i = 0;
        while (i < inputLen && i < maxLen - 1) {
            outPassword[i] = inputBuf[i];
            i++;
        }
        outPassword[i] = '\0';
    }

    return true;
}