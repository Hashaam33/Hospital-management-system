#include "Text.h"

int Text::length(const char value[]) {
    int i = 0;
    while (value[i] != '\0') {
        i++;
    }
    return i;
}

void Text::copy(char dest[], const char src[], int maxSize) {
    if (maxSize <= 0) {
        return;
    }
    int i = 0;
    while (src[i] != '\0' && i < maxSize - 1) {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

void Text::append(char dest[], const char src[], int maxSize) {
    int pos = length(dest);
    int i = 0;
    while (src[i] != '\0' && pos < maxSize - 1) {
        dest[pos] = src[i];
        pos++;
        i++;
    }
    dest[pos] = '\0';
}

bool Text::equals(const char a[], const char b[]) {
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (a[i] != b[i]) {
            return false;
        }
        i++;
    }
    return a[i] == '\0' && b[i] == '\0';
}

bool Text::equalsIgnoreCase(const char a[], const char b[]) {
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        char ca = lowerChar(a[i]);
        char cb = lowerChar(b[i]);
        if (ca != cb) {
            return false;
        }
        i++;
    }
    return a[i] == '\0' && b[i] == '\0';
}

char Text::lowerChar(char c) {
    if (c >= 'A' && c <= 'Z') {
        return (char)(c + 32);
    }
    return c;
}

bool Text::isEmpty(const char value[]) {
    return value[0] == '\0';
}

int Text::toIntLoose(const char value[]) {
    int i = 0;
    int sign = 1;
    int result = 0;
    if (value[0] == '-') {
        sign = -1;
        i = 1;
    }
    while (value[i] >= '0' && value[i] <= '9') {
        result = result * 10 + (value[i] - '0');
        i++;
    }
    return result * sign;
}

double Text::toDoubleLoose(const char value[]) {
    int i = 0;
    int sign = 1;
    double result = 0.0;
    double place = 0.1;
    if (value[0] == '-') {
        sign = -1;
        i = 1;
    }
    while (value[i] >= '0' && value[i] <= '9') {
        result = result * 10.0 + (double)(value[i] - '0');
        i++;
    }
    if (value[i] == '.') {
        i++;
        while (value[i] >= '0' && value[i] <= '9') {
            result += (double)(value[i] - '0') * place;
            place /= 10.0;
            i++;
        }
    }
    return result * sign;
}