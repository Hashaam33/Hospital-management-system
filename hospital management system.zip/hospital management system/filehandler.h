#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Prescription.h"
#include "Bill.h"

class FileHandler {
private:
    static void splitLine(char line[], char fields[][600], int maxFields, int& fieldCount);
    static void requireReadable(const char fileName[]);
    static void writePatientLine(std::ofstream& out, const Patient& p);
    static void writeDoctorLine(std::ofstream& out, const Doctor& d);
    static void writeAdminLine(std::ofstream& out, const Admin& a);
    static void writeAppointmentLine(std::ofstream& out, const Appointment& a);
    static void writeBillLine(std::ofstream& out, const Bill& b);
    static void writePrescriptionLine(std::ofstream& out, const Prescription& p);
public:
    static const char* patientsFile();
    static const char* doctorsFile();
    static const char* adminFile();
    static const char* appointmentsFile();
    static const char* prescriptionsFile();
    static const char* billsFile();
    static void verifyStartupFiles();
    static void loadPatients(Storage<Patient>& storage);
    static void loadDoctors(Storage<Doctor>& storage);
    static void loadAdmins(Storage<Admin>& storage);
    static void loadAppointments(Storage<Appointment>& storage);
    static void loadPrescriptions(Storage<Prescription>& storage);
    static void loadBills(Storage<Bill>& storage);
    static void loadAll(Storage<Patient>& patients, Storage<Doctor>& doctors, Storage<Admin>& admins,
        Storage<Appointment>& appointments, Storage<Prescription>& prescriptions,
        Storage<Bill>& bills);
    static int maxIdInFile(const char fileName[]);
    static int nextAppointmentId();
    static int nextDoctorId();
    static int nextBillId();
    static int nextPrescriptionId();
    static int nextPatientId();
    static void savePatients(const Storage<Patient>& storage);
    static void saveDoctors(const Storage<Doctor>& storage);
    static void saveAdmins(const Storage<Admin>& storage);
    static void saveAppointments(const Storage<Appointment>& storage);
    static void savePrescriptions(const Storage<Prescription>& storage);
    static void saveBills(const Storage<Bill>& storage);
    static bool appendDoctor(const Doctor& doctor, Storage<Doctor>& storage);
    static bool appendAppointment(const Appointment& appointment, Storage<Appointment>& storage);
    static bool appendPatient(const Patient& patient, Storage<Patient>& storage);
    static bool appendBill(const Bill& bill, Storage<Bill>& storage);
    static bool appendPrescription(const Prescription& prescription, Storage<Prescription>& storage);
    static bool updatePatientById(Storage<Patient>& storage, const Patient& updated);
    static bool updateDoctorById(Storage<Doctor>& storage, const Doctor& updated);
    static bool updateAppointmentById(Storage<Appointment>& storage, const Appointment& updated);
    static bool updateBillById(Storage<Bill>& storage, const Bill& updated);
    static bool deletePatientById(Storage<Patient>& storage, int id);
    static bool deleteDoctorById(Storage<Doctor>& storage, int id);
    static bool deleteAppointmentById(Storage<Appointment>& storage, int id);
    static bool deleteBillById(Storage<Bill>& storage, int id);
    static void deleteAppointmentsByPatientId(Storage<Appointment>& storage, int patientId);
    static void deletePrescriptionsByPatientId(Storage<Prescription>& storage, int patientId);
    static void deleteBillsByPatientId(Storage<Bill>& storage, int patientId);
    static void appendSecurityEvent(const char role[], const char enteredId[], const char result[]);
    static void displaySecurityLog();
    static void archiveDischargedPatient(const Patient& patient, const Storage<Appointment>& appointments,
        const Storage<Prescription>& prescriptions, const Storage<Bill>& bills);
};

#endif
