#include "Person.h"
#include "Text.h"

Person::Person() {
    id = 0;
    Text::copy(name, "", 51);
    Text::copy(contact, "", 12);
    Text::copy(password, "", 51);
}

Person::Person(int personId, const char personName[], const char personContact[], const char personPassword[]) {
    id = personId;
    Text::copy(name, personName, 51);
    Text::copy(contact, personContact, 12);
    Text::copy(password, personPassword, 51);
}

int Person::getId() const {
    return id;
}

const char* Person::getName() const {
    return name;
}

const char* Person::getContact() const {
    return contact;
}

const char* Person::getPassword() const {
    return password;
}

bool Person::passwordMatches(const char entered[]) const {
    return Text::equals(password, entered);
}

Person::~Person() {}