#ifndef STORAGE_H
#define STORAGE_H

template <class T>
class Storage {
private:
    T* data;
    int count;
    int capacity;
public:
    Storage() {
        capacity = 100;
        data = new T[capacity];
        count = 0;
        int count;

    }
    Storage(const Storage<T>& other) {
        capacity = other.capacity;
        count = other.count;
        data = new T[capacity];
        for (int i = 0; i < count; i++) {
            data[i] = other.data[i];
        }
    }

    Storage<T>& operator=(const Storage<T>& other) {
        if (this != &other) {
            delete[] data;
            capacity = other.capacity;
            count = other.count;
            data = new T[capacity];
            for (int i = 0; i < count; i++) {
                data[i] = other.data[i];
            }
        }
        return *this;
    }

    ~Storage() {
        delete[] data;
    }

    void clear() {
        count = 0;
    }

    bool add(const T& item) {
        if (count >= capacity) {
            return false;
        }
        data[count] = item;
        count++;
        return true;
    }

    bool removeById(int id) {
        for (int i = 0; i < count; i++) {
            if (data[i].getId() == id) {
                return removeAt(i);
            }
        }
        return false;
    }

    bool removeAt(int index) {
        if (index < 0 || index >= count) {
            return false;
        }
        for (int i = index; i < count - 1; i++) {
            data[i] = data[i + 1];
        }
        count--;
        return true;
    }

    T* findById(int id) {
        for (int i = 0; i < count; i++) {
            if (data[i].getId() == id) {
                return &data[i];
            }
        }
        return 0;
    }

    const T* findById(int id) const {
        for (int i = 0; i < count; i++) {
            if (data[i].getId() == id) {
                return &data[i];
            }
        }
        return 0;
    }

    T* getAll() {
        return data;
    }

    int size() const {
        return count;
    }

    T& at(int index) {
        return data[index];
    }

    const T& at(int index) const {
        return data[index];
    }
};

#endif