#ifndef PRESCRIPTION_H
#define PRESCRIPTION_H

class Prescription {
private:
    int id;
    int appointmentId;
    int patientId;
    int doctorId;
    char date[11];
    char medicines[500];
    char notes[300];
public:
    Prescription();
    Prescription(int prescriptionId, int appId, int pId, int dId, const char prescriptionDate[],
        const char prescriptionMedicines[], const char prescriptionNotes[]);
    int getId() const;
    int getAppointmentId() const;
    int getPatientId() const;
    int getDoctorId() const;
    const char* getDate() const;
    const char* getMedicines() const;
    const char* getNotes() const;
    ~Prescription();
};

#endif