#ifndef ADMIN_H
#define ADMIN_H

#include <SFML/Graphics.hpp>
#include "Person.h"

class Admin : public Person {
public:
    Admin();
    Admin(int adminId, const char adminName[], const char adminPassword[]);

    void        display()   const;
    const char* roleName()  const;

    // ── SFML helpers ─────────────────────────────────────────────────────────
    static bool isRoleButtonHovered(sf::RenderWindow& window, float x, float y);
    static void drawRoleButton(sf::RenderWindow& window, sf::Font& font,
        float x, float y, bool hovered);

    // Draw a small shield / admin icon at (x, y)
    static void drawIcon(sf::RenderWindow& window, float x, float y);

    // Full SFML login screen for the Admin role
    static bool runLoginScreen(sf::RenderWindow& window, sf::Font& font,
        char outPassword[], int maxLen);

    ~Admin();
};

#endif // ADMIN_H