#include "FileHandler.h"
#include "HospitalException.h"
#include "Text.h"
#include "DateTools.h"
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

void FileHandler::splitLine(char line[], char fields[][600], int maxFields, int& fieldCount) {
    fieldCount = 0;
    int pos = 0;
    for (int i = 0; ; i++) {
        char c = line[i];
        if (c == ',' || c == '\0') {
            fields[fieldCount][pos] = '\0';
            fieldCount++;
            pos = 0;
            if (c == '\0' || fieldCount >= maxFields) {
                break;
            }
        }
        else {
            if (pos < 599) {
                fields[fieldCount][pos] = c;
                pos++;
            }
        }
    }
}

void FileHandler::requireReadable(const char fileName[]) {
    ifstream in(fileName);
    if (!in) {
        throw FileNotFoundException(fileName);
    }
    in.close();
}

void FileHandler::writePatientLine(ofstream& out, const Patient& p) {
    out << p.getId() << "," << p.getName() << "," << p.getAge() << "," << p.getGender()
        << "," << p.getContact() << "," << p.getPassword() << ","
        << fixed << setprecision(2) << p.getBalance() << endl;
}

void FileHandler::writeDoctorLine(ofstream& out, const Doctor& d) {
    out << d.getId() << "," << d.getName() << "," << d.getSpecialization() << ","
        << d.getContact() << "," << d.getPassword() << ","
        << fixed << setprecision(2) << d.getFee() << endl;
}

void FileHandler::writeAdminLine(ofstream& out, const Admin& a) {
    out << a.getId() << "," << a.getName() << "," << a.getPassword() << endl;
}

void FileHandler::writeAppointmentLine(ofstream& out, const Appointment& a) {
    out << a.getId() << "," << a.getPatientId() << "," << a.getDoctorId() << ","
        << a.getDate() << "," << a.getTimeSlot() << "," << a.getStatus() << endl;
}

void FileHandler::writeBillLine(ofstream& out, const Bill& b) {
    out << b.getId() << "," << b.getPatientId() << "," << b.getAppointmentId() << ","
        << fixed << setprecision(2) << b.getAmount() << "," << b.getStatus() << ","
        << b.getDate() << endl;
}

void FileHandler::writePrescriptionLine(ofstream& out, const Prescription& p) {
    out << p.getId() << "," << p.getAppointmentId() << "," << p.getPatientId() << ","
        << p.getDoctorId() << "," << p.getDate() << "," << p.getMedicines() << ","
        << p.getNotes() << endl;
}

const char* FileHandler::patientsFile() {
    return "patients.txt";
}

const char* FileHandler::doctorsFile() {
    return "doctors.txt";
}

const char* FileHandler::adminFile() {
    return "admin.txt";
}

const char* FileHandler::appointmentsFile() {
    return "appointments.txt";
}

const char* FileHandler::prescriptionsFile() {
    return "prescriptions.txt";
}

const char* FileHandler::billsFile() {
    return "bills.txt";
}

void FileHandler::verifyStartupFiles() {
    requireReadable(patientsFile());
    requireReadable(doctorsFile());
    requireReadable(adminFile());
    requireReadable(appointmentsFile());
    requireReadable(prescriptionsFile());
    requireReadable(billsFile());
    requireReadable("security_log.txt");
    requireReadable("discharged.txt");
}

void FileHandler::loadPatients(Storage<Patient>& storage) {
    storage.clear();
    ifstream in(patientsFile());
    if (!in) {
        throw FileNotFoundException(patientsFile());
    }
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[10][600];
        int total = 0;
        splitLine(line, fields, 10, total);
        if (total >= 7) {
            Patient p(Text::toIntLoose(fields[0]), fields[1], Text::toIntLoose(fields[2]),
                fields[3][0], fields[4], fields[5], Text::toDoubleLoose(fields[6]));
            storage.add(p);
        }
    }
    in.close();
}

void FileHandler::loadDoctors(Storage<Doctor>& storage) {
    storage.clear();
    ifstream in(doctorsFile());
    if (!in) {
        throw FileNotFoundException(doctorsFile());
    }
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[10][600];
        int total = 0;
        splitLine(line, fields, 10, total);
        if (total >= 6) {
            Doctor d(Text::toIntLoose(fields[0]), fields[1], fields[2], fields[3],
                fields[4], Text::toDoubleLoose(fields[5]));
            storage.add(d);
        }
    }
    in.close();
}

void FileHandler::loadAdmins(Storage<Admin>& storage) {
    storage.clear();
    ifstream in(adminFile());
    if (!in) {
        throw FileNotFoundException(adminFile());
    }
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[5][600];
        int total = 0;
        splitLine(line, fields, 5, total);
        if (total >= 3) {
            Admin a(Text::toIntLoose(fields[0]), fields[1], fields[2]);
            storage.add(a);
        }
    }
    in.close();
}

void FileHandler::loadAppointments(Storage<Appointment>& storage) {
    storage.clear();
    ifstream in(appointmentsFile());
    if (!in) {
        throw FileNotFoundException(appointmentsFile());
    }
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[10][600];
        int total = 0;
        splitLine(line, fields, 10, total);
        if (total >= 6) {
            Appointment a(Text::toIntLoose(fields[0]), Text::toIntLoose(fields[1]),
                Text::toIntLoose(fields[2]), fields[3], fields[4], fields[5]);
            storage.add(a);
        }
    }
    in.close();
}

void FileHandler::loadPrescriptions(Storage<Prescription>& storage) {
    storage.clear();
    ifstream in(prescriptionsFile());
    if (!in) {
        throw FileNotFoundException(prescriptionsFile());
    }
    char line[1200];
    while (in.getline(line, 1200)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[10][600];
        int total = 0;
        splitLine(line, fields, 10, total);
        if (total >= 7) {
            Prescription p(Text::toIntLoose(fields[0]), Text::toIntLoose(fields[1]),
                Text::toIntLoose(fields[2]), Text::toIntLoose(fields[3]),
                fields[4], fields[5], fields[6]);
            storage.add(p);
        }
    }
    in.close();
}

void FileHandler::loadBills(Storage<Bill>& storage) {
    storage.clear();
    ifstream in(billsFile());
    if (!in) {
        throw FileNotFoundException(billsFile());
    }
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[10][600];
        int total = 0;
        splitLine(line, fields, 10, total);
        if (total >= 6) {
            Bill b(Text::toIntLoose(fields[0]), Text::toIntLoose(fields[1]),
                Text::toIntLoose(fields[2]), Text::toDoubleLoose(fields[3]),
                fields[4], fields[5]);
            storage.add(b);
        }
    }
    in.close();
}

void FileHandler::loadAll(Storage<Patient>& patients, Storage<Doctor>& doctors, Storage<Admin>& admins,
    Storage<Appointment>& appointments, Storage<Prescription>& prescriptions,
    Storage<Bill>& bills) {
    verifyStartupFiles();
    loadPatients(patients);
    loadDoctors(doctors);
    loadAdmins(admins);
    loadAppointments(appointments);
    loadPrescriptions(prescriptions);
    loadBills(bills);
}

int FileHandler::maxIdInFile(const char fileName[]) {
    ifstream in(fileName);
    if (!in) {
        throw FileNotFoundException(fileName);
    }
    int maxId = 0;
    char line[1000];
    while (in.getline(line, 1000)) {
        if (Text::isEmpty(line)) {
            continue;
        }
        char fields[3][600];
        int total = 0;
        splitLine(line, fields, 3, total);
        int current = Text::toIntLoose(fields[0]);
        if (current > maxId) {
            maxId = current;
        }
    }
    in.close();
    return maxId;
}

int FileHandler::nextAppointmentId() {
    return maxIdInFile(appointmentsFile()) + 1;
}

int FileHandler::nextPatientId() {
    return maxIdInFile(patientsFile()) + 1;
}

int FileHandler::nextDoctorId() {
    return maxIdInFile(doctorsFile()) + 1;
}

int FileHandler::nextBillId() {
    return maxIdInFile(billsFile()) + 1;
}

int FileHandler::nextPrescriptionId() {
    return maxIdInFile(prescriptionsFile()) + 1;
}

void FileHandler::savePatients(const Storage<Patient>& storage) {
    ofstream out(patientsFile());
    if (!out) {
        throw FileNotFoundException(patientsFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writePatientLine(out, storage.at(i));
    }
    out.close();
}

void FileHandler::saveDoctors(const Storage<Doctor>& storage) {
    ofstream out(doctorsFile());
    if (!out) {
        throw FileNotFoundException(doctorsFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writeDoctorLine(out, storage.at(i));
    }
    out.close();
}

void FileHandler::saveAdmins(const Storage<Admin>& storage) {
    ofstream out(adminFile());
    if (!out) {
        throw FileNotFoundException(adminFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writeAdminLine(out, storage.at(i));
    }
    out.close();
}

void FileHandler::saveAppointments(const Storage<Appointment>& storage) {
    ofstream out(appointmentsFile());
    if (!out) {
        throw FileNotFoundException(appointmentsFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writeAppointmentLine(out, storage.at(i));
    }
    out.close();
}

void FileHandler::savePrescriptions(const Storage<Prescription>& storage) {
    ofstream out(prescriptionsFile());
    if (!out) {
        throw FileNotFoundException(prescriptionsFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writePrescriptionLine(out, storage.at(i));
    }
    out.close();
}

void FileHandler::saveBills(const Storage<Bill>& storage) {
    ofstream out(billsFile());
    if (!out) {
        throw FileNotFoundException(billsFile());
    }
    for (int i = 0; i < storage.size(); i++) {
        writeBillLine(out, storage.at(i));
    }
    out.close();
}

bool FileHandler::appendPatient(const Patient& patient, Storage<Patient>& storage) {
    if (storage.size() >= 100) {
        return false;
    }
    ofstream out(patientsFile(), ios::app);
    if (!out) {
        throw FileNotFoundException(patientsFile());
    }
    writePatientLine(out, patient);
    out.close();
    return storage.add(patient);
}

bool FileHandler::appendDoctor(const Doctor& doctor, Storage<Doctor>& storage) {
    if (storage.size() >= 100) {
        return false;
    }
    ofstream out(doctorsFile(), ios::app);
    if (!out) {
        throw FileNotFoundException(doctorsFile());
    }
    writeDoctorLine(out, doctor);
    out.close();
    return storage.add(doctor);
}

bool FileHandler::appendAppointment(const Appointment& appointment, Storage<Appointment>& storage) {
    if (storage.size() >= 100) {
        return false;
    }
    ofstream out(appointmentsFile(), ios::app);
    if (!out) {
        throw FileNotFoundException(appointmentsFile());
    }
    writeAppointmentLine(out, appointment);
    out.close();
    return storage.add(appointment);
}

bool FileHandler::appendBill(const Bill& bill, Storage<Bill>& storage) {
    if (storage.size() >= 100) {
        return false;
    }
    ofstream out(billsFile(), ios::app);
    if (!out) {
        throw FileNotFoundException(billsFile());
    }
    writeBillLine(out, bill);
    out.close();
    return storage.add(bill);
}

bool FileHandler::appendPrescription(const Prescription& prescription, Storage<Prescription>& storage) {
    if (storage.size() >= 100) {
        return false;
    }
    ofstream out(prescriptionsFile(), ios::app);
    if (!out) {
        throw FileNotFoundException(prescriptionsFile());
    }
    writePrescriptionLine(out, prescription);
    out.close();
    return storage.add(prescription);
}

bool FileHandler::updatePatientById(Storage<Patient>& storage, const Patient& updated) {
    for (int i = 0; i < storage.size(); i++) {
        if (storage.at(i).getId() == updated.getId()) {
            storage.at(i) = updated;
            savePatients(storage);
            return true;
        }
    }
    return false;
}

bool FileHandler::updateDoctorById(Storage<Doctor>& storage, const Doctor& updated) {
    for (int i = 0; i < storage.size(); i++) {
        if (storage.at(i).getId() == updated.getId()) {
            storage.at(i) = updated;
            saveDoctors(storage);
            return true;
        }
    }
    return false;
}

bool FileHandler::updateAppointmentById(Storage<Appointment>& storage, const Appointment& updated) {
    for (int i = 0; i < storage.size(); i++) {
        if (storage.at(i).getId() == updated.getId()) {
            storage.at(i) = updated;
            saveAppointments(storage);
            return true;
        }
    }
    return false;
}

bool FileHandler::updateBillById(Storage<Bill>& storage, const Bill& updated) {
    for (int i = 0; i < storage.size(); i++) {
        if (storage.at(i).getId() == updated.getId()) {
            storage.at(i) = updated;
            saveBills(storage);
            return true;
        }
    }
    return false;
}

bool FileHandler::deletePatientById(Storage<Patient>& storage, int id) {
    bool removed = storage.removeById(id);
    if (removed) {
        savePatients(storage);
    }
    return removed;
}

bool FileHandler::deleteDoctorById(Storage<Doctor>& storage, int id) {
    bool removed = storage.removeById(id);
    if (removed) {
        saveDoctors(storage);
    }
    return removed;
}

bool FileHandler::deleteAppointmentById(Storage<Appointment>& storage, int id) {
    bool removed = storage.removeById(id);
    if (removed) {
        saveAppointments(storage);
    }
    return removed;
}

bool FileHandler::deleteBillById(Storage<Bill>& storage, int id) {
    bool removed = storage.removeById(id);
    if (removed) {
        saveBills(storage);
    }
    return removed;
}

void FileHandler::deleteAppointmentsByPatientId(Storage<Appointment>& storage, int patientId) {
    for (int i = 0; i < storage.size();) {
        if (storage.at(i).getPatientId() == patientId) {
            storage.removeAt(i);
        }
        else {
            i++;
        }
    }
    saveAppointments(storage);
}

void FileHandler::deletePrescriptionsByPatientId(Storage<Prescription>& storage, int patientId) {
    for (int i = 0; i < storage.size();) {
        if (storage.at(i).getPatientId() == patientId) {
            storage.removeAt(i);
        }
        else {
            i++;
        }
    }
    savePrescriptions(storage);
}

void FileHandler::deleteBillsByPatientId(Storage<Bill>& storage, int patientId) {
    for (int i = 0; i < storage.size();) {
        if (storage.at(i).getPatientId() == patientId) {
            storage.removeAt(i);
        }
        else {
            i++;
        }
    }
    saveBills(storage);
}

void FileHandler::appendSecurityEvent(const char role[], const char enteredId[], const char result[]) {
    ofstream out("security_log.txt", ios::app);
    if (!out) {
        throw FileNotFoundException("security_log.txt");
    }
    char stamp[20];
    DateTools::timestamp(stamp);
    out << stamp << "," << role << "," << enteredId << "," << result << endl;
    out.close();
}

void FileHandler::displaySecurityLog() {
    ifstream in("security_log.txt");
    if (!in) {
        throw FileNotFoundException("security_log.txt");
    }
    char line[1000];
    bool found = false;
    while (in.getline(line, 1000)) {
        if (!Text::isEmpty(line)) {
            cout << line << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "No security events logged." << endl;
    }
    in.close();
}

void FileHandler::archiveDischargedPatient(const Patient& patient, const Storage<Appointment>& appointments,
    const Storage<Prescription>& prescriptions, const Storage<Bill>& bills) {
    ofstream out("discharged.txt", ios::app);
    if (!out) {
        throw FileNotFoundException("discharged.txt");
    }
    out << "PATIENT,";
    writePatientLine(out, patient);
    for (int i = 0; i < appointments.size(); i++) {
        if (appointments.at(i).getPatientId() == patient.getId()) {
            out << "APPOINTMENT,";
            writeAppointmentLine(out, appointments.at(i));
        }
    }
    for (int i = 0; i < prescriptions.size(); i++) {
        if (prescriptions.at(i).getPatientId() == patient.getId()) {
            out << "PRESCRIPTION,";
            writePrescriptionLine(out, prescriptions.at(i));
        }
    }
    for (int i = 0; i < bills.size(); i++) {
        if (bills.at(i).getPatientId() == patient.getId()) {
            out << "BILL,";
            writeBillLine(out, bills.at(i));
        }
    }
    out.close();
}