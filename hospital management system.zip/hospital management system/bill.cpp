#include "Bill.h"
#include "Text.h"

Bill::Bill() {
    id = 0;
    patientId = 0;
    appointmentId = 0;
    amount = 0.0;
    Text::copy(status, "unpaid", 16);
    Text::copy(date, "", 11);
}

Bill::Bill(int billId, int pId, int appId, double billAmount, const char billStatus[], const char billDate[]) {
    id = billId;
    patientId = pId;
    appointmentId = appId;
    amount = billAmount;
    Text::copy(status, billStatus, 16);
    Text::copy(date, billDate, 11);
}

int Bill::getId() const {
    return id;
}

int Bill::getPatientId() const {
    return patientId;
}

int Bill::getAppointmentId() const {
    return appointmentId;
}

double Bill::getAmount() const {
    return amount;
}

const char* Bill::getStatus() const {
    return status;
}

const char* Bill::getDate() const {
    return date;
}

void Bill::setStatus(const char newStatus[]) {
    Text::copy(status, newStatus, 16);
}

void Bill::setDate(const char newDate[]) {
    Text::copy(date, newDate, 11);
}

Bill::~Bill() {}