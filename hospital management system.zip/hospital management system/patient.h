#ifndef PATIENT_H
#define PATIENT_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include "Person.h"

class Patient : public Person {
private:
    int age;
    char gender;
    double balance;

public:
    Patient();
    Patient(int patientId, const char patientName[], int patientAge, char patientGender,
        const char patientContact[], const char patientPassword[], double patientBalance);

    void display() const;
    const char* roleName() const;

    int    getAge()     const;
    char   getGender()  const;
    double getBalance() const;

    Patient& operator+=(double amount);
    Patient& operator-=(double amount);
    bool     operator==(const Patient& other) const;
    bool     operator>=(double amount)        const;

    friend std::ostream& operator<<(std::ostream& out, const Patient& patient);

    // ── SFML helpers ─────────────────────────────────────────────────────────
    // Font is loaded once by HospitalSystem / caller and passed in.
    static bool isRoleButtonHovered(sf::RenderWindow& window, float x, float y);
    static void drawRoleButton(sf::RenderWindow& window, sf::Font& font,
        float x, float y, bool hovered);

    // Draw a small patient silhouette icon at (x, y)
    static void drawIcon(sf::RenderWindow& window, float x, float y);

    // Full SFML login / info panel for the Patient role
    // Returns true when the user successfully authenticates.
    static bool runLoginScreen(sf::RenderWindow& window, sf::Font& font,
        char outPassword[], int maxLen);

    ~Patient();
};

#endif // PATIENT_H