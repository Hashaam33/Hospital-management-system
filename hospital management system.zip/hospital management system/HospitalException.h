#ifndef HOSPITALEXCEPTION_H
#define HOSPITALEXCEPTION_H

class HospitalException {
protected:
    char message[200];
public:
    HospitalException(const char msg[] = "Hospital error.");
    virtual const char* what() const;
};

class FileNotFoundException : public HospitalException {
public:
    FileNotFoundException(const char fileName[]);
};

class InsufficientFundsException : public HospitalException {
public:
    InsufficientFundsException(const char msg[] = "Insufficient funds.");
};

class InvalidInputException : public HospitalException {
public:
    InvalidInputException(const char msg[] = "Invalid input.");
};

class SlotUnavailableException : public HospitalException {
public:
    SlotUnavailableException(const char msg[] = "Selected time slot is not available.");
   
};

#endif
