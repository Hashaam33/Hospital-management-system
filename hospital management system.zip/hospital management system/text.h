#ifndef TEXT_H
#define TEXT_H

class Text {
public:
    static int length(const char value[]);
    static void copy(char dest[], const char src[], int maxSize);
    static void append(char dest[], const char src[], int maxSize);
    static bool equals(const char a[], const char b[]);
    static bool equalsIgnoreCase(const char a[], const char b[]);
    static char lowerChar(char c);
    static bool isEmpty(const char value[]);
    static int toIntLoose(const char value[]);
    static double toDoubleLoose(const char value[]);
};

#endif
