#include <SFML/Graphics.hpp>
#include "HospitalSystem.h"
#include <iostream>
#include <fstream>

using namespace std;



static bool mouseInside(sf::RectangleShape& box, sf::RenderWindow& window) {
    sf::Vector2i mouse = sf::Mouse::getPosition(window);
    return box.getGlobalBounds().contains(sf::Vector2f((float)mouse.x, (float)mouse.y));
}

static void setupButton(sf::RectangleShape& box, float y, sf::Color color) {
    box.setSize(sf::Vector2f(440.0f, 85.0f));
    box.setOrigin(sf::Vector2f(220.0f, 42.5f));
    box.setPosition(sf::Vector2f(500.0f, y));
    box.setFillColor(color);
    box.setOutlineThickness(6.0f);
    box.setOutlineColor(sf::Color::White);
}



static void drawPatientIcon(sf::RenderWindow& window, float x, float y) {
    sf::CircleShape head(18.0f);
    head.setOrigin(sf::Vector2f(18.0f, 18.0f));
    head.setPosition(sf::Vector2f(x, y - 14.0f));
    head.setFillColor(sf::Color::White);
    window.draw(head);

    sf::RectangleShape body(sf::Vector2f(70.0f, 32.0f));
    body.setOrigin(sf::Vector2f(35.0f, 16.0f));
    body.setPosition(sf::Vector2f(x, y + 24.0f));
    body.setFillColor(sf::Color::White);
    window.draw(body);
}

static void drawDoctorIcon(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape vertical(sf::Vector2f(22.0f, 70.0f));
    vertical.setOrigin(sf::Vector2f(11.0f, 35.0f));
    vertical.setPosition(sf::Vector2f(x, y));
    vertical.setFillColor(sf::Color::White);
    window.draw(vertical);

    sf::RectangleShape horizontal(sf::Vector2f(70.0f, 22.0f));
    horizontal.setOrigin(sf::Vector2f(35.0f, 11.0f));
    horizontal.setPosition(sf::Vector2f(x, y));
    horizontal.setFillColor(sf::Color::White);
    window.draw(horizontal);
}

static void drawAdminIcon(sf::RenderWindow& window, float x, float y) {
    sf::CircleShape shield(42.0f, 5);
    shield.setOrigin(sf::Vector2f(42.0f, 42.0f));
    shield.setPosition(sf::Vector2f(x, y));
    shield.setFillColor(sf::Color::White);
    window.draw(shield);

    sf::CircleShape center(16.0f);
    center.setOrigin(sf::Vector2f(16.0f, 16.0f));
    center.setPosition(sf::Vector2f(x, y));
    center.setFillColor(sf::Color(35, 80, 190));
    window.draw(center);
}

static void drawExitIcon(sf::RenderWindow& window, float x, float y) {
    sf::RectangleShape line1(sf::Vector2f(90.0f, 16.0f));
    line1.setOrigin(sf::Vector2f(45.0f, 8.0f));
    line1.setPosition(sf::Vector2f(x, y));
    line1.setRotation(sf::degrees(45.0f));
    line1.setFillColor(sf::Color::White);
    window.draw(line1);

    sf::RectangleShape line2(sf::Vector2f(90.0f, 16.0f));
    line2.setOrigin(sf::Vector2f(45.0f, 8.0f));
    line2.setPosition(sf::Vector2f(x, y));
    line2.setRotation(sf::degrees(-45.0f));
    line2.setFillColor(sf::Color::White);
    window.draw(line2);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Draw a centred text label using arial.ttf
// ─────────────────────────────────────────────────────────────────────────────

static void drawCentredText(sf::RenderWindow& window, sf::Font& font,
    const sf::String& str, unsigned int size,
    sf::Color color, float x, float y)
{
    sf::Text text(font);
    text.setString(str);
    text.setCharacterSize(size);
    text.setFillColor(color);
    text.setStyle(sf::Text::Bold);

    sf::FloatRect bounds = text.getLocalBounds();
    text.setOrigin(sf::Vector2f(bounds.position.x + bounds.size.x / 2.0f,
        bounds.position.y + bounds.size.y / 2.0f));
    text.setPosition(sf::Vector2f(x, y));
    window.draw(text);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Main menu
//  Returns: 1=Patient  2=Doctor  3=Admin  4=Exit
// ─────────────────────────────────────────────────────────────────────────────

int runSfmlMainMenu() {
    sf::RenderWindow window(
        sf::VideoMode(sf::Vector2u(1000u, 700u)),
        "MediCore Hospital Management System"
    );
    window.setFramerateLimit(60);
    window.setActive(true);
    window.requestFocus();

    // ── Load Arial via fstream → openFromMemory (bypasses all path issues) ──
    // We try every likely location; whichever opens first wins.
    sf::Font font;
    bool fontLoaded = false;

    // Candidate paths (Windows system font dir is always the first choice)
    const char* candidates[] = {
        "C:\\Windows\\Fonts\\arial.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "arial.ttf"
    };
    const int numCandidates = 3;

    for (int c = 0; c < numCandidates && !fontLoaded; c++) {
        ifstream file(candidates[c], ios::binary | ios::ate);
        if (!file.is_open()) continue;

        // Read entire file into a heap buffer
        streamsize size = file.tellg();
        file.seekg(0, ios::beg);

        char* buf = new char[size];
        if (file.read(buf, size)) {
            fontLoaded = font.openFromMemory(buf, (size_t)size);
        }
        // Note: buf must stay alive while font is in use — store it below
        if (fontLoaded) {
            // Transfer ownership to a static buffer so it outlives this scope
            static char* fontBuf = nullptr;
            delete[] fontBuf;   // free any previous attempt
            fontBuf = buf;
        }
        else {
            delete[] buf;
        }
    }

    if (!fontLoaded) {
        cerr << "[WARNING] Could not load Arial font.\n";
    }

    // ── Shapes ──────────────────────────────────────────────────────────────
    sf::RectangleShape background(sf::Vector2f(1000.0f, 700.0f));
    background.setFillColor(sf::Color(245, 245, 245));

    sf::RectangleShape header(sf::Vector2f(1000.0f, 120.0f));
    header.setPosition(sf::Vector2f(0.0f, 0.0f));
    header.setFillColor(sf::Color(20, 90, 130));

    sf::RectangleShape panel(sf::Vector2f(600.0f, 500.0f));
    panel.setOrigin(sf::Vector2f(300.0f, 250.0f));
    panel.setPosition(sf::Vector2f(500.0f, 400.0f));
    panel.setFillColor(sf::Color(30, 40, 50));
    panel.setOutlineThickness(8.0f);
    panel.setOutlineColor(sf::Color::Black);

    sf::RectangleShape patientButton, doctorButton, adminButton, exitButton;
    setupButton(patientButton, 250.0f, sf::Color(220, 45, 55));
    setupButton(doctorButton, 355.0f, sf::Color(35, 170, 85));
    setupButton(adminButton, 460.0f, sf::Color(55, 95, 220));
    setupButton(exitButton, 565.0f, sf::Color(175, 55, 190));

    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) { window.close(); return 4; }

            if (const sf::Event::KeyPressed* key = event->getIf<sf::Event::KeyPressed>()) {
                if (key->code == sf::Keyboard::Key::Escape) { window.close(); return 4; }
            }

            if (const sf::Event::MouseButtonPressed* click =
                event->getIf<sf::Event::MouseButtonPressed>()) {
                if (click->button == sf::Mouse::Button::Left) {
                    if (mouseInside(patientButton, window)) { window.close(); return 1; }
                    if (mouseInside(doctorButton, window)) { window.close(); return 2; }
                    if (mouseInside(adminButton, window)) { window.close(); return 3; }
                    if (mouseInside(exitButton, window)) { window.close(); return 4; }
                }
            }
        }

        // Hover colours
        patientButton.setFillColor(mouseInside(patientButton, window)
            ? sf::Color(255, 90, 100) : sf::Color(220, 45, 55));
        doctorButton.setFillColor(mouseInside(doctorButton, window)
            ? sf::Color(80, 220, 130) : sf::Color(35, 170, 85));
        adminButton.setFillColor(mouseInside(adminButton, window)
            ? sf::Color(95, 135, 255) : sf::Color(55, 95, 220));
        exitButton.setFillColor(mouseInside(exitButton, window)
            ? sf::Color(220, 95, 235) : sf::Color(175, 55, 190));

        // ── Draw ────────────────────────────────────────────────────────────
        window.clear(sf::Color::Yellow);
        window.draw(background);
        window.draw(header);

        // Header title
        if (fontLoaded)
            drawCentredText(window, font, "MediCore Hospital System",
                36, sf::Color::White, 500.0f, 60.0f);

        window.draw(panel);

        // Buttons
        window.draw(patientButton);
        window.draw(doctorButton);
        window.draw(adminButton);
        window.draw(exitButton);

        // Icons (shapes)
        drawPatientIcon(window, 360.0f, 250.0f);
        drawDoctorIcon(window, 360.0f, 355.0f);
        drawAdminIcon(window, 360.0f, 460.0f);
        drawExitIcon(window, 360.0f, 565.0f);

        // Button labels (text)
        if (fontLoaded) {
            drawCentredText(window, font, "Patient", 26, sf::Color::White, 510.0f, 248.0f);
            drawCentredText(window, font, "Doctor", 26, sf::Color::White, 510.0f, 353.0f);
            drawCentredText(window, font, "Admin", 26, sf::Color::White, 510.0f, 458.0f);
            drawCentredText(window, font, "Exit", 26, sf::Color::White, 510.0f, 563.0f);
        }

        window.display();
    }

    return 4;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Entry point
// ─────────────────────────────────────────────────────────────────────────────

int main() {
    int selectedRole = runSfmlMainMenu();

    if (selectedRole >= 1 && selectedRole <= 3) {
        HospitalSystem system;
        system.runSelectedRole(selectedRole);
    }

    return 0;
}